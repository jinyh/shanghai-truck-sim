from __future__ import annotations
import argparse
import json
from pathlib import Path
from .analysis import run,planning
from .demo import make_demo,PLANS
from .io import ROOT,templates,save_result,load_bundle,preserve_import


def main():
    parser=argparse.ArgumentParser(description='上海重卡接入与配套电网规划仿真')
    sub=parser.add_subparsers(dest='command',required=True)
    p=sub.add_parser('serve');p.add_argument('--port',type=int,default=8785)
    p=sub.add_parser('demo');p.add_argument('--year',type=int,default=2027);p.add_argument('--growth',default='medium',choices=['low','medium','high']);p.add_argument('--plan',default='ordered',choices=list(PLANS));p.add_argument('--stress',default='normal',choices=['normal','bunched','early','derated','control_loss']);p.add_argument('--ac',action='store_true')
    p=sub.add_parser('run');p.add_argument('path');p.add_argument('--method',default='optimized');p.add_argument('--ac',action='store_true')
    p=sub.add_parser('planning');p.add_argument('--growth',default='medium');p.add_argument('--stress',default='normal')
    sub.add_parser('templates');sub.add_parser('research')
    p=sub.add_parser('reproduce');p.add_argument('folder')
    args=parser.parse_args()
    (ROOT/'output').mkdir(exist_ok=True)
    if args.command=='serve':
        from .server import serve
        serve(args.port);return
    if args.command=='templates':print(templates());return
    if args.command=='research':
        from .research import admission
        value=admission();path=ROOT/'output'/'research.json';path.write_text(json.dumps(value,ensure_ascii=False,indent=2));print(path);return
    if args.command=='planning':
        value=planning(args.growth,args.stress);path=ROOT/'output'/f'planning-{args.growth}-{args.stress}.json';path.write_text(json.dumps(value,ensure_ascii=False,indent=2));print(path);return
    if args.command=='reproduce':
        p=Path(args.folder)
        from .verification import reproduce
        check=reproduce(p)
        print(json.dumps(check,ensure_ascii=False,indent=2))
        if not check['passed']:raise SystemExit(1)
        return
    if args.command=='demo':raw=make_demo(args.year,args.growth,args.plan,args.stress);method=PLANS[args.plan]['method']
    else:
        data=Path(args.path).read_bytes();raw=load_bundle(data) if data[:2]==b'PK' else json.loads(data.decode('utf-8-sig'));method=args.method
        from .model import normalize
        normalize(raw);raw=preserve_import(raw,data)
    r=run(raw,method,args.ac);p=save_result(r,ROOT/'output'/('private' if r['evidence_level']!='synthetic' else 'runs'))
    print(json.dumps({'output':str(p),'feasible':r['metrics']['feasible'],'shortfall_kwh':r['metrics']['shortfall_kwh'],'seconds':r['seconds']},ensure_ascii=False,indent=2))


if __name__=='__main__':main()
