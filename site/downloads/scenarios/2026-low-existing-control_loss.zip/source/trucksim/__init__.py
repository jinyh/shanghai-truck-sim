"""Offline, auditable truck charging and grid-planning simulation."""
__version__ = '0.1.0'
