"""Independent conservation, service and capacity checker; no optimizer calls."""
from __future__ import annotations
import math
from .model import reserve_ports


def evaluate(task, solution):
    n=task['periods'];eps=1e-4
    rows=reserve_ports(task)  # do not trust a submitted reservation map
    power=solution.get('power_by_session',{})
    issues=[];shortfall=0.;delivered=0.;queue=0.;served=0
    site={s['id']:[0.]*n for s in task['stations']}
    known={s['id'] for s in rows}
    for extra in set(power)-known:issues.append({'kind':'unknown_session','id':extra})
    sessions=[]
    # Independent reconstruction of immutable requests at stations without control.
    immutable={}
    for station in task['stations']:
        if station['controllable']:continue
        own=sorted([r for r in rows if r['station_id']==station['id']],key=lambda r:(r['arrival_step'],r['id']))
        remaining={r['id']:r['required_kwh'] for r in own}
        for t in range(n):
            room=station['limit_kw'][t]
            for r in own:
                if r['connected_step']<=t<r['departure_step']:
                    p=max(0,min(room,r['power_limit_kw'],remaining[r['id']]/(.25*task['charging_efficiency'])))
                    immutable[(r['id'],t)]=p;room-=p;remaining[r['id']]-=p*.25*task['charging_efficiency']
    for s in rows:
        values=power.get(s['id'])
        if not isinstance(values,list) or len(values)!=n:
            issues.append({'kind':'malformed_series','id':s['id']});values=[0.]*n
        clean=[]
        for t,p in enumerate(values):
            valid=isinstance(p,(int,float)) and not isinstance(p,bool) and math.isfinite(p)
            if not valid:
                issues.append({'kind':'invalid_number','id':s['id'],'step':t});p=0.
            if p < -eps or p > s['power_limit_kw']+eps:
                issues.append({'kind':'vehicle_power','id':s['id'],'step':t})
            if not s['connected_step']<=t<s['departure_step'] and abs(p)>eps:
                issues.append({'kind':'outside_window','id':s['id'],'step':t})
            if (s['id'],t) in immutable and abs(p-immutable[(s['id'],t)])>eps:
                issues.append({'kind':'control_permission','id':s['id'],'step':t})
            clean.append(max(0,p));site[s['station_id']][t]+=max(0,p)
        energy=sum(clean)*.25*task['charging_efficiency']
        missing=max(0,s['required_kwh']-energy)
        if energy>s['required_kwh']+eps:issues.append({'kind':'overdelivery','id':s['id']})
        if missing>eps:issues.append({'kind':'deadline_shortfall','id':s['id'],'kwh':missing})
        delivered+=energy;shortfall+=missing;queue+=s['wait_minutes'];served+=missing<=eps
        sessions.append({**s,'delivered_kwh':energy,'shortfall_kwh':missing})
    feeder={};transformer={};bottlenecks=[]
    def check_asset(asset, curve, kind):
        excess=[max(0,p-cap) for p,cap in zip(curve,asset['limit_kw'])]
        bad=[t for t,x in enumerate(excess) if x>eps]
        if bad:
            issues.append({'kind':'capacity_exceeded','asset_id':asset['id'],
                           'asset_type':kind,'steps':len(bad),'max_excess_kw':max(excess)})
        peak=max(range(n),key=lambda t:curve[t])
        worst=max(range(n),key=lambda t:curve[t]/max(1e-9,asset['limit_kw'][t]))
        rec={'id':asset['id'],'name':asset.get('name',asset['id']),'type':kind,
             'peak_kw':curve[peak],'peak_step':peak,'worst_step':worst,
             'max_loading_pct':100*curve[worst]/max(1e-9,asset['limit_kw'][worst]),
             'violation_hours':len(bad)*.25,'max_excess_kw':max(excess),'curve_kw':curve,
             'limit_kw':asset['limit_kw'],'scope':'本案例评价期'}
        bottlenecks.append(rec)
        return rec
    for s in task['stations']:check_asset(s,site[s['id']],'station')
    for f in task['feeders']:
        child=[site[s['id']] for s in task['stations'] if s['feeder_id']==f['id']]
        feeder[f['id']]=[f['net_background_kw'][t]+f['committed_kw'][t]+sum(c[t] for c in child) for t in range(n)]
        check_asset(f,feeder[f['id']],'feeder')
    for tr in task['transformers']:
        child=[feeder[f['id']] for f in task['feeders'] if f['transformer_id']==tr['id']]
        transformer[tr['id']]=[tr['net_background_kw'][t]+tr['committed_kw'][t]+sum(c[t] for c in child) for t in range(n)]
        check_asset(tr,transformer[tr['id']],'transformer')
    station_cards=[]
    feeder_map={f['id']:f for f in task['feeders']}
    for s in task['stations']:
        fid=s['feeder_id'];tid=feeder_map[fid]['transformer_id']
        tr=next(x for x in task['transformers'] if x['id']==tid)
        own=[x for x in sessions if x['station_id']==s['id']]
        # Conditional instantaneous headroom, NEVER summed across stations.
        headroom=[max(0,min(s['limit_kw'][t]-site[s['id']][t],
                             feeder_map[fid]['limit_kw'][t]-feeder[fid][t],
                             tr['limit_kw'][t]-transformer[tid][t])) for t in range(n)]
        deficits=sum(x['shortfall_kwh'] for x in own)
        own_ids={x['id'] for x in own}
        invalid=any(x.get('id') in own_ids for x in issues)
        related=[b for b in bottlenecks if b['id'] in (s['id'],fid,tid)]
        over=any(b['max_excess_kw']>eps for b in related)
        station_cards.append({'id':s['id'],'name':s['name'],'region':s['region'],
            'feeder_id':fid,'transformer_id':tid,'ports':s['ports'],
            'rated_kw':s['ports']*s['charger_kw'],'shared_power_kw':s['shared_power_kw'],
            'connection_limit_kw':s['connection_limit_kw'],'peak_kw':max(site[s['id']]),
            'grid_energy_kwh':sum(site[s['id']])*.25,'sessions':len(own),
            'shortfall_kwh':deficits,'mean_wait_minutes':sum(x['wait_minutes'] for x in own)/max(1,len(own)),
            'headroom_kw':headroom,'assessment':'本工况容量或履约不合格' if over or deficits>eps or invalid else '本工况容量与履约合格',
            'evidence':'合成工况' if task['metadata']['evidence']=='synthetic' else '客户提供数据，待业务复核',
            'pending':['真实同期数据校准','公司认可运行方式与工程判据','电压及接入专项复核','控制执行与保障约定'],
            'headroom_definition':'其余站负荷保持本方案时的逐时附加功率空间，不代表独立可承诺容量，不可跨站求和'})
    grid_energy=sum(sum(c) for c in site.values())*.25
    cost=sum(sum(c[t] for c in site.values())*task['price_cny_kwh'][t]*.25 for t in range(n))
    peak=max(sum(c[t] for c in site.values()) for t in range(n))
    return {'feasible':not issues,'issues':issues,'shortfall_kwh':shortfall,
        'required_kwh':sum(s['required_kwh'] for s in rows),'delivered_kwh':delivered,
        'grid_energy_kwh':grid_energy,'charging_loss_kwh':grid_energy-delivered,
        'operator_energy_cost_cny':cost,'utility_investment_cny':task.get('investment',{}).get('utility_cny'),
        'user_investment_cny':task.get('investment',{}).get('user_cny'),
        'service_rate':served/max(1,len(rows)),'mean_wait_minutes':queue/max(1,len(rows)),
        'charging_peak_kw':peak,'simultaneity':peak/max(1,sum(max(c) for c in site.values())),
        'stations':station_cards,'assets':bottlenecks,'sessions':sessions,
        'station_power_kw':site,'feeder_power_kw':feeder,'transformer_power_kw':transformer,
        'energy_balance_error_kwh':abs(grid_energy*task['charging_efficiency']-delivered),
        'grid_check_scope':'有功容量边界；交流潮流、电能质量及保护专项分别核查',
        'period_hours':n*.25,'annualized':False}
