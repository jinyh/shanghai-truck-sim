"""Engineering admission audit. Does not fabricate RSI/model experiments."""
from __future__ import annotations
from .demo import make_demo
from .analysis import run


def admission():
    records=[]
    for stress in ('normal','bunched','early','derated','control_loss'):
        raw=make_demo(2027,'medium','ordered',stress,seed=17,days=1)
        for method in ('deadline','optimized'):
            r=run(raw,method);m=r['metrics']
            records.append({'group_id':f'development-{stress}','stress':stress,'method':method,
                'feasible':m['feasible'],'shortfall_kwh':m['shortfall_kwh'],
                'cost_cny':m['operator_energy_cost_cny'],'solver_calls':r['solution']['solver_calls'],
                'solver_status':r['solution']['status'],'input_hash':r['input_hash']})
    return {'status':'engineering_admission_only','records':records,'model_calls':0,'promotions':0,
        'rsi_benefit_proven':False,'final_test_evaluated':False,
        'decision':'已运行工程基线筛查。固定接枪与已知需求问题由LP求解；尚未证明存在超出工程优化的RSI改进空间。',
        'protocol':{'development_seeds':[17],'validation_seeds':[29],'heldout_seeds':[43],
            'split_unit':'母场景/供电区域；仅改变随机种子不足以证明跨站泛化',
            'arms':['成熟工程基线','固定流程＋共同历史','更新F＋固定G','更新F/G','每轮重置'],
            'fixed':['物理模型','服务要求','评分器','独立测试','各组总预算'],
            'not_executed':['模型提案','F/G更新及晋升','独立最终测试'],
            'entry_rule':'先确认真实业务下存在有用的工具选择、诊断或验证成本差异，再冻结模型预算和试验协议'}}
