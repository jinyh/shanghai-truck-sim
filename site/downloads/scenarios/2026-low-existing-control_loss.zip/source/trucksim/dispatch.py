"""Deterministic engineering baselines, with explicit charging shortfall."""
from __future__ import annotations

import time
import numpy as np
from scipy.optimize import linprog
from scipy.sparse import coo_matrix, vstack

from .model import reserve_ports


def build_problem(task, reservations):
    n = task['periods']
    dt_eta = task['charging_efficiency']*.25
    stations = {s['id']: s for s in task['stations']}
    feeders = {f['id']: f for f in task['feeders']}
    variables, by_session, by_station, by_feeder, by_transformer = [], {}, {}, {}, {}
    for i, session in enumerate(reservations):
        by_session[i] = []
        sid = session['station_id']; fid = stations[sid]['feeder_id']; tid = feeders[fid]['transformer_id']
        for t in range(session['connected_step'], session['departure_step']):
            j = len(variables); variables.append((i, t))
            by_session[i].append(j)
            for mapping, key in [(by_station, sid), (by_feeder, fid), (by_transformer, tid)]:
                mapping.setdefault((key, t), []).append(j)
    nv = len(variables); total = nv+len(reservations)
    row, col, vals, rhs = [], [], [], []
    def constraint(entries, bound):
        r = len(rhs)
        for j, v in entries:
            row.append(r); col.append(j); vals.append(v)
        rhs.append(bound)
    for i, s in enumerate(reservations):
        constraint([(j, -dt_eta) for j in by_session[i]] + [(nv+i, -1)], -s['required_kwh'])
        constraint([(j, dt_eta) for j in by_session[i]], s['required_kwh'])
    for s in task['stations']:
        for t in range(n):
            constraint([(j, 1) for j in by_station.get((s['id'], t), [])], s['limit_kw'][t])
    for f in task['feeders']:
        for t in range(n):
            headroom = f['limit_kw'][t]-f['net_background_kw'][t]-f['committed_kw'][t]
            constraint([(j, 1) for j in by_feeder.get((f['id'], t), [])], max(0, headroom))
    for tr in task['transformers']:
        children = [f for f in task['feeders'] if f['transformer_id'] == tr['id']]
        for t in range(n):
            base = tr['net_background_kw'][t]+tr['committed_kw'][t]+sum(f['net_background_kw'][t]+f['committed_kw'][t] for f in children)
            constraint([(j, 1) for j in by_transformer.get((tr['id'], t), [])], max(0, tr['limit_kw'][t]-base))
    bounds = [(0, reservations[i]['power_limit_kw']) for i, t in variables] + [(0, s['required_kwh']) for s in reservations]
    # Uncontrolled stations follow the same immutable first-come charging requests.
    uncontrolled = rule(task, reservations, respect_grid=False)['power_by_session']
    for j, (i, t) in enumerate(variables):
        if not stations[reservations[i]['station_id']]['controllable']:
            p = uncontrolled[reservations[i]['id']][t]
            bounds[j] = (p, p)
    matrix = coo_matrix((vals, (row, col)), shape=(len(rhs), total)).tocsr()
    return variables, matrix, np.array(rhs), bounds, by_feeder


def rule(task, reservations=None, respect_grid=False):
    rs = reservations if reservations is not None else reserve_ports(task)
    n = task['periods']; eta_dt = task['charging_efficiency']*.25
    stations = {s['id']: s for s in task['stations']}
    feeders = {f['id']: f for f in task['feeders']}
    power = {s['id']: [0.]*n for s in rs}
    remaining = {s['id']: s['required_kwh'] for s in rs}
    fixed = rule(task, rs, False)['power_by_session'] if respect_grid and any(not s['controllable'] for s in task['stations']) else {}
    for t in range(n):
        site_room = {s['id']: s['limit_kw'][t] for s in task['stations']}
        feeder_room = {f['id']: max(0, f['limit_kw'][t]-f['net_background_kw'][t]-f['committed_kw'][t]) for f in task['feeders']}
        transformer_room = {tr['id']: max(0, tr['limit_kw'][t]-tr['net_background_kw'][t]-tr['committed_kw'][t]-sum(f['net_background_kw'][t]+f['committed_kw'][t] for f in task['feeders'] if f['transformer_id']==tr['id'])) for tr in task['transformers']}
        active = [s for s in rs if s['connected_step']<=t<s['departure_step']]
        active.sort(key=lambda s: (stations[s['station_id']]['controllable'] if respect_grid else False,
                                  s['departure_step'] if respect_grid and stations[s['station_id']]['controllable'] else s['arrival_step'], s['id']))
        for s in active:
            sid=s['station_id']; fid=stations[sid]['feeder_id']; tid=feeders[fid]['transformer_id']
            caps=[s['power_limit_kw'], remaining[s['id']]/eta_dt, site_room[sid]]
            if respect_grid:
                caps.extend([feeder_room[fid], transformer_room[tid]])
            p=fixed[s['id']][t] if respect_grid and not stations[sid]['controllable'] else max(0, min(caps))
            power[s['id']][t]=p
            remaining[s['id']]-=p*eta_dt; site_room[sid]-=p
            feeder_room[fid]-=p; transformer_room[tid]-=p
    return {'method': 'deadline' if respect_grid else 'unmanaged', 'status': 'rule',
            'power_by_session': power, 'reservations': rs, 'solver_calls': 0,
            'information_mode': 'offline_known_scenario'}


def optimize(task, reservations=None, flex=None):
    started=time.perf_counter()
    rs=reservations if reservations is not None else reserve_ports(task)
    if not rs:
        result=rule(task, rs, True);result.update(method='optimized', status='empty', solver_calls=0)
        return result
    variables, matrix, rhs, bounds, by_feeder=build_problem(task, rs)
    if flex:
        # A call starting now cannot borrow pre-event charging from an alternate past.
        for j,(i,t) in enumerate(variables):
            if t < flex['start_step']:
                p=flex['baseline_power_by_session'][rs[i]['id']][t]
                bounds[j]=(p,p)
    nv=len(variables);total=len(bounds)
    c=np.zeros(total);c[nv:]=1
    options={'time_limit': 30., 'dual_feasibility_tolerance': 1e-7, 'primal_feasibility_tolerance': 1e-7}
    phase1=linprog(c, A_ub=matrix, b_ub=rhs, bounds=bounds, method='highs', options=options)
    if not phase1.success:
        fallback=rule(task, rs, all(s['controllable'] for s in task['stations']))
        fallback.update(method='optimized', status='solver_failed_fallback', solver_message=phase1.message, solver_calls=1)
        return fallback
    # Lexicographic optimization: cheap electricity must never purchase shortfall.
    minimum_shortfall=float(phase1.fun)
    if flex and minimum_shortfall>1e-5:
        return {'status':'flex_unavailable', 'reason':'原始需求无法全部交付', 'solver_calls':1}
    cap_row=coo_matrix(([1.]*len(rs), ([0]*len(rs), list(range(nv,total)))), shape=(1,total)).tocsr()
    matrix=vstack([matrix,cap_row],format='csr');rhs=np.append(rhs,max(0,minimum_shortfall)+1e-7)
    c=np.array([task['price_cny_kwh'][t]*.25+1e-8*t for i,t in variables]+[0.]*len(rs))
    if flex:
        from scipy.sparse import hstack
        matrix=hstack([matrix,coo_matrix((matrix.shape[0],1))],format='csr')
        rows=[];cols=[];vals=[];limits=[]
        direction=1 if flex['direction']=='reduce' else -1
        for t in range(flex['start_step'],flex['start_step']+flex['duration_steps']):
            r=len(limits)
            for j in by_feeder.get((flex['feeder_id'],t),[]):
                rows.append(r);cols.append(j);vals.append(direction)
            rows.append(r);cols.append(total);vals.append(1.)
            limits.append(direction*flex['baseline_station_sum_kw'][t])
        extra=coo_matrix((vals,(rows,cols)),shape=(len(limits),total+1)).tocsr()
        matrix=vstack([matrix,extra],format='csr');rhs=np.concatenate([rhs,limits])
        bounds=bounds+[(0,None)];c=np.zeros(total+1);c[-1]=-1
    phase2=linprog(c,A_ub=matrix,b_ub=rhs,bounds=bounds,method='highs',options=options)
    if flex and not phase2.success:
        return {'status':'flex_unavailable','reason':phase2.message,'solver_calls':2}
    x=phase2.x if phase2.success else phase1.x
    power={s['id']:[0.]*task['periods'] for s in rs}
    for j,(i,t) in enumerate(variables):
        power[rs[i]['id']][t]=float(max(0,x[j]))
    result={'method':'optimized','status':'optimal' if phase2.success else 'minimum_shortfall_only',
            'power_by_session':power,'reservations':rs,'solver_calls':2,
            'seconds':time.perf_counter()-started,'minimum_shortfall_kwh':minimum_shortfall,
            'information_mode':'offline_known_scenario',
            'optimality_scope':'固定接枪占用、已知完整需求和容量边界下的线性排程；不代表全局规划最优'}
    if flex:result['flex_delta_kw']=float(max(0,x[-1]))
    return result
