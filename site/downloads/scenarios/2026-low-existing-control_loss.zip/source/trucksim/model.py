"""Input contract, normalization and connection reservations (kW/kWh/minutes)."""
from __future__ import annotations

import copy
import hashlib
import json
import math
from datetime import datetime, timedelta


class InputError(ValueError):
    pass


def fingerprint(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
                                     allow_nan=False).encode()).hexdigest()


def number(value, label, minimum=0):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value < minimum:
        raise InputError(f'{label}: 需要不小于 {minimum} 的有限数值')
    return value


def series(value, n, label):
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        value = [value] * n
    if not isinstance(value, list) or len(value) != n:
        raise InputError(f'{label}: 必须包含 {n} 个连续时段，缺测不可填零')
    return [number(v, label) for v in value]


def unique(rows, label):
    if not isinstance(rows,list) or any(not isinstance(r,dict) for r in rows):
        raise InputError(f'{label}: 必须为记录数组')
    ids = [r.get('id') for r in rows]
    if not rows or any(not isinstance(x, str) or not x for x in ids) or len(ids) != len(set(ids)):
        raise InputError(f'{label}: 标识为空或重复')
    return {r['id']: r for r in rows}


def normalize(raw):
    if not isinstance(raw, dict):
        raise InputError('案例必须为 JSON 对象')
    task = copy.deepcopy(raw)
    if task.get('schema_version') != '1.0':
        raise InputError('schema_version 必须为 1.0')
    if task.get('information_mode') != 'offline_known_scenario':
        raise InputError('首版仅支持离线已知工况排程，不接受伪装为在线预测的历史实绩')
    n = task.get('periods')
    if isinstance(n, bool) or not isinstance(n, int) or not 1 <= n <= 35136:
        raise InputError('periods 必须为 1–35136 的整数')
    if task.get('step_minutes') != 15:
        raise InputError('首版时间步长固定 15 分钟')
    try:
        start = datetime.fromisoformat(task['start'])
    except (KeyError, ValueError):
        raise InputError('缺少带时区的 ISO start') from None
    if start.utcoffset() != timedelta(hours=8):
        raise InputError('场景时间必须明确使用 UTC+08:00')
    if start.minute % 15 or start.second or start.microsecond:
        raise InputError('开始时间必须对齐 15 分钟区间')
    metadata = task.get('metadata', {})
    if not isinstance(metadata,dict):raise InputError('metadata 必须为对象')
    if metadata.get('evidence') not in ('synthetic', 'customer_provided'):
        raise InputError('metadata.evidence 必须标识 synthetic 或 customer_provided')
    if not metadata.get('source') or not metadata.get('version'):
        raise InputError('必须记录数据来源与版本')
    task['price_cny_kwh'] = series(task.get('price_cny_kwh'), n, '购电价格')
    eta = number(task.get('charging_efficiency'), '充电效率', .01)
    if eta > 1:
        raise InputError('效率不能大于 1')
    stations = unique(task.get('stations', []), '场站')
    feeders = unique(task.get('feeders', []), '馈线')
    transformers = unique(task.get('transformers', []), '主变')
    if len(set(stations)|set(feeders)|set(transformers)) != len(stations)+len(feeders)+len(transformers):
        raise InputError('场站、馈线和主变标识必须全局唯一')
    for sid, s in stations.items():
        if not s.get('name') or not s.get('region'):
            raise InputError(f'{sid}: 必须提供场站名称和所属区域')
        if s.get('feeder_id') not in feeders:
            raise InputError(f'{sid}: 馈线映射缺失')
        if isinstance(s.get('ports'), bool) or not isinstance(s.get('ports'), int) or s['ports'] < 1:
            raise InputError(f'{sid}: 枪口数必须为正整数')
        for key in ('charger_kw', 'shared_power_kw', 'connection_limit_kw'):
            number(s.get(key), f'{sid}.{key}', .01)
        if not isinstance(s.get('controllable'), bool):
            raise InputError(f'{sid}: 必须明确控制权限')
        s['limit_kw'] = series(s.get('limit_kw', min(s['shared_power_kw'], s['connection_limit_kw'])), n, sid)
        s['limit_kw'] = [min(x, s['shared_power_kw'], s['connection_limit_kw']) for x in s['limit_kw']]
    for fid, f in feeders.items():
        if f.get('transformer_id') not in transformers:
            raise InputError(f'{fid}: 主变映射缺失')
    # Every measurement declares its boundary. Subtract only identified measured children.
    for rows, children, link, label in [(feeders, stations, 'feeder_id', '场站'),
                                         (transformers, feeders, 'transformer_id', '馈线')]:
        for rid, r in rows.items():
            r['limit_kw'] = series(r.get('limit_kw'), n, f'{rid}容量边界')
            r['committed_kw'] = series(r.get('committed_kw'), n, f'{rid}已承诺增量（无则明确填0）')
            base = series(r.get('background_kw'), n, f'{rid}背景负荷')
            boundary = r.get('background_boundary')
            if boundary not in ('excludes_children', 'includes_declared_children'):
                raise InputError(f'{rid}: 必须声明背景负荷是否包含所建模{label}')
            included = r.get('included_children_kw', {})
            if not isinstance(included,dict):raise InputError(f'{rid}: 分项必须为对象')
            if boundary == 'includes_declared_children':
                if not included:
                    raise InputError(f'{rid}: 含下级负荷时必须提供同期分项用于去重')
                for child, values in included.items():
                    if child not in children or children[child][link] != rid:
                        raise InputError(f'{rid}: 分项 {child} 不属于该设备')
                    base = [a-b for a, b in zip(base, series(values, n, child))]
                if min(base) < -1e-6:
                    raise InputError(f'{rid}: 分项超过总表，无法可靠分离背景负荷')
            elif included:
                raise InputError(f'{rid}: excludes_children 与提供分项相冲突')
            r['net_background_kw'] = [max(0, v) for v in base]
    sessions = task.get('sessions', [])
    if not isinstance(sessions,list) or any(not isinstance(s,dict) for s in sessions):
        raise InputError('sessions 必须为记录数组')
    if len(sessions) > 20000:
        raise InputError('单案例会话超过首版上限 20000')
    if len(sessions)*n > 5_000_000:
        raise InputError('单案例会话×时段超过首版500万上限；请按供电区域与完整车辆窗口分批，跨期状态不得丢弃')
    if sessions:
        unique(sessions, '充电会话')
    for s in sessions:
        if s.get('station_id') not in stations:
            raise InputError(f"{s['id']}: 场站映射缺失")
        for key in ('arrival_step', 'departure_step'):
            if isinstance(s.get(key), bool) or not isinstance(s.get(key), int):
                raise InputError(f"{s['id']}.{key}: 必须为整数时段")
        if not 0 <= s['arrival_step'] < s['departure_step'] <= n:
            raise InputError(f"{s['id']}: 到离站窗口无效或超出评价期；跨界需求须纳入完整窗口")
        number(s.get('required_kwh'), '最低电量', .001)
        number(s.get('max_power_kw'), '车辆充电功率', .001)
    if not isinstance(task.get('investment',{}),dict):raise InputError('investment 必须为对象')
    for key, value in task.get('investment', {}).items():
        if key in ('utility_cny', 'user_cny') and value is not None:
            number(value, key)
    task['timestamps'] = [(start + timedelta(minutes=15*i)).isoformat() for i in range(n)]
    task['input_hash'] = fingerprint(raw)
    return task


def reserve_ports(task):
    """FCFS reservations: vehicles remain connected until declared departure.

    Reservations are identical across policies. Queueing is modeled explicitly;
    moving charged vehicles early is not assumed without an operational rule.
    """
    stations = {s['id']: s for s in task['stations']}
    available = {sid: [0]*s['ports'] for sid, s in stations.items()}
    result = []
    for s in sorted(task['sessions'], key=lambda x: (x['arrival_step'], x['id'])):
        row = dict(s)
        slots = available[s['station_id']]
        port = min(range(len(slots)), key=lambda i: (slots[i], i))
        connected = max(s['arrival_step'], slots[port])
        row['connected_step'] = min(connected, s['departure_step'])
        row['port'] = port
        row['wait_minutes'] = (row['connected_step']-s['arrival_step'])*15
        row['power_limit_kw'] = min(s['max_power_kw'], stations[s['station_id']]['charger_kw'])
        if connected < s['departure_step']:
            slots[port] = s['departure_step']
        result.append(row)
    return result
