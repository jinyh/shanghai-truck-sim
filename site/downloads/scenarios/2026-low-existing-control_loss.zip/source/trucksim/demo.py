"""Registered synthetic cases. No station or grid geometry is represented as real."""
from __future__ import annotations
import math
import random

GROWTH={'low':1.06,'medium':1.13,'high':1.20}
PLANS={
    'existing': {'name':'现状配置 · 常规充电','method':'unmanaged'},
    'ordered': {'name':'现状配置 · 有序充电','method':'optimized'},
    'phased': {'name':'分期增容 · 有序充电','method':'optimized'},
    'expanded': {'name':'提前扩建 · 有序充电','method':'optimized'},
    'alternate': {'name':'备选电源路径 · 有序充电','method':'optimized'},
}


def make_demo(year=2027, growth='medium', plan='ordered', stress='normal', seed=42, days=3):
    if year not in range(2026,2031) or growth not in GROWTH or plan not in PLANS:
        raise ValueError('不支持的年份、增长或方案')
    if stress not in ('normal','bunched','early','derated','control_loss'):
        raise ValueError('不支持的压力工况')
    n=days*96;factor=GROWTH[growth]**(year-2026)
    h=[(t%96)/4 for t in range(n)]
    price=[.38 if x<7 or x>=22 else 1.12 if 8<=x<11 or 18<=x<22 else .68 for x in h]
    upgrades=(plan=='expanded' and year>=2027) or (plan=='phased' and year>=2029)
    alternate=plan=='alternate' and year>=2027
    stations=[]
    labels=[('港区 A','港口短倒'),('港区 B','港口短倒'),('园区 A','物流园区'),('园区 B','物流园区'),('通道 A','公共补能'),('通道 B','公共补能')]
    for i,(name,kind) in enumerate(labels):
        fid=f'F{i//2+1}'
        if alternate and i==3:fid='F3'
        stations.append({'id':f'S{i+1}','name':name+'（示范）','region':kind,
            'feeder_id':fid,'ports':6 if upgrades else 4,'charger_kw':320,
            'shared_power_kw':1600 if upgrades else 960,'connection_limit_kw':1400 if upgrades else 850,
            'controllable':stress!='control_loss','status':'示范候选配置','coordinate_status':'无真实坐标'})
    feeders=[]
    for i in range(3):
        bg=[(660+140*math.cos((x-21)*math.pi/12)+70*math.sin((x-9)*math.pi/6))*(1+.035*(year-2026)) for x in h]
        limit=[(2100 if upgrades else 1450)+(100 if i==2 else 0)]*n
        if stress=='derated':
            for t in range(n):
                if 19<=h[t]<23:limit[t]*=.7
        feeders.append({'id':f'F{i+1}','name':f'示范馈线 {i+1}','transformer_id':'T1' if i<2 else 'T2',
            'limit_kw':limit,'background_kw':bg,'background_boundary':'excludes_children',
            'committed_kw':[80+25*(year-2026)]*n})
    transformers=[]
    for i in range(2):
        transformers.append({'id':f'T{i+1}','name':f'示范主变 {i+1}',
            'limit_kw':(4700 if i==0 else 2900) if upgrades else (3400 if i==0 else 2300),
            'background_kw':[380+50*math.cos((x-14)*math.pi/12) for x in h],
            'background_boundary':'excludes_children','committed_kw':80+20*(year-2026)})
    sessions=[]
    for day in range(days):
        for i,s in enumerate(stations):
            for batch, hour in enumerate([1,7,13,18]):
                # Stable per-batch demand makes years nested and plans comparable.
                count_rng=random.Random(f'{seed}-{day}-{i}-{batch}-count')
                count=math.floor(5*factor)+(count_rng.random()<5*factor%1)
                for j in range(count):
                    arrival=day*96+hour*4+(j//3 if stress=='bunched' else j)
                    stay=8 if stress=='early' else 14
                    departure=arrival+stay
                    energy_rng=random.Random(f'{seed}-{day}-{i}-{batch}-{j}-energy')
                    sessions.append({'id':f'D{day}-S{i}-B{batch}-V{j}', 'station_id':s['id'],
                        'arrival_step':arrival,'departure_step':departure,'required_kwh':float(energy_rng.choice([160,200,240,280])),
                        'max_power_kw':280.,'deadline_source':'合成已知出车要求','known_at_step':0})
    utility=0;user=0;projects=[]
    if upgrades:
        commissioning=2027 if plan=='expanded' else 2029
        for f in feeders:
            projects.append({'id':'UP-'+f['id'],'asset_id':f['id'],'name':f['name']+'增容','commission_year':commissioning,
                'lead_months':18,'latest_start':f'{commissioning-2}-07','utility_cny':1800000,'user_cny':0,
                'cost_basis':'合成工程估算假设','trigger':'该年度代表工况下现状边界或服务不满足；须结合完整工况复核'})
        for t in transformers:
            projects.append({'id':'UP-'+t['id'],'asset_id':t['id'],'name':t['name']+'增容','commission_year':commissioning,
                'lead_months':24,'latest_start':f'{commissioning-2}-01','utility_cny':3200000,'user_cny':0,
                'cost_basis':'合成工程估算假设','trigger':'共享容量联合校核'})
        utility=11800000;user=6*450000
    elif alternate:
        utility=900000;user=350000
        projects=[{'id':'ALT-S4','asset_id':'S4','name':'园区 B 备选馈线路径','commission_year':2027,'lead_months':12,
                   'latest_start':'2026-01','utility_cny':utility,'user_cny':user,'cost_basis':'合成路径及造价假设',
                   'trigger':'示范可达关系；真实廊道与供电方案未确认'}]
    return {'schema_version':'1.0','id':f'demo-{year}-{growth}-{plan}-{stress}-{seed}',
        'title':'上海重卡接入与配套电网规划 · 合成示范',
        'metadata':{'evidence':'synthetic','source':'本地上海项目报告用于业务任务定义；全部数值场景由登记假设生成',
            'version':'demo-v1.1','seed':seed,'year':year,'growth':growth,'plan':plan,'stress':stress,
            'source_documents':['上海重卡接入与可调能力评估及规划咨询项目_修订建议稿_20261009.md',
                '上海货运重卡充电桩站点近期建设规划研究-0623-发.pdf'],
            'assumptions':['六个站点与电气连接均为合成，不对应正式25站清单',
                '320kW终端为材料中的设备量级，其余容量、背景负荷、电价和造价均为仿真假设',
                '全部需求及压力工况在离线求解前已知，不是在线预测',
                '接枪后占用车位至发车；固定先到先接，未优化移车或线路',
                '工程评价以容量边界为主，演示交流网络另行校核，不代表上海真实网架',
                '工程假设1月投产并已按倒排节点启动；实际启动进展、廊道、审批和工期尚未核实',
                '三天不是代表全年抽样，电量、费用和越限小时均不年化'],
            'growth_assumption':f'车辆数相对2026按每年 {(GROWTH[growth]-1)*100:.0f}% 增长；背景负荷另行增长'},
        'information_mode':'offline_known_scenario','start':f'{year}-06-15T00:00:00+08:00',
        'periods':n,'step_minutes':15,'charging_efficiency':.95,'price_cny_kwh':price,
        'stations':stations,'feeders':feeders,'transformers':transformers,'sessions':sessions,
        'investment':{'utility_cny':utility,'user_cny':user,'basis':'合成估算；累计建成投资，非投资节省'},
        'projects':projects,'network':{'kind':'synthetic_radial','power_factor':.97,
            'voltage_min_pu':.95,'voltage_max_pu':1.05,'loading_max_pct':100.,
            'criteria_approved':False,'source':'演示等值模型，非上海真实线路'}}
