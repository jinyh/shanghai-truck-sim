"""Optional full-window AC check of the registered synthetic equivalent network."""
from __future__ import annotations
import math
import warnings


def audit_ac(task, metrics):
    spec=task.get('network',{})
    if spec.get('kind')!='synthetic_radial' or task['metadata']['evidence']!='synthetic':
        return {'status':'unavailable','reason':'客户网络需经认可的模型适配和校准；当前仅实现合成等值网络校核'}
    import pandapower as pp
    net=pp.create_empty_network()
    high=pp.create_bus(net,vn_kv=110);pp.create_ext_grid(net,high,vm_pu=1.02)
    tbus={};fbus={};loads={};feeder_loads={};transformer_loads={}
    for t in task['transformers']:
        b=pp.create_bus(net,vn_kv=10,name=t['id']);tbus[t['id']]=b
        pp.create_transformer_from_parameters(net,high,b,sn_mva=max(t['limit_kw'])/1000/.9,
            vn_hv_kv=110,vn_lv_kv=10,vkr_percent=.5,vk_percent=8,pfe_kw=8,i0_percent=.1,name=t['id'])
        transformer_loads[t['id']]=pp.create_load(net,b,p_mw=0)
    for i,f in enumerate(task['feeders']):
        b=pp.create_bus(net,vn_kv=10,name=f['id']);fbus[f['id']]=b
        pp.create_line_from_parameters(net,tbus[f['transformer_id']],b,length_km=2+i*.5,
            r_ohm_per_km=.2,x_ohm_per_km=.12,c_nf_per_km=200,
            max_i_ka=max(f['limit_kw'])/1000/(math.sqrt(3)*10*.97),name=f['id'])
        feeder_loads[f['id']]=pp.create_load(net,b,p_mw=0)
    for s in task['stations']:loads[s['id']]=pp.create_load(net,fbus[s['feeder_id']],p_mw=0,name=s['id'])
    phi=math.tan(math.acos(spec['power_factor']))
    trace=[];failures=[];violations=[]
    def setload(idx,kw):net.load.loc[idx,['p_mw','q_mvar']]=[kw/1000,kw/1000*phi]
    for step in range(task['periods']):
        for s in task['stations']:setload(loads[s['id']],metrics['station_power_kw'][s['id']][step])
        for f in task['feeders']:setload(feeder_loads[f['id']],f['net_background_kw'][step]+f['committed_kw'][step])
        for t in task['transformers']:setload(transformer_loads[t['id']],t['net_background_kw'][step]+t['committed_kw'][step])
        try:
            with warnings.catch_warnings():
                warnings.simplefilter('ignore')
                pp.runpp(net,numba=False,init='results' if step and net.converged else 'auto',max_iteration=25)
            vmin=float(net.res_bus.vm_pu.min());vmax=float(net.res_bus.vm_pu.max())
            load=max(float(net.res_line.loading_percent.max()),float(net.res_trafo.loading_percent.max()))
            if not net.converged or not all(math.isfinite(x) for x in [vmin,vmax,load]):raise ValueError('潮流未收敛')
            passed=vmin>=spec['voltage_min_pu'] and vmax<=spec['voltage_max_pu'] and load<=spec['loading_max_pct']+1e-6
            for idx,row in net.res_bus.iterrows():
                if not spec['voltage_min_pu']<=row.vm_pu<=spec['voltage_max_pu']:
                    violations.append({'step':step,'kind':'voltage','asset_id':str(net.bus.loc[idx,'name'] or 'source'),
                        'value':float(row.vm_pu),'unit':'pu'})
            for kind,table,assets in [('line',net.res_line,net.line),('transformer',net.res_trafo,net.trafo)]:
                for idx,row in table.iterrows():
                    if row.loading_percent>spec['loading_max_pct']+1e-6:
                        violations.append({'step':step,'kind':kind+'_loading','asset_id':str(assets.loc[idx,'name']),
                            'value':float(row.loading_percent),'unit':'%'})
            trace.append({'step':step,'v_min_pu':vmin,'v_max_pu':vmax,'max_loading_pct':load,'passed':passed,
                          'loss_kw':float(net.res_line.pl_mw.sum()+net.res_trafo.pl_mw.sum())*1000})
        except Exception as exc:
            failures.append({'step':step,'reason':str(exc)});trace.append({'step':step,'passed':False})
    return {'status':'completed','passed':all(r['passed'] for r in trace),'steps_checked':len(trace),
            'failed_steps':sum(not r['passed'] for r in trace),'trace':trace,'failures':failures,'violations':violations,
            'criteria_approved':False,'scope':'合成等值网络完整时窗交流潮流；不含短路、保护、谐波及事故组合',
            'voltage_min_pu':spec['voltage_min_pu'],'voltage_max_pu':spec['voltage_max_pu']}
