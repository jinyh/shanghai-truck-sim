"""Connected run, flexibility, planning comparisons and calibration metrics."""
from __future__ import annotations
import time
from .audit import evaluate
from .dispatch import optimize, rule
from .model import normalize, fingerprint
from .demo import make_demo, PLANS


def run(raw, method='optimized', include_ac=False):
    started=time.perf_counter();task=normalize(raw)
    if method not in ('unmanaged','deadline','optimized'):
        raise ValueError('不支持的调度方法')
    solution=optimize(task) if method=='optimized' else rule(task,respect_grid=method=='deadline')
    metrics=evaluate(task,solution)
    result={'schema_version':'1.0','job_id':fingerprint({'input':raw,'method':method,'ac':include_ac})[:16],
            'task':raw,'method':method,'input_hash':task['input_hash'],'timestamps':task['timestamps'],
            'solution':solution,'metrics':metrics,'ac':{'status':'not_run','reason':'未执行交流潮流校核'},
            'evidence_level':'synthetic' if raw['metadata']['evidence']=='synthetic' else 'customer_unvalidated',
            'seconds':0,'formal_connection_approval':False}
    if include_ac:
        from .network import audit_ac
        result['ac']=audit_ac(task,metrics)
    result['seconds']=time.perf_counter()-started
    return result


def flexibility(result, feeder_id=None, start_step=None, duration_steps=4):
    task=normalize(result['task']);metrics=result['metrics']
    if not metrics['feasible']:
        return {'status':'unavailable','reason':'基准方案须先满足全部容量和车辆需求','evidence':'未验证'}
    feeder_id=feeder_id or task['feeders'][0]['id']
    if feeder_id not in {f['id'] for f in task['feeders']}:
        raise ValueError('馈线标识不存在')
    if not isinstance(duration_steps,int) or isinstance(duration_steps,bool) or not 1<=duration_steps<=task['periods']:
        raise ValueError('调用时长无效')
    curves=[metrics['station_power_kw'][s['id']] for s in task['stations'] if s['feeder_id']==feeder_id]
    baseline=[sum(c[t] for c in curves) for t in range(task['periods'])]
    if start_step is None:
        start_step=max(range(task['periods']-duration_steps+1),key=lambda t:sum(baseline[t:t+duration_steps]))
    if isinstance(start_step,bool) or not isinstance(start_step,int) or not 0<=start_step<=task['periods']-duration_steps:
        raise ValueError('调用时段超出评价窗口')
    output={'status':'calculated','feeder_id':feeder_id,'start_step':start_step,'duration_minutes':duration_steps*15,
            'evidence':'离线技术潜力；未经过现场执行验证','available_probability':None,
            'planning_credit_kw':None,'reference_job_id':result['job_id'],'directions':{}}
    for direction in ('reduce','increase'):
        spec={'feeder_id':feeder_id,'start_step':start_step,'duration_steps':duration_steps,
              'direction':direction,'baseline_station_sum_kw':baseline}
        spec['baseline_power_by_session']=result['solution']['power_by_session']
        sol=optimize(task,flex=spec)
        if sol['status']=='flex_unavailable':output['directions'][direction]=sol;continue
        checked=evaluate(task,sol)
        altered=[sum(checked['station_power_kw'][s['id']][t] for s in task['stations'] if s['feeder_id']==feeder_id) for t in range(task['periods'])]
        diffs=[b-a if direction=='reduce' else a-b for a,b in zip(altered,baseline)]
        after=start_step+duration_steps
        output['directions'][direction]={'delta_kw':sol['flex_delta_kw'],'feasible':checked['feasible'],
            'verified_min_delta_kw':min(diffs[start_step:after]),
            'rebound_peak_kw':max([0.]+[altered[t]-baseline[t] for t in range(after,task['periods'])]),
            'post_event_energy_change_kwh':sum(altered[t]-baseline[t] for t in range(after,task['periods']))*.25,
            'pre_event_energy_change_kwh':sum(altered[t]-baseline[t] for t in range(start_step))*.25,
            'full_period_energy_change_kwh':sum(altered[t]-baseline[t] for t in range(task['periods']))*.25,
            'curve_kw':altered,'baseline_kw':baseline,'shortfall_kwh':checked['shortfall_kwh'],
            'solver_calls':sol['solver_calls']}
    return output


def planning(growth='medium',stress='normal',seed=42):
    rows=[];calls=0;projects={};time_series=[];started=time.perf_counter()
    for year in range(2027,2031):
        for plan in PLANS:
            result=run(make_demo(year,growth,plan,stress,seed),PLANS[plan]['method'])
            m=result['metrics'];calls+=result['solution']['solver_calls']
            worst=max([a for a in m['assets'] if a['type']!='station'],key=lambda a:a['max_loading_pct'])
            rows.append({'year':year,'plan':plan,'name':PLANS[plan]['name'],'feasible':m['feasible'],
                'shortfall_kwh':m['shortfall_kwh'],'operator_energy_cost_cny':m['operator_energy_cost_cny'],
                'utility_investment_cny':m['utility_investment_cny'],'user_investment_cny':m['user_investment_cny'],
                'charging_peak_kw':m['charging_peak_kw'],'grid_energy_kwh':m['grid_energy_kwh'],
                'worst_asset':worst['name'],'worst_loading_pct':worst['max_loading_pct'],
                'grid_violation_hours':sum(a['violation_hours'] for a in m['assets'] if a['type']=='feeder'),
                'period_hours':m['period_hours'],'job_id':result['job_id']})
            time_series.append({'year':year,'plan':plan,'input_hash':result['input_hash'],
                'timestamps':result['timestamps'],'station_power_kw':m['station_power_kw'],
                'feeder_power_kw':m['feeder_power_kw'],'transformer_power_kw':m['transformer_power_kw']})
            for p in result['task']['projects']:projects[(plan,p['id'])]={**p,'plan':plan}
    summaries=[]
    for plan in PLANS:
        subset=[r for r in rows if r['plan']==plan]
        summaries.append({'plan':plan,'name':PLANS[plan]['name'],'all_years_feasible':all(r['feasible'] for r in subset),
            'first_failure_year':next((r['year'] for r in subset if not r['feasible']),None),
            'utility_investment_cny':max(r['utility_investment_cny'] for r in subset),
            'user_investment_cny':max(r['user_investment_cny'] for r in subset)})
    feasible=sorted([s for s in summaries if s['all_years_feasible']],key=lambda s:s['utility_investment_cny'])
    return {'rows':rows,'plans':summaries,'projects':list(projects.values()),'time_series':time_series,'growth':growth,'stress':stress,'seed':seed,
        'capacity_screening_candidate':feasible[0]['plan'] if feasible else None,'suggested_plan':None,
        'engineering_review_pending':True,
        'recommendation_scope':'仅做指定增长与代表工况下的容量和履约初筛；逐年交流潮流及工程专项尚未完成，不形成接入推荐。投资比较限定于已枚举方案，非全局规划最优',
        'annualized':False,'annual_energy_kwh':None,'deferral_benefit_cny':None,
        'seconds':time.perf_counter()-started,'solver_calls':calls,'evidence':'synthetic'}


def calibration(actual, predicted, step_minutes=15):
    if len(actual)!=len(predicted) or not actual:
        raise ValueError('实测与预测需同长且非空')
    import math
    if any(isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) or v<0 for v in actual+predicted):
        raise ValueError('缺测、非法值或负功率不能参与校准')
    n=len(actual);ap=max(actual);pp=max(predicted)
    return {'mae_kw':sum(abs(a-p) for a,p in zip(actual,predicted))/n,
        'rmse_kw':math.sqrt(sum((a-p)**2 for a,p in zip(actual,predicted))/n),
        'actual_peak_kw':ap,'predicted_peak_kw':pp,'peak_error_kw':pp-ap,
        'peak_time_error_minutes':(predicted.index(pp)-actual.index(ap))*step_minutes,
        'energy_error_kwh':sum(p-a for a,p in zip(actual,predicted))*step_minutes/60,
        'sample_count':n,'scope':'调用者提供的同一独立时期；未自动推断训练/测试隔离'}
