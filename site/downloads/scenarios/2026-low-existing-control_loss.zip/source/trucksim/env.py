"""Budgeted offline environment. Reference solutions never enter observations."""
from __future__ import annotations
import copy
from .model import normalize, fingerprint
from .audit import evaluate


class TruckPlanningEnv:
    def __init__(self,check_budget=10):
        if isinstance(check_budget,bool) or not isinstance(check_budget,int) or check_budget<1:raise ValueError("检查预算必须为正整数")
        self.budget=check_budget

    def reset(self,task):
        self.task=normalize(task);self.raw=copy.deepcopy(task);self.used=0;self.done=False;self.history=[]
        return self.get_situation()

    def get_situation(self):
        return {'task':copy.deepcopy(self.raw),'remaining_checks':self.budget-self.used,
                'information_mode':'offline_known_scenario','instructions':'提交每会话每15分钟的电网侧充电功率；不能修改物理约束。'}

    def check_plan(self,power_by_session):
        if self.done:raise ValueError('该任务已提交')
        if self.used>=self.budget:raise ValueError('检查预算已耗尽')
        self.used+=1
        result=evaluate(self.task,{'power_by_session':power_by_session})
        record={k:result[k] for k in ('feasible','issues','shortfall_kwh','operator_energy_cost_cny','energy_balance_error_kwh')}
        self.history.append({'query':self.used,'plan_hash':fingerprint(power_by_session),'result':record})
        return record

    def submit_plan(self,power_by_session):
        if self.done:raise ValueError('该任务已提交')
        checked=evaluate(self.task,{'power_by_session':power_by_session});self.done=True
        return {'feasible':checked['feasible'],'metrics':checked,'queries':self.used,
                'evaluation':'先判断容量与服务合格，再比较相同任务的成本和查询开销；不使用LLM评分'}
