"""Recompute full trajectories and check exported source integrity."""
import hashlib
import json
from pathlib import Path
from .analysis import run,planning
from .io import ROOT


def reproduce(folder):
    folder=Path(folder)
    expected=json.loads((folder/'source_manifest.json').read_text())
    source_ok=True;running_source_ok=True
    for name,digest in expected.items():
        relative=Path(name)
        if relative.is_absolute() or '..' in relative.parts or relative.parts[0]!='source':
            raise ValueError('非法源文件清单路径')
        exported=folder/relative
        source_ok &= exported.is_file() and hashlib.sha256(exported.read_bytes()).hexdigest()==digest
        current=ROOT/Path(*relative.parts[1:])
        running_source_ok &= current.is_file() and hashlib.sha256(current.read_bytes()).hexdigest()==digest
    if (folder/'analysis.json').exists():
        saved=json.loads((folder/'analysis.json').read_text());old=saved['result']
        if saved['kind']=='planning':new=planning(old['growth'],old['stress'],old['seed'])
        elif saved['kind']=='research':
            from .research import admission
            new=admission()
        else:raise ValueError('不支持的比较类型')
        def stable(value):
            if isinstance(value,dict):return {k:stable(v) for k,v in value.items() if k not in ('seconds','elapsed_seconds')}
            if isinstance(value,list):return [stable(x) for x in value]
            return value
        agrees=stable(old)==stable(new)
        return {'passed':bool(source_ok and running_source_ok and agrees),'source_integrity':bool(source_ok),
            'running_source_matches':bool(running_source_ok),'complete_comparison_matches':agrees}
    old=json.loads((folder/'result.json').read_text())
    raw=json.loads((folder/'task.json').read_text())
    new=run(raw,old['method'],old['ac']['status']=='completed')
    differences={k:abs(new['metrics'][k]-old['metrics'][k]) for k in ('shortfall_kwh','grid_energy_kwh','charging_peak_kw','operator_energy_cost_cny')}
    trajectories_ok=set(new['solution']['power_by_session'])==set(old['solution']['power_by_session'])
    max_trajectory_error=0.
    for key,values in new['solution']['power_by_session'].items():
        previous=old['solution']['power_by_session'].get(key,[])
        if len(values)!=len(previous):trajectories_ok=False;continue
        max_trajectory_error=max(max_trajectory_error,max([0.]+[abs(a-b) for a,b in zip(values,previous)]))
    trajectories_ok &= max_trajectory_error<1e-4
    ac_ok=new['ac']['status']==old['ac']['status'] and new['ac'].get('passed')==old['ac'].get('passed')
    if new['ac']['status']=='completed':
        ac_ok &= new['ac']['steps_checked']==old['ac']['steps_checked'] and new['ac']['failed_steps']==old['ac']['failed_steps']
    passed=source_ok and running_source_ok and trajectories_ok and ac_ok and all(v<1e-4 for v in differences.values()) and old['input_hash']==new['input_hash'] and old['metrics']['feasible']==new['metrics']['feasible']
    return {'passed':bool(passed),'source_integrity':bool(source_ok),'running_source_matches':bool(running_source_ok),
            'differences':differences,'maximum_trajectory_error_kw':max_trajectory_error,'ac_agrees':bool(ac_ok),'input_hash':new['input_hash']}
