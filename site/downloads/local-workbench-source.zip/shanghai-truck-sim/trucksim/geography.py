"""Versioned OSM road graph; routes are scenarios, never legal navigation advice."""
from __future__ import annotations

import heapq
import math

from .model import InputError


def distance_km(a, b):
    lon1, lat1, lon2, lat2 = map(math.radians, (*a, *b))
    h = math.sin((lat2-lat1)/2)**2 + math.cos(lat1)*math.cos(lat2)*math.sin((lon2-lon1)/2)**2
    return 6371.0088*2*math.asin(min(1, math.sqrt(h)))


def nearest_node(geo, coordinate):
    return min(geo['nodes'], key=lambda n: distance_km(geo['nodes'][n], coordinate))


def route(geo, origin, destination, vehicle=None):
    vehicle = vehicle or {'weight_t': 40, 'height_m': 4.0}
    if origin not in geo['nodes'] or destination not in geo['nodes']:
        return {'status': 'unreachable', 'reason': '起终点不在登记路网内'}
    adjacency = {}
    for edge in geo['edges']:
        if edge.get('hgv') == 'no' or edge.get('access') in ('no', 'private'):
            continue
        if edge.get('maxweight_t') is not None and vehicle['weight_t'] > edge['maxweight_t']:
            continue
        if edge.get('maxheight_m') is not None and vehicle['height_m'] > edge['maxheight_m']:
            continue
        # Destination-only access is restricted to the first/last link.
        if edge.get('hgv') in ('destination', 'delivery') and origin != edge['u'] and destination != edge['v']:
            continue
        adjacency.setdefault(edge['u'], []).append(edge)
    restrictions = {}
    for row in geo.get('turn_restrictions', []):
        restrictions.setdefault((row['via'], row['from_way']), []).append(row)
    start = (origin, '')
    costs = {start: 0.0}; previous = {}; queue = [(0.0, *start)]; end = None
    while queue:
        cost, node, way = heapq.heappop(queue)
        state = (node, way)
        if cost > costs[state] + 1e-9:
            continue
        if node == destination:
            end = state; break
        for edge in adjacency.get(node, []):
            blocked = any((r['kind'].startswith('no_') and edge['way'] == r['to_way']) or
                          (r['kind'].startswith('only_') and edge['way'] != r['to_way'])
                          for r in restrictions.get((node, way), []))
            if blocked:
                continue
            nxt = (edge['v'], edge['way']); value = cost + edge['minutes']
            if value < costs.get(nxt, float('inf')):
                costs[nxt] = value; previous[nxt] = (state, edge)
                heapq.heappush(queue, (value, *nxt))
    if end is None:
        return {'status': 'unreachable', 'reason': '在登记方向、限行及车辆尺寸约束下不可达'}
    edges = []; cursor = end
    while cursor != start:
        cursor, edge = previous[cursor]; edges.append(edge)
    edges.reverse()
    unknown = sorted({flag for e in edges for flag in e.get('unknown', [])})
    return {'status': 'routed', 'nodes': [origin]+[e['v'] for e in edges],
            'distance_km': sum(e['km'] for e in edges), 'minutes': costs[end],
            'unknown_restrictions': unknown, 'ways': list(dict.fromkeys(e['way'] for e in edges)),
            'evidence': '公开道路几何；车速与未核实通行条件为情景假设'}


def validate_spatial(spatial):
    if spatial.get('coordinate_system') != 'EPSG:4326':
        raise InputError('空间数据必须显式使用 EPSG:4326')
    if not spatial.get('source', {}).get('sha256'):
        raise InputError('空间数据缺少来源哈希')
    for key, xy in spatial.get('nodes', {}).items():
        if len(xy) != 2 or not all(math.isfinite(x) for x in xy) or not -180 <= xy[0] <= 180 or not -90 <= xy[1] <= 90:
            raise InputError(f'道路节点 {key} 坐标无效')
    for edge in spatial.get('edges', []):
        if edge['u'] not in spatial['nodes'] or edge['v'] not in spatial['nodes'] or edge['minutes'] <= 0 or edge['km'] <= 0:
            raise InputError('道路边连接或单位无效')
