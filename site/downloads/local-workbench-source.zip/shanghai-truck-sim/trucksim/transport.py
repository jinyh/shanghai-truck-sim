"""Transport requests and a continuous, independently replayed battery ledger."""
from __future__ import annotations

import math

from .model import InputError


def audit_transport(task, solution):
    spec = task.get('transport')
    if not spec:
        return {'status': 'not_evaluated', 'reason': '未提供运输任务链'}
    if task.get('study', {}).get('plan') == 'baseline':
        return {'status': 'not_applicable', 'reason': '无新增重卡仅为电气基线，不参与运输服务排名'}
    sessions = {s['id']: s for s in task['sessions']}
    ledger = []; issues = []
    for vehicle in spec['vehicles']:
        energy = vehicle['initial_kwh']; capacity = vehicle['battery_kwh']
        if not 0 <= energy <= capacity:
            raise InputError('车辆初始电量超出电池容量')
        for trip in sorted((t for t in spec['trips'] if t['vehicle_id'] == vehicle['id']), key=lambda t: t['start_step']):
            before = energy
            if trip['route_status'] != 'routed':
                issues.append({'kind': 'unreachable', 'trip_id': trip['id']})
                ledger.append({'trip_id': trip['id'], 'vehicle_id': vehicle['id'], 'status': 'unreachable',
                               'before_kwh': before, 'after_trip_kwh': energy, 'after_charge_kwh': energy})
                continue
            energy -= trip['energy_kwh']
            if energy < -1e-6:
                issues.append({'kind': 'battery_depleted', 'trip_id': trip['id'], 'deficit_kwh': -energy})
            # Keep a negative energy balance visible; never fabricate recharge or reset at midnight.
            after_trip = energy
            sid = trip.get('session_id'); session = sessions.get(sid)
            delivered = sum(solution['power_by_session'].get(sid, []))*.25*task['charging_efficiency']
            if session and session['arrival_step'] < trip['arrival_step']:
                issues.append({'kind': 'charge_before_arrival', 'trip_id': trip['id']})
            energy += delivered
            if energy > capacity + 1e-5:
                issues.append({'kind': 'battery_overflow', 'trip_id': trip['id'], 'excess_kwh': energy-capacity})
            if energy < trip['minimum_departure_kwh']-1e-5:
                issues.append({'kind': 'departure_energy', 'trip_id': trip['id'],
                               'deficit_kwh': trip['minimum_departure_kwh']-energy})
            ledger.append({'trip_id': trip['id'], 'vehicle_id': vehicle['id'], 'start_step': trip['start_step'],
                           'arrival_step': trip['arrival_step'], 'before_kwh': before,
                           'distance_km': trip['distance_km'], 'consumed_kwh': trip['energy_kwh'],
                           'after_trip_kwh': after_trip, 'charged_kwh': delivered,
                           'after_charge_kwh': energy, 'minimum_departure_kwh': trip['minimum_departure_kwh']})
    return {'status': 'completed', 'passed': not issues, 'issues': issues, 'ledger': ledger,
            'distance_km': sum(t.get('distance_km', 0) for t in spec['trips']),
            'failed_trip_count': len({i['trip_id'] for i in issues}),
            'scope': '固定运输任务与指定场站；跨日连续能量账本；未模拟交通拥堵反馈及动态换站'}


def validate_transport(task):
    spec = task.get('transport')
    if not spec:
        return
    ids = [v['id'] for v in spec['vehicles']]
    if len(set(ids)) != len(ids):
        raise InputError('车辆标识重复')
    trip_ids=[t['id'] for t in spec['trips']]
    if len(set(trip_ids))!=len(trip_ids):raise InputError('运输任务标识重复')
    for v in spec['vehicles']:
        if not all(math.isfinite(v[k]) for k in ('battery_kwh','initial_kwh')) or not 0<=v['initial_kwh']<=v['battery_kwh'] or v['battery_kwh']<=0:
            raise InputError('电池容量或初始电量无效')
    sessions = {s['id']: s for s in task['sessions']}
    assigned = set()
    for vid in ids:
        previous_end = 0
        for t in sorted((x for x in spec['trips'] if x['vehicle_id'] == vid), key=lambda x: x['start_step']):
            if any(not math.isfinite(t[k]) or t[k]<0 for k in ('energy_kwh','distance_km','minimum_departure_kwh')):
                raise InputError('运输耗能、里程和最低电量必须为非负有限数')
            if not 0 <= previous_end <= t['start_step'] <= t['arrival_step'] <= t['departure_step'] <= task['periods']:
                raise InputError('车辆任务时间重叠、倒置或超出评价窗')
            previous_end = t['departure_step']
            sid = t.get('session_id')
            if sid:
                if sid in assigned or sid not in sessions:
                    raise InputError('运输会话重复关联或不存在')
                assigned.add(sid)
                if sessions[sid]['departure_step'] != t['departure_step'] or sessions[sid]['arrival_step'] < t['arrival_step']:
                    raise InputError('运输任务与充电窗口不一致')
    if any(t['vehicle_id'] not in ids for t in spec['trips']):
        raise InputError('运输任务引用未知车辆')
