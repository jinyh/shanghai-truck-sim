"""Public geography + explicit synthetic transport, load and electrical scenarios."""
from __future__ import annotations

import copy
import hashlib
import json
import math
from pathlib import Path

from .geography import nearest_node, route, distance_km

ROOT = Path(__file__).resolve().parents[1]
STUDY_PLANS = {'baseline': '无新增重卡', 'unmanaged': '常规充电', 'ordered': '有序充电',
               'capacitor': '有序充电 + 无功补偿', 'filter': '有序充电 + 谐波滤波'}
STRESSES = {'normal': '代表周', 'bunched': '集中到站', 'light': '低功率充电', 'weak': '较弱电源', 'background': '背景负荷偏高'}


def geography():
    return json.loads((ROOT/'data/public/shanghai-study-area.json').read_text())


def criteria(kv):
    thd = 4.0 if kv >= 1 else 5.0
    return {'voltage_min_pu': .93, 'voltage_max_pu': 1.07, 'thdu_pct': thd,
            'individual_harmonic_pct': {str(h): (3.2 if h % 2 else 1.6) if kv >= 1 else (4.0 if h % 2 else 2.0) for h in range(2, 26)},
            'voltage_standard': 'GB/T 12325-2008：20 kV及以下三相供电电压±7%',
            'harmonic_standard': 'GB/T 14549-1993：6/10 kV或0.38 kV参考表；2—25次',
            'voltage_source': 'https://openstd.samr.gov.cn/bzgk/std/newGbInfo?hcno=75EBBCF838AA40D281EDA854B8F63AD7',
            'harmonic_source': 'https://std.samr.gov.cn/gb/search/gbDetailed?id=71F772D7F6ACD3A7E05397BE0A0AB82A',
            'evaluation_point': '登记节点各相对中性点基波幅值；三相等值系统',
            'statistics': '各15分钟恒定运行点的最大相值；不是标准测量窗口的实测合格率',
            'approved': False, 'current_allocation': None}


def make_electrical(periods=672, season='summer', stress='normal'):
    buses = [{'id': 'source', 'name': '上级等值电源', 'kv': 110, 'observe': False, 'kind': 'source'}]
    transformers = []; lines = []
    def bus(name, kv, label, kind, observe=True):
        buses.append({'id': name, 'kv': kv, 'name': label, 'kind': kind, 'observe': observe,
                      'criteria': criteria(kv) if observe else {}})
    def transformer(name, source, dest, kva, xhl=6, rp=1):
        transformers.append({'id': name, 'from_bus': source, 'to_bus': dest, 'kva': kva,
                             'xhl_pct': xhl, 'r_pct': rp, 'connections': ['delta', 'wye'],
                             'evidence': 'synthetic', 'source': '登记等值设备参数；不由有功限额反推'})
    def line(name, source, dest, km, ampacity=300):
        lines.append({'id': name, 'from_bus': source, 'to_bus': dest, 'length_km': km,
                      'r1': .20, 'x1': .12, 'r0': .60, 'x0': .36, 'c1_nf': 150, 'c0_nf': 75,
                      'ampacity_a': ampacity, 'evidence': 'synthetic'})
    for i in (1, 2):
        bus(f'MV{i}', 10, f'主变{i}低压侧', 'transformer', False)
        transformer(f'T{i}', 'source', f'MV{i}', 25000, 8, .5)
    for i, (parent, km) in enumerate([(1, 4), (1, 5), (2, 6)], 1):
        bus(f'F{i}', 10, f'馈线{i}末端', 'feeder', False); line(f'LF{i}', f'MV{parent}', f'F{i}', km)
    station_buses = {}; pcc = {}; loads = []
    categories = ['industrial', 'residential', 'commercial', 'residential']
    names = ['港口工业用户', '同馈线居民用户', '商住混合区商业用户', '居民区用户']
    for i, fid in enumerate(['F1', 'F1', 'F2', 'F3'], 1):
        bus(f'PCC{i}', 10, f'站{i}公共连接点', 'pcc'); line(f'LS{i}', fid, f'PCC{i}', .5)
        bus(f'SLV{i}', .4, f'站{i}充电母线', 'station'); transformer(f'UST{i}', f'PCC{i}', f'SLV{i}', 1600)
        station_buses[f'S{i}'] = f'SLV{i}'; pcc[f'S{i}'] = f'line.LS{i}'
        bus(f'ZMV{i}', 10, f'用户{i}高压侧', 'user', False); line(f'LZ{i}', fid, f'ZMV{i}', 1.0)
        bus(f'ZLV{i}', .4, names[i-1], categories[i-1]); transformer(f'UZT{i}', f'ZMV{i}', f'ZLV{i}', 2500)
        category = categories[i-1]; ps = []; qs = []
        peak = [1500, 800, 1100, 900][i-1]
        for t in range(periods):
            hour = (t % 96)/4; weekend = (t//96) % 7 >= 5
            if category == 'industrial':
                factor = .55 + .4*(7 <= hour < 20); factor *= .82 if weekend else 1
                pf = .92
            elif category == 'residential':
                factor = .35 + .45*math.exp(-((hour-20)/2.7)**2)+.20*math.exp(-((hour-8)/2)**2)
                factor *= 1.08 if weekend else 1; pf = .96
            else:
                factor = .25+.65*math.exp(-((hour-14)/5)**2); factor *= .80 if weekend else 1; pf = .95
            p = peak*factor*(1 if season=='summer' else .87)*(2.0 if stress=='background' else 1)
            ps.append(p); qs.append(p*math.tan(math.acos(pf)))
        loads.append({'id': f'Z{i}', 'name': names[i-1], 'bus': f'ZLV{i}', 'feeder_id': fid,
                      'category': category, 'p_kw': ps, 'q_kvar': qs, 'phase_fractions': [1/3]*3,
                      'harmonics': {'5': [2.0, -20], '7': [1.0, 25], '11': [.5, 0]},
                      'evidence': 'synthetic', 'boundary': 'excludes_chargers',
                      'source': '登记典型曲线与幅值；非上海实测；未按用地面积推算实际负荷'})
    points = []
    for fraction, pf, scale in [(.05, .90, 2.8), (.25, .96, 1.8), (.5, .985, 1.0), (1., .995, .65)]:
        points.append({'fraction': fraction, 'displacement_pf': pf,
                       'harmonics': {str(h): [magnitude*scale, angle] for h, magnitude, angle in
                                     [(3, .5, 0), (5, 5.0, -15), (7, 3.0, 20), (11, 1.7, 10), (13, 1.0, -20), (17, .5, 0), (19, .3, 0)]}})
    return {'frequency_hz': 50, 'evidence': 'synthetic_equivalent', 'public': True,
            'source': {'bus': 'source', 'pu': 1.02, 'mvasc3': 150 if stress=='weak' else 1000,
                       'mvasc1': 100 if stress=='weak' else 800, 'xr': 10,
                       'harmonics': {'5': [.2, 0], '7': [.1, 20]}},
            'buses': buses, 'lines': lines, 'transformers': transformers, 'loads': loads,
            'station_buses': station_buses, 'pcc_elements': pcc, 'station_ports': {f'S{i}': 4 for i in range(1,5)},
            'charger_rated_kw': 320,
            'charger_characteristics': {'evidence': 'synthetic', 'source': '演示运行点，不对应厂家测试',
                                        'interpolation': '谐波复数线性插值；低于首点按首点，停机为零', 'operating_points': points},
            'mitigation': {'capacitor_kvar_per_station': 300, 'filter_orders': [5,7,11,13],
                           'filter_fraction': .8, 'filter_rated_a': 100,
                           'source': '理想限流前馈补偿；无动态、投资或设备保证结论'},
            'assumptions': ['合成辐射配电网；S1/S2共馈线，F1/F2共主变', '负荷默认三相均分，可显式提供分相比例',
                            '电容固定投入；滤波按次抵消且受100 A额定电流限制', '不模拟设备高频开关、电磁暂态或保护']}


def make_study(season='summer', plan='ordered', stress='normal', geo=None, days=7):
    if season not in ('summer', 'winter') or plan not in STUDY_PLANS or stress not in STRESSES or not 1 <= days <= 7:
        raise ValueError('不支持的季节、方案、工况或天数')
    geo = copy.deepcopy(geo if geo is not None else geography()); n = days*96
    net = make_electrical(n, season, stress)
    seeds = [[121.585,31.361],[121.615,31.323],[121.575,31.293],[121.535,31.285]]
    labels = ['港口工业示范站位','物流园区示范站位','商住混合示范站位','居民区邻近示范站位']
    anchors = [nearest_node(geo, xy) for xy in seeds]
    for i,z in enumerate(net['loads']):
        features=[f for f in geo.get('landuse',{}).get('features',[]) if f['properties']['category']==z['category']]
        def proximity(feature):
            polygons=[feature['geometry']['coordinates']] if feature['geometry']['type']=='Polygon' else feature['geometry']['coordinates']
            return min(distance_km(seeds[i],xy) for polygon in polygons for ring in polygon for xy in ring)
        z['landuse_feature_id']=min(features,key=proximity)['properties']['osm_id'] if features else None
        z['spatial_mapping_evidence']='合成供电映射；关联邻近同类公开用地图斑作展示，不代表实际供电或实测负荷'
    stations = []; vehicles = []; trips = []; sessions = []; routes = []
    for i, anchor in enumerate(anchors):
        sid = f'S{i+1}'; fid = ['F1','F1','F2','F3'][i]
        stations.append({'id': sid, 'name': labels[i], 'region': labels[i], 'feeder_id': fid,
                         'ports': 4, 'charger_kw': 320, 'shared_power_kw': 1280, 'connection_limit_kw': 1250,
                         'controllable': True, 'longitude': geo['nodes'][anchor][0], 'latitude': geo['nodes'][anchor][1],
                         'coordinate_system': 'EPSG:4326', 'road_node': anchor,
                         'position_evidence': '公开道路上的合成站位，不对应真实运营站', 'electrical_evidence': 'synthetic'})
        outward = route(geo, anchor, anchors[(i+2)%4]); inward = route(geo, anchors[(i+2)%4], anchor)
        routed = outward['status'] == inward['status'] == 'routed'
        km = (outward.get('distance_km',0)+inward.get('distance_km',0))*4
        minutes = (outward.get('minutes',0)+inward.get('minutes',0))*4+120
        routes.append({'station_id': sid, 'round_trips': 4, 'outward': outward, 'inward': inward,
                       'distance_km': km, 'minutes': minutes, 'service_minutes': 120})
        for v in range(4):
            vid = sid+f'V{v}'; initial = 430.; battery = 600.
            vehicles.append({'id': vid, 'battery_kwh': battery, 'initial_kwh': initial, 'weight_t': 40,
                             'height_m': 4., 'kwh_per_km': 1.5, 'evidence': 'synthetic'})
            for day in range(days):
                start = day*96 + (20 if stress=='bunched' else 16+v*2)
                arrival = start+math.ceil(minutes/15)
                deadline = min(n, (day+1)*96+(20 if stress=='bunched' else 16+v*2))
                arrival = min(arrival, deadline)
                energy = km*1.5*(1.12 if season=='winter' else 1)
                if stress=='bunched':
                    # Explicit loading delay concentrates arrivals in the evening.
                    arrival = min(deadline, day*96+68)
                tripid = f'{vid}D{day}'; sessionid = 'C'+tripid
                trip = {'id': tripid, 'vehicle_id': vid, 'start_step': start, 'arrival_step': arrival,
                        'departure_step': deadline, 'distance_km': km, 'energy_kwh': energy,
                        'minimum_departure_kwh': initial, 'route_status': 'routed' if routed else 'unreachable'}
                if plan != 'baseline' and routed and arrival < deadline and energy > 0:
                    trip['session_id'] = sessionid
                    sessions.append({'id': sessionid, 'station_id': sid, 'arrival_step': arrival,
                                     'departure_step': deadline, 'required_kwh': energy,
                                     'max_power_kw': 64 if stress=='light' else 320,
                                     'deadline_source': '固定车队任务；离线已知；保守向上对齐到站时间'})
                trips.append(trip)
    feeders = []
    for i in (1,2,3):
        fid = f'F{i}'
        background = [sum(z['p_kw'][t] for z in net['loads'] if z['feeder_id']==fid) for t in range(n)]
        feeders.append({'id': fid, 'name': f'等值馈线{i}', 'transformer_id': 'T1' if i<3 else 'T2',
                        'limit_kw': 5000, 'background_kw': background, 'committed_kw': 0, 'background_boundary': 'excludes_children'})
    transformers = [{'id': f'T{i}', 'name': f'等值主变{i}', 'limit_kw': 18000,
                     'background_kw': 0, 'committed_kw': 0, 'background_boundary': 'excludes_children'} for i in (1,2)]
    start = '2026-07-06T00:00:00+08:00' if season=='summer' else '2026-01-05T00:00:00+08:00'
    return {'schema_version': '1.1', 'id': f'quality-{season}-{plan}-{stress}',
            'title': f'重卡电能质量 · {"夏季" if season=="summer" else "冬季"}代表周 · {STUDY_PLANS[plan]}',
            'metadata': {'evidence': 'synthetic', 'source': '公开OSM道路 + 登记合成运输、电网和分区负荷',
                         'version': 'quality-v1', 'seed': 42, 'public': True,
                         'assumptions': ['地理数据公开真实；站位、电气连接、车辆与负荷为合成假设',
                                         '每车每天4次固定往返；按已知道路约束最短时间路由',
                                         '15分钟内按每端口设定功率恒定运行；不由平均功率猜测谐波',
                                         '跨日不重置电量；代表周不年化；尚无实测校准或工程审批']},
            'information_mode': 'offline_known_scenario', 'start': start, 'periods': n,
            'step_minutes': 15, 'charging_efficiency': .94,
            'price_cny_kwh': [.38 if (t%96)/4<7 or (t%96)/4>=22 else 1.12 if 18<=(t%96)/4<22 else .68 for t in range(n)],
            'stations': stations, 'feeders': feeders, 'transformers': transformers, 'sessions': sessions,
            'investment': {'utility_cny': None, 'user_cny': None, 'basis': '未核定'}, 'projects': [],
            'study': {'season': season, 'plan': plan, 'stress': stress, 'seed': 42, 'annualized': False},
            'spatial': geo, 'electrical': net, 'transport': {'vehicles': vehicles, 'trips': trips, 'routes': routes,
                                                          'evidence': 'synthetic_tasks_on_public_roads'}}


def compare_study(season='summer', stress='normal', days=7, scans=True, inputs=None):
    from .analysis import run
    from .quality import paired_deltas, impedance_scan, event_screen
    cases = {}; geo = inputs['baseline']['spatial'] if inputs else geography()
    for plan in STUDY_PLANS:
        raw = copy.deepcopy(inputs[plan]) if inputs else make_study(season, plan, stress, geo, days)
        cases[plan] = run(raw, 'unmanaged' if plan in ('baseline','unmanaged') else 'optimized')
    reference = cases['baseline']['power_quality']
    for plan, value in cases.items():
        value['power_quality']['paired_deltas'] = paired_deltas(reference, value['power_quality'])
        value['power_quality']['reference_input_hash'] = cases['baseline']['input_hash']
    sensitivity = []
    if scans:
        net = cases['ordered']['task']['electrical']
        for plan in ('ordered','capacitor'):
            for damping in (0,50,100):
                for label, step in [('light', 0), ('peak', min(cases['ordered']['task']['periods']-1, 76))]:
                    sensitivity.append({'plan': plan, 'background': label, **impedance_scan(net, plan, step, damping)})
    events = []
    for plan in ('unmanaged','ordered'):
        result = cases[plan]
        curve = [sum(result['metrics']['station_power_kw'][s][t] for s in result['metrics']['station_power_kw']) for t in range(result['task']['periods'])]
        if len(curve) > 1:
            step = max(range(1,len(curve)), key=lambda t: abs(curve[t]-curve[t-1]))
            try:events.append(event_screen(result['task'],result['solution'],step))
            except Exception as exc:events.append({'plan':plan,'step':step,'status':'failed','reason':str(exc),'nodes':{},'previous_nodes':{}})
    digest = hashlib.sha256(json.dumps([r['input_hash'] for r in cases.values()]).encode()).hexdigest()
    from .quality import crosscheck_fundamental
    crosscheck = crosscheck_fundamental(cases['ordered']['task']['electrical'],0,{('S1',0):300,('S2',0):300})
    return {'schema_version': '1.1', 'kind': 'power_quality_comparison', 'id': digest[:16], 'season': season,
            'stress': stress, 'days': days, 'cases': cases, 'impedance_sensitivity': sensitivity, 'events': events,
            'evidence': 'public_geography_synthetic_engineering', 'formal_connection_approval': False,
            'annualized': False, 'comparison_rule': '同运输任务、同背景负荷与种子；基线只参与电气比较',
            'plan_labels': STUDY_PLANS, 'source_sha256': geo['source']['sha256'], 'fundamental_crosscheck':crosscheck}


def presentation(value):
    """Explicit public display projection; full calculation evidence stays in export."""
    result={k:copy.deepcopy(v) for k,v in value.items() if k!='cases'}
    result['cases']={}
    for plan,r in value['cases'].items():
        q=r['power_quality']
        result['cases'][plan]={'input_hash':r['input_hash'],'assessment':r['assessment'],
            'stations':r['task']['stations'], 'timestamps':r['timestamps'],
            'metrics':{k:r['metrics'][k] for k in ('feasible','shortfall_kwh','charging_peak_kw','operator_energy_cost_cny','station_power_kw','assets')},
            'transport':r['transport'],
            'power_quality':{k:q[k] for k in ('status','failures','nodes','trace','paired_deltas','station_q_kvar','pcc_current','harmonic_orders','not_evaluated','scope','engine','maximum_equipment_loading_pct','equipment_overload_steps','equipment_scope')},
            'background':r['task']['electrical']['loads'],
            'network':{k:r['task']['electrical'][k] for k in ('buses','lines','transformers','station_buses')},
            'routes':r['task']['transport']['routes']}
    geo=value['cases']['baseline']['task']['spatial']
    result['spatial']={k:geo[k] for k in ('source','bounds','roads','landuse','coverage','assumptions')}
    return result
