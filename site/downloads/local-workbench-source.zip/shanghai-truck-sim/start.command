#!/bin/zsh
set -eu
cd "${0:A:h}"
if [ ! -x .venv/bin/python ]; then
  uv sync --offline --frozen --no-index --find-links wheelhouse --cache-dir .cache/uv
fi
exec .venv/bin/python -m trucksim.cli serve --port "${1:-8785}"
