import copy
import io
import json
import math
import tempfile
import unittest
import zipfile
from pathlib import Path
from unittest.mock import patch

import numpy as np

from trucksim.analysis import run
from trucksim.geography import route, validate_spatial
from trucksim.model import InputError, normalize
from trucksim.quality import Circuit, crosscheck_fundamental, impedance_scan, operating_point, paired_deltas, event_screen
from trucksim.quality_io import export_study, numerically_equal, restore_inputs
from trucksim.study import make_electrical, make_study
from trucksim.transport import audit_transport


def roads():
    nodes={'A':[121.535,31.285],'B':[121.575,31.293],'C':[121.615,31.323],'D':[121.585,31.361]}
    edges=[]
    for u,v in [('A','B'),('B','C'),('C','D'),('D','A')]:
        for a,b in [(u,v),(v,u)]:edges.append({'u':a,'v':b,'way':u+v,'km':10,'minutes':20,'unknown':['fixture']})
    return {'coordinate_system':'EPSG:4326','source':{'sha256':'fixture','public':True},'nodes':nodes,'edges':edges,
            'turn_restrictions':[],'bounds':[121.51,31.26,121.64,31.385],
            'roads':{'type':'FeatureCollection','features':[]},'landuse':{'type':'FeatureCollection','features':[]},'coverage':{},'assumptions':[]}


def short_task(plan='ordered'):
    # Construct a complete task, then a valid 4-period standalone charging fixture.
    t=make_study(plan=plan,geo=roads(),days=1);t['periods']=4;t['price_cny_kwh']=[.4,.4,1.,1.]
    for f in t['feeders']:f['background_kw']=f['background_kw'][:4]
    for z in t['electrical']['loads']:
        z['p_kw']=z['p_kw'][:4];z['q_kvar']=z['q_kvar'][:4]
    t.pop('transport')
    t['sessions']=[] if plan=='baseline' else [{'id':'C1','station_id':'S1','arrival_step':0,'departure_step':4,'required_kwh':100,'max_power_kw':320}]
    return t


def simple_network():
    n=make_electrical(1)
    n['source']={'bus':'source','pu':1.,'mvasc3':1e9,'mvasc1':1e9,'xr':10,'harmonics':{}}
    n['buses']=[{'id':'source','kv':10},{'id':'end','kv':10}]
    n['transformers']=[];n['station_buses']={};n['station_ports']={};n['pcc_elements']={}
    n['lines']=[{'id':'L1','from_bus':'source','to_bus':'end','length_km':1,'r1':.2,'x1':.1,'r0':.6,'x0':.3,'c1_nf':0,'c0_nf':0,'ampacity_a':1000}]
    n['loads']=[{'id':'ZA','bus':'end','p_kw':[100.],'q_kvar':[0.],'phase_fractions':[1/3]*3,'harmonics':{}}]
    return n


class RoadTests(unittest.TestCase):
    def test_known_restriction_and_oneway(self):
        g=roads();g['edges']=[e for e in g['edges'] if e['u']=='A' and e['v']=='B']
        self.assertEqual(route(g,'A','B')['status'],'routed')
        self.assertEqual(route(g,'B','A')['status'],'unreachable')
        g['edges'][0]['hgv']='no';self.assertEqual(route(g,'A','B')['status'],'unreachable')

    def test_dimensions_and_turn_restriction(self):
        g=roads();g['edges']=[e for e in g['edges'] if (e['u'],e['v']) in [('A','B'),('B','C')]]
        g['edges'][0]['maxweight_t']=30;self.assertEqual(route(g,'A','C')['status'],'unreachable')
        g['edges'][0]['maxweight_t']=50
        g['turn_restrictions']=[{'via':'B','from_way':'AB','to_way':'BC','kind':'no_straight_on'}]
        self.assertEqual(route(g,'A','C')['status'],'unreachable')

    def test_unknown_is_preserved_and_units(self):
        g=roads();r=route(g,'A','B');self.assertEqual(r['distance_km'],10);self.assertEqual(r['minutes'],20)
        self.assertIn('fixture',r['unknown_restrictions'])
        g['coordinate_system']='GCJ-02'
        with self.assertRaises(InputError):validate_spatial(g)


class TransportTests(unittest.TestCase):
    def test_cross_day_does_not_reset_battery(self):
        t=make_study(geo=roads(),days=2);task=normalize(t)
        power={s['id']:[0]*task['periods'] for s in task['sessions']}
        audit=audit_transport(task,{'power_by_session':power})
        rows=[r for r in audit['ledger'] if r['vehicle_id']=='S1V0']
        self.assertEqual(rows[1]['before_kwh'],rows[0]['after_charge_kwh']);self.assertFalse(audit['passed'])
        self.assertTrue(any(x['kind']=='battery_depleted' for x in audit['issues']))

    def test_unreachable_keeps_failure_and_baseline_not_applicable(self):
        g=roads();g['edges']=[];t=make_study(geo=g,days=1)
        a=audit_transport(normalize(t),{'power_by_session':{}})
        self.assertEqual(a['failed_trip_count'],16);self.assertEqual(len(a['ledger']),16)
        t['study']['plan']='baseline';self.assertEqual(audit_transport(t,{})['status'],'not_applicable')


class ElectricalTests(unittest.TestCase):
    def test_two_bus_closed_form_voltage(self):
        c=Circuit(simple_network());c.set_state(0,{})
        v0=10000/math.sqrt(3);p=100000/3;r=.2;x=.1
        b=v0*v0-2*r*p;y=(b+math.sqrt(b*b-4*(r*r+x*x)*p*p))/2
        expected=math.sqrt(y)/v0
        self.assertAlmostEqual(float(np.mean(abs(c.voltages('end'))))/v0,expected,places=6)

    def test_zero_harmonics_and_explicit_frequency(self):
        c=Circuit(make_electrical(1));c.net['source']['harmonics']={}
        c.spectrum('background_source',{})
        for z in c.net['loads']:c.spectrum('sp_'+z['id'],{})
        c.set_state(0,{})
        for h in [2,5,7,25]:
            c.harmonic(h);self.assertEqual(c.dss.ActiveCircuit.Solution.Frequency,h*50)
            self.assertLess(float(max(abs(c.voltages('SLV1')))),1e-8)

    def test_harmonic_addition_and_cancellation(self):
        n=simple_network();n['loads'][0]['harmonics']={'5':[10.,0.]}
        other=copy.deepcopy(n['loads'][0]);other['id']='ZB';n['loads'].append(other)
        c=Circuit(n);c.set_state(0,{});c.harmonic(5);same=max(abs(c.voltages('end')))
        n['loads'][1]['harmonics']['5'][1]=180
        d=Circuit(n);d.set_state(0,{});d.harmonic(5);cancel=max(abs(d.voltages('end')))
        self.assertGreater(same,.1);self.assertLess(cancel,same*1e-6)

    def test_complex_angle_interpolation(self):
        table={'operating_points':[{'fraction':.1,'displacement_pf':.9,'harmonics':{'5':[10,179]}},
                                   {'fraction':1,'displacement_pf':1,'harmonics':{'5':[10,-179]}}]}
        p=operating_point(table,.55);self.assertAlmostEqual(abs(p['harmonics']['5'][1]),180,places=6)

    def test_same_network_fundamental_crosscheck(self):
        for plan in ('ordered','capacitor'):
            x=crosscheck_fundamental(make_electrical(1),0,{('S1',0):320,('S2',0):320},plan)
            self.assertTrue(x['passed'],x)

    def test_capacitor_moves_resonance_and_damping_matters(self):
        n=make_electrical(1);a=impedance_scan(n,'ordered',0);b=impedance_scan(n,'capacitor',0)
        self.assertNotEqual(a['peak']['order'],b['peak']['order'])
        self.assertTrue(any(y['ohm']>x['ohm'] for x,y in zip(a['rows'],b['rows'])))
        c=impedance_scan(n,'capacitor',0,0)
        self.assertNotAlmostEqual(c['peak']['ohm'],b['peak']['ohm'],places=5)

    def test_normal_run_zero_increment_and_stop_restart(self):
        t=short_task();r=run(t);self.assertEqual(r['power_quality']['status'],'completed')
        q=r['power_quality'];d=paired_deltas(q,q)
        self.assertTrue(all(x['min_voltage_delta_pu']==0 and x['max_thdu_delta_percentage_points']==0 for x in d))
        self.assertTrue(all(math.isfinite(x['max_thdu_pct']) for x in q['nodes']))
        self.assertGreater(sum(bool(x) for x in q['operating_states']),0)

    def test_capacity_pass_but_voltage_fail(self):
        t=short_task();t['electrical']['source']['pu']=.91
        r=run(t);self.assertTrue(r['metrics']['feasible'])
        self.assertTrue(any(x['voltage_exceedance_steps'] for x in r['power_quality']['nodes']))
        self.assertFalse(r['assessment']['engineering_approved'])

    def test_background_violation_without_trucks(self):
        t=short_task('baseline');t['electrical']['source']['pu']=.91
        r=run(t);self.assertEqual(r['metrics']['charging_peak_kw'],0)
        self.assertTrue(any(x['voltage_exceedance_steps'] for x in r['power_quality']['nodes']))

    def test_nonconvergence_not_hidden(self):
        with patch('trucksim.quality.Circuit.set_state',side_effect=ValueError('forced nonconvergence')):
            r=run(short_task())
        self.assertEqual(r['power_quality']['status'],'failed');self.assertEqual(len(r['power_quality']['failures']),4)
        self.assertTrue(all(x['voltage_min_pu'] is None for x in r['power_quality']['nodes']))

    def test_partial_failure_keeps_alignment_and_cleans_partial_rows(self):
        original=Circuit.harmonic;calls=0
        def fail_one(c,h):
            nonlocal calls
            calls+=1
            if calls==5:raise ValueError('failed harmonic step')
            return original(c,h)
        with patch.object(Circuit,'harmonic',fail_one):r=run(short_task())
        q=r['power_quality'];self.assertEqual(q['failures'][0]['step'],0)
        self.assertIsNone(q['station_q_kvar']['S1'][0]);self.assertIsNone(q['operating_states'][0])
        self.assertEqual([x['step'] for x in q['equipment']],[1,2,3])
        self.assertTrue(all([x['step'] for x in rows]==[1,2,3] for rows in q['trace'].values()))

    def test_event_freezes_background_and_cache_retains_steps(self):
        t=short_task('baseline');r=run(t)
        e=event_screen(r['task'],r['solution'],1)
        self.assertTrue(all(abs(x)<1e-8 for row in e['phase_delta_pu'].values() for x in row))
        self.assertTrue(all([row['step'] for row in rows]==[0,1,2,3] for rows in r['power_quality']['trace'].values()))

    def test_duplicate_load_and_missing_criteria(self):
        t=short_task();t['electrical']['loads'].append(copy.deepcopy(t['electrical']['loads'][0]))
        with self.assertRaises(InputError):normalize(t)
        t=short_task();t['electrical']['buses'][0]['criteria']={}
        for b in t['electrical']['buses']:b['criteria']={}
        r=run(t)
        self.assertTrue(all(row['voltage_status']=='not_evaluated' and row['harmonic_status']=='not_evaluated'
                            for rows in r['power_quality']['trace'].values() for row in rows))

    def test_missing_specialty_stays_not_evaluated(self):
        t=short_task();t.pop('electrical');r=run(t)
        self.assertEqual(r['power_quality']['status'],'not_evaluated')

    def test_low_load_spectrum_can_worsen_thd_while_shaving(self):
        t=short_task();t['sessions'][0]['required_kwh']=60
        # Controlled adversarial device fixture: low-power point is much dirtier.
        for p in t['electrical']['charger_characteristics']['operating_points']:
            p['harmonics']={'5':[80 if p['fraction']<=.25 else .1,0]}
        a=run(t,'unmanaged');b=copy.deepcopy(t);b['sessions'][0]['max_power_kw']=64;b=run(b,'optimized')
        self.assertLess(b['metrics']['charging_peak_kw'],a['metrics']['charging_peak_kw'])
        self.assertGreater(max(n['max_thdu_pct'] for n in b['power_quality']['nodes']),max(n['max_thdu_pct'] for n in a['power_quality']['nodes']))


class ExportTests(unittest.TestCase):
    def test_shared_geo_round_trip_and_numerical_tamper(self):
        # Small complete inputs make this test exercise every comparison/export path.
        inputs={plan:short_task(plan) for plan in ('baseline','unmanaged','ordered','capacitor','filter')}
        a=run(inputs['ordered']);self.assertTrue(numerically_equal(a,copy.deepcopy(a)))
        b=copy.deepcopy(a);b['power_quality']['nodes'][0]['max_thdu_pct']+=1
        self.assertFalse(numerically_equal(a,b))
        from trucksim.model import fingerprint
        value={'cases':{p:run(t,'unmanaged' if p in ('baseline','unmanaged') else 'optimized') for p,t in inputs.items()},'id':'fixture'}
        with tempfile.TemporaryDirectory() as folder:
            with zipfile.ZipFile(io.BytesIO(export_study(value))) as z:z.extractall(folder)
            f=Path(folder);manifest=json.loads((f/'study.json').read_text());restored=restore_inputs(f,manifest)
            self.assertEqual(set(restored),set(inputs))
            for plan in inputs:self.assertEqual(fingerprint(restored[plan]),fingerprint(inputs[plan]))


if __name__=='__main__':unittest.main()
