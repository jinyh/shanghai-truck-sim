"""Integration checks against a running loopback server; use only synthetic fixtures."""
import io
import json
import time
import urllib.request
import urllib.error
import zipfile
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from test_core import case,csv_bundle

BASE=sys.argv[1] if len(sys.argv)>1 else 'http://127.0.0.1:8785'


def request(path,data=None,headers=None):
    return urllib.request.urlopen(urllib.request.Request(BASE+path,data=data,headers=headers or {}),timeout=30)


def wait(jid):
    for _ in range(120):
        value=json.load(request('/api/jobs/'+jid))
        if value['status']=='completed':return value['result']
        if value['status']=='failed':raise AssertionError(value['error'])
        time.sleep(.1)
    raise AssertionError('job timeout')


checks={}
checks['health']=json.load(request('/api/health'))['status']=='ok'
for name,body in [('json',json.dumps(case()).encode()),('csv',csv_bundle(case()))]:
    job=json.load(request('/api/import',body));r=wait(job['id'])
    checks[name+'_import']=r['metrics']['feasible'] and abs(r['metrics']['operator_energy_cost_cny']-2)<1e-4
    with zipfile.ZipFile(io.BytesIO(request('/api/export/'+job['id']).read())) as z:
        checks[name+'_export']=all(n in z.namelist() for n in ['task.json','result.json','逐站评估.csv','source_manifest.json'])
        checks[name+'_original_preserved']=any(n.startswith('original-input.') for n in z.namelist())
    if name=='csv':checks['unknown_investment_not_zero']=r['metrics']['utility_investment_cny'] is None
for name,path,data,headers in [('bad_json','/api/import',b'[]',{}),('missing_record','/api/import',b'{}',{}),('host_guard','/api/health',None,{'Host':'untrusted.example'}),('origin_guard','/api/run',b'{}',{'Origin':'https://untrusted.example'})]:
    try:request(path,data,headers);checks[name]=False
    except urllib.error.HTTPError as exc:checks[name]=exc.code==(403 if 'guard' in name else 400)
with zipfile.ZipFile(io.BytesIO(request('/api/templates.zip').read())) as z:
    checks['templates_complete']=all(n in z.namelist() for n in ['manifest.json','stations.csv','timeseries.csv','数据交付说明.md'])
Path('output/接口验证.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2))
print(json.dumps(checks,ensure_ascii=False,indent=2))
assert all(checks.values())
