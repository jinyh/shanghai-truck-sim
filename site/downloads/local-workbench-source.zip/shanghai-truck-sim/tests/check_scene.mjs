import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {vehicleState,routePosition,assessmentFor} from '../web/scene-state.js';
const base=new URL('../web/',import.meta.url),read=p=>JSON.parse(readFileSync(new URL(p,base)));
const pointer=read('scene-data/index.json'),index=read('scene-data/'+pointer.file),catalog=read(`candidates-${index.candidate_version}.json`);
let samples=0;
for(const [key,entry] of Object.entries(index.records)){
 const d=JSON.parse(gunzipSync(readFileSync(new URL('scene-data/'+entry.file,base))));
 assert.equal(d.input_hash,entry.input_hash);
 for(let t=0;t<d.timestamps.length;t++){
  const occupied=new Set(),sums=Object.fromEntries(d.stations.map(s=>[s.id,0]));
  for(const v of d.vehicles){const state=vehicleState(v,t,d);samples++;assert(Number.isFinite(state.energy));sums[v.station_id]+=state.power;
   if(['charging','connected'].includes(state.status)){const k=v.station_id+':'+state.port;assert(!occupied.has(k),`${key} ${t} duplicate port ${k}`);occupied.add(k);}
   if(state.status==='charging')assert(state.power>0);
   const again=vehicleState(v,t,d);assert.deepEqual(state,again,'random seek must be deterministic');
   for(const trip of v.trips){if(t===trip.arrival_step)assert(Math.abs(state.energy-trip.ledger.after_trip_kwh)<1e-5);}
  }
  for(const s of d.stations)assert(Math.abs(sums[s.id]-d.station_power_kw[s.id][t])<1e-5,`${key} ${s.id} ${t} charging mismatch`);
 }
 for(const v of d.vehicles)for(const trip of v.trips){const last=vehicleState(v,trip.departure_step-.001,d);const final=last.energy+(trip.power_kw[Math.floor(trip.departure_step-.001)]||0)*.25*d.charging_efficiency;assert(Math.abs(final-trip.ledger.after_charge_kwh)<1e-5,'SOC must reconcile to ledger');}
 for(const s of d.stations){if(d.plan!=='baseline'){const r=assessmentFor(catalog,d.case_id,d.plan,s.id);assert(r);assert.equal(r.source_input_hash,d.input_hash);}const route=d.routes[s.id];if(route.outward_coordinates.length>1){const pos=routePosition(route,.25,p=>p);assert(Number.isFinite(pos.x));}}
}
assert.equal(assessmentFor(catalog,'summer-normal','unmanaged','S1','missing'),undefined);
console.log(JSON.stringify({passed:true,cases:Object.keys(index.records).length,vehicle_time_samples:samples,checks:'power, SOC, unique ports, deterministic seek, input/assessment versions'}));
