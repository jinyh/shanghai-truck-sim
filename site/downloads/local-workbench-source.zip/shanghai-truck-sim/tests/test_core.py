import io
import json
import tempfile
import unittest
import zipfile
from pathlib import Path

from trucksim.analysis import run, flexibility, calibration
from trucksim.audit import evaluate
from trucksim.demo import make_demo
from trucksim.dispatch import rule
from trucksim.env import TruckPlanningEnv
from trucksim.io import csv_text, FIELDS, load_bundle, export_bundle, report_text
from trucksim.model import InputError, normalize, reserve_ports
from trucksim.verification import reproduce


def case():
    return {'schema_version':'1.0','id':'hand-check','title':'可手算验证案例',
        'information_mode':'offline_known_scenario','metadata':{'evidence':'synthetic','source':'test','version':'1'},
        'start':'2027-01-01T00:00:00+08:00','periods':4,'step_minutes':15,
        'charging_efficiency':1.,'price_cny_kwh':[1,1,.2,.2],
        'stations':[{'id':'S1','name':'测试站','region':'测试区域','feeder_id':'F1','ports':2,
            'charger_kw':20,'shared_power_kw':30,'connection_limit_kw':30,'controllable':True}],
        'feeders':[{'id':'F1','transformer_id':'T1','limit_kw':30,'background_kw':10,
            'committed_kw':0,'background_boundary':'excludes_children'}],
        'transformers':[{'id':'T1','limit_kw':45,'background_kw':5,
            'committed_kw':0,'background_boundary':'excludes_children'}],
        'sessions':[{'id':'V1','station_id':'S1','arrival_step':0,'departure_step':4,
            'required_kwh':10,'max_power_kw':20}]}


def csv_bundle(raw, duplicate_price=False):
    t=normalize(raw);content=io.BytesIO()
    manifest={k:v for k,v in raw.items() if k not in ('stations','feeders','transformers','sessions','price_cny_kwh')}
    stations=t['stations'];assets=[];curves=[]
    for kind in ('feeder','transformer'):
        for a in t[kind+'s']:
            assets.append({**a,'type':kind,'parent_id':a.get('transformer_id',''),'limit_kw':a['limit_kw'][0]})
            for i,stamp in enumerate(t['timestamps']):
                curves.append({'timestamp':stamp,'entity_type':kind,'entity_id':a['id'],
                    'background_kw':a['background_kw'],'committed_kw':a['committed_kw'][i],
                    'limit_kw':a['limit_kw'][i],'quality':'valid'})
                # Normalize keeps the original background scalar; use net background here.
                curves[-1]['background_kw']=a['net_background_kw'][i]
    for i,stamp in enumerate(t['timestamps']):
        curves.append({'timestamp':stamp,'entity_type':'price','entity_id':'tariff','price_cny_kwh':t['price_cny_kwh'][i],'quality':'valid'})
    if duplicate_price:curves.append({**curves[-1],'entity_id':'another-tariff'})
    sessions=[]
    from datetime import datetime,timedelta
    for s in t['sessions']:
        sessions.append({**s,'arrival_time':t['timestamps'][s['arrival_step']],
            'departure_time':(datetime.fromisoformat(t['start'])+timedelta(minutes=15*s['departure_step'])).isoformat()})
    with zipfile.ZipFile(content,'w') as z:
        z.writestr('manifest.json',json.dumps(manifest))
        for name,rows in [('stations.csv',stations),('grid_assets.csv',assets),('timeseries.csv',curves),('sessions.csv',sessions)]:
            z.writestr(name,csv_text(FIELDS[name],rows))
        z.writestr('controls.csv',csv_text(FIELDS['controls.csv'],[{'station_id':'S1','permission_basis':'测试声明'}]))
    return content.getvalue()


class CoreTests(unittest.TestCase):
    def test_hand_calculated_optimum(self):
        r=run(case());m=r['metrics']
        self.assertTrue(m['feasible']);self.assertAlmostEqual(m['operator_energy_cost_cny'],2,places=5)
        self.assertAlmostEqual(m['grid_energy_kwh'],10,places=5)
        self.assertLess(m['energy_balance_error_kwh'],1e-6)
        self.assertAlmostEqual(sum(r['solution']['power_by_session']['V1'][:2]),0,places=5)

    def test_shared_transformer_joint_constraint(self):
        raw=case();raw['stations'].append({**raw['stations'][0],'id':'S2','feeder_id':'F2'})
        raw['feeders'].append({**raw['feeders'][0],'id':'F2'})
        raw['sessions'].append({**raw['sessions'][0],'id':'V2','station_id':'S2'})
        raw['transformers'][0]['limit_kw']=40 # 25 kW background leaves 15 kWh in this hour
        r=run(raw);self.assertAlmostEqual(r['metrics']['shortfall_kwh'],5,places=5)
        self.assertLessEqual(max(r['metrics']['transformer_power_kw']['T1']),40.00001)
        self.assertFalse(r['metrics']['feasible'])

    def test_feeder_measurement_deduplication(self):
        raw=case();f=raw['feeders'][0]
        f.update(background_kw=18,background_boundary='includes_declared_children',included_children_kw={'S1':[8]*4})
        t=normalize(raw);self.assertEqual(t['feeders'][0]['net_background_kw'],[10]*4)
        r=run(raw);self.assertAlmostEqual(max(r['metrics']['feeder_power_kw']['F1']),30,places=5)
        f['included_children_kw']={}
        with self.assertRaises(InputError):normalize(raw)

    def test_wrong_child_and_negative_residual_rejected(self):
        raw=case();f=raw['feeders'][0];f.update(background_boundary='includes_declared_children',included_children_kw={'S9':[1]*4})
        with self.assertRaises(InputError):normalize(raw)
        f['included_children_kw']={'S1':[11]*4}
        with self.assertRaises(InputError):normalize(raw)

    def test_missing_committed_not_zero(self):
        raw=case();del raw['feeders'][0]['committed_kw']
        with self.assertRaises(InputError):normalize(raw)

    def test_queue_and_deadline(self):
        raw=case();raw['stations'][0]['ports']=1
        raw['sessions'].append({**raw['sessions'][0],'id':'V2','departure_step':2})
        r=run(raw);self.assertAlmostEqual(r['metrics']['shortfall_kwh'],10,places=5)
        second=next(x for x in r['metrics']['sessions'] if x['id']=='V2')
        self.assertEqual(second['wait_minutes'],30)

    def test_expensive_energy_cannot_buy_shortfall(self):
        raw=case();raw['price_cny_kwh']=[1e6]*4
        r=run(raw);self.assertTrue(r['metrics']['feasible'])
        self.assertAlmostEqual(r['metrics']['delivered_kwh'],10,places=5)

    def test_control_permissions(self):
        raw=case();raw['stations'][0]['controllable']=False
        task=normalize(raw);reference=rule(task)['power_by_session']
        for method in ('deadline','optimized'):
            self.assertEqual(run(raw,method)['solution']['power_by_session'],reference)
        altered={'V1':[0,0,20,20]}
        self.assertIn('control_permission',{x['kind'] for x in evaluate(task,{'power_by_session':altered})['issues']})

    def test_control_loss_exceedance_is_not_hidden(self):
        raw=case();raw['stations'][0]['controllable']=False;raw['feeders'][0]['limit_kw']=15
        for method in ('deadline','optimized'):
            r=run(raw,method);self.assertFalse(r['metrics']['feasible'])
            self.assertTrue(any(x['kind']=='capacity_exceeded' for x in r['metrics']['issues']))

    def test_background_overload_still_fails_without_vehicles(self):
        raw=case();raw['sessions']=[];raw['feeders'][0]['background_kw']=40
        r=run(raw);self.assertFalse(r['metrics']['feasible']);self.assertEqual(r['metrics']['shortfall_kwh'],0)

    def test_independent_checker_rejects_invalid_plan(self):
        task=normalize(case())
        for power in ({'V1':[float('nan')]*4},{'V1':[30]*4},{'V1':[20]*4},{'unknown':[0]*4},{'V1':[True]*4}):
            self.assertFalse(evaluate(task,{'power_by_session':power})['feasible'])

    def test_window_and_units_validation(self):
        for edit in ('missing','nan','timezone','window','identifier'):
            raw=case()
            if edit=='missing':raw['feeders'][0]['background_kw']=[0,None,0,0]
            if edit=='nan':raw['sessions'][0]['required_kwh']=float('nan')
            if edit=='timezone':raw['start']='2027-01-01T00:00:00'
            if edit=='window':raw['sessions'][0]['departure_step']=5
            if edit=='identifier':raw['transformers'][0]['id']='F1'
            with self.assertRaises(InputError,msg=edit):normalize(raw)

    def test_flex_freezes_past_and_closes_energy(self):
        raw=case();raw['periods']=8;raw['price_cny_kwh']=[1,.1,.2,.3,1,1,1,1]
        raw['sessions'][0]['departure_step']=8
        r=run(raw);f=flexibility(r,'F1',1,1)
        down=f['directions']['reduce']
        self.assertTrue(down['feasible']);self.assertAlmostEqual(down['pre_event_energy_change_kwh'],0,places=6)
        self.assertAlmostEqual(down['full_period_energy_change_kwh'],0,places=5)
        self.assertGreater(down['delta_kw'],0);self.assertGreater(down['rebound_peak_kw'],0)

    def test_flex_rejects_infeasible_baseline(self):
        raw=case();raw['sessions'][0]['required_kwh']=100
        self.assertEqual(flexibility(run(raw))['status'],'unavailable')

    def test_csv_round_trip_and_optional_retention(self):
        raw=load_bundle(csv_bundle(case()));r=run(raw)
        self.assertTrue(r['metrics']['feasible']);self.assertEqual(r['evidence_level'],'customer_unvalidated')
        self.assertIsNone(r['metrics']['utility_investment_cny'])
        self.assertEqual(raw['supplementary_tables']['controls.csv'][0]['station_id'],'S1')
        self.assertIn('未提供',report_text(r))

    def test_duplicate_price_rejected(self):
        with self.assertRaises(InputError):load_bundle(csv_bundle(case(),True))

    def test_source_and_result_reproduction(self):
        r=run(case())
        with tempfile.TemporaryDirectory() as d:
            with zipfile.ZipFile(io.BytesIO(export_bundle(r))) as z:z.extractall(d)
            self.assertTrue(reproduce(d)['passed'])
            p=Path(d)/'source'/'trucksim'/'model.py';p.write_text(p.read_text()+'\n# tampered\n')
            self.assertFalse(reproduce(d)['passed'])

    def test_environment_budget_and_finality(self):
        env=TruckPlanningEnv(1);obs=env.reset(case());self.assertNotIn('oracle',obs)
        power=run(case())['solution']['power_by_session'];self.assertTrue(env.check_plan(power)['feasible'])
        with self.assertRaises(ValueError):env.check_plan(power)
        self.assertTrue(env.submit_plan(power)['feasible'])
        with self.assertRaises(ValueError):env.submit_plan(power)

    def test_project_commissioning_and_cost_boundary(self):
        for plan in ('expanded','alternate'):
            raw=make_demo(2026,plan=plan)
            self.assertEqual(raw['investment']['utility_cny'],0)
            self.assertEqual(raw['stations'][3]['feeder_id'],'F2')
        self.assertGreater(make_demo(2027,plan='expanded')['investment']['utility_cny'],0)
        self.assertEqual(make_demo(2028,plan='phased')['investment']['utility_cny'],0)
        self.assertGreater(make_demo(2029,plan='phased')['investment']['utility_cny'],0)

    def test_demo_growth_is_nested_and_windows_complete(self):
        previous={}
        for year in range(2026,2031):
            raw=make_demo(year,'high');normalize(raw)
            current={s['id']:s for s in raw['sessions']}
            for key,s in previous.items():self.assertEqual(current[key],s)
            previous=current

    def test_calibration_and_invalid_measurement(self):
        value=calibration([0,10,0],[0,0,10]);self.assertEqual(value['energy_error_kwh'],0)
        self.assertEqual(value['peak_time_error_minutes'],15);self.assertGreater(value['rmse_kw'],0)
        with self.assertRaises(ValueError):calibration([None],[0])


if __name__=='__main__':unittest.main()
