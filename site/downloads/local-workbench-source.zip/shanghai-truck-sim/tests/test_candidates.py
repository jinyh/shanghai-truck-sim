import copy
import io
import json
from pathlib import Path
import tempfile
import unittest
import zipfile

from trucksim.candidates import CHECKS, RULE_VERSION, STAGE, evaluate, import_register, save_records, local_catalog


def fixture():
    context={'scale':1000,'combination':{'A':1000},'background':'week-1','network':'grid-1','control':'mode-1','rules':RULE_VERSION}
    return {'stage':STAGE,'evaluated_at':'2026-10-15T10:00:00+08:00','station':{'id':'A','name':'测试站'},
            'proposal':{'id':'original','name':'原方案','scale_kw':1000},'context':context,
            'checks':[{'id':key,'status':'pass','reason':name+'满足','evidence':[{'source':'test.json','locator':'/'+key,
                        'version':'v1','criterion':'独立合成验收用例','state':'valid','station_id':'A','proposal_id':'original','binding':copy.deepcopy(context)}]} for key,name in CHECKS.items()]}


def check(r,key):return next(x for x in r['checks'] if x['id']==key)
def conditional(r):
    c=check(r,'external');c['status']='conditional';c['conditions']=[{'text':'落实通道授权','verified':True,'verification':'路径已核定',
        'closure_evidence':'授权文件','owner':'建设方','closed':False}]


class CandidateTests(unittest.TestCase):
    def test_four_states(self):
        r=fixture();self.assertEqual(evaluate(r)['decision']['color'],'green')
        conditional(r);self.assertEqual(evaluate(r)['decision']['color'],'yellow')
        check(r,'capacity')['evidence']=[];self.assertEqual(evaluate(r)['decision']['color'],'gray')
        check(r,'voltage')['status']='fail';self.assertEqual(evaluate(r)['decision']['color'],'red')

    def test_capacity_pass_voltage_fail_and_residual_overload(self):
        r=fixture();check(r,'voltage')['status']='fail'
        self.assertEqual(evaluate(r)['decision']['blockers'],['voltage'])
        check(r,'voltage')['status']='pass';check(r,'capacity')['status']='fail'
        self.assertEqual(evaluate(r)['decision']['color'],'red')

    def test_blocker_retains_missing_evidence(self):
        r=fixture();check(r,'capacity')['status']='fail';r['checks'].remove(check(r,'external'))
        d=evaluate(r)['decision'];self.assertEqual(d['color'],'red');self.assertEqual(d['pending'],['external'])

    def test_missing_retains_known_conditions_and_promises_are_gray(self):
        r=fixture();conditional(r);check(r,'voltage')['evidence']=[]
        d=evaluate(r)['decision'];self.assertEqual(d['color'],'gray');self.assertEqual(len(d['conditions']),1)
        r=fixture();conditional(r);check(r,'external')['conditions'][0]['verified']=False
        self.assertEqual(evaluate(r)['decision']['color'],'gray')

    def test_original_and_alternative_never_overwrite(self):
        r=fixture();check(r,'capacity')['status']='fail';a=copy.deepcopy(r)
        a['proposal']['id']='limited';check(a,'capacity')['status']='pass';conditional(a)
        for c in a['checks']:
            for e in c['evidence']:e['proposal_id']='limited'
        with tempfile.TemporaryDirectory() as d:
            saved=save_records([r,a],d);self.assertEqual([x['decision']['color'] for x in saved],['red','yellow'])
            save_records([r],d);self.assertEqual(len(local_catalog(d)['records']),2)

    def test_joint_capacity_must_be_recomputed(self):
        r=fixture();self.assertEqual(evaluate(r)['decision']['color'],'green')
        r['context']['combination']={'A':1000,'B':1000}
        self.assertEqual(evaluate(r)['decision']['color'],'gray')
        for c in r['checks']:
            for e in c['evidence']:e['binding']=copy.deepcopy(r['context'])
        check(r,'capacity')['status']='fail'
        self.assertEqual(evaluate(r)['decision']['color'],'red')

    def test_control_failure_is_required_by_proposal(self):
        r=fixture();r['proposal']['requires_control']=True
        self.assertIn('control_failure',evaluate(r)['decision']['pending'])
        c=copy.deepcopy(check(r,'controls'));c['id']='control_failure';c['status']='fail';r['checks'].append(c)
        self.assertEqual(evaluate(r)['decision']['color'],'red')

    def test_conflict_failure_expiry_and_recheck(self):
        for state in ('conflict','solver_failed','stale'):
            r=fixture();check(r,'capacity')['evidence'][0]['state']=state
            self.assertEqual(evaluate(r)['decision']['color'],'gray')
            check(r,'external')['status']='fail';self.assertEqual(evaluate(r)['decision']['color'],'red')
        r=fixture();e=check(r,'capacity')['evidence'][0];e['valid_until']='2026-10-14T00:00:00+00:00'
        old=evaluate(r);self.assertEqual(old['decision']['color'],'gray')
        e['valid_until']='2027-01-01T00:00:00+00:00';new=evaluate(r)
        self.assertEqual(new['decision']['color'],'green');self.assertNotEqual(old['assessment_id'],new['assessment_id'])

    def test_stale_but_independent_blocker_survives(self):
        r=fixture();check(r,'external')['status']='fail';r['context']['background']='week-2'
        d=evaluate(r)['decision'];self.assertEqual(d['color'],'red');self.assertEqual(d['blockers'],['external']);self.assertIn('capacity',d['pending'])

    def test_scale_and_identity_change_invalidate(self):
        r=fixture();r['proposal']['scale_kw']=2000
        self.assertEqual(evaluate(r)['decision']['color'],'gray')
        r=fixture();r['station']['id']='B';self.assertEqual(evaluate(r)['decision']['color'],'gray')

    def test_condition_closure_needs_acceptance(self):
        r=fixture();conditional(r);c=check(r,'external')['conditions'][0];c['closed']=True
        self.assertEqual(evaluate(r)['decision']['color'],'gray')
        c['closure_reference']='acceptance.json#route';self.assertEqual(evaluate(r)['decision']['color'],'green')

    def test_unregistered_stress_does_not_set_colour(self):
        r=fixture();c=copy.deepcopy(check(r,'capacity'));c['id']='exploratory';c['status']='fail';r['checks'].append(c)
        self.assertEqual(evaluate(r)['decision']['color'],'green')
        r['additional_required']=[{'id':'exploratory','name':'登记压力工况','trigger':'项目要求'}]
        self.assertEqual(evaluate(r)['decision']['color'],'red')

    def test_no_manual_colour_and_missing_scope_not_shrunk(self):
        r=fixture();r['checks']=[];r['decision']={'color':'green'}
        d=evaluate(r)['decision'];self.assertEqual(d['color'],'gray');self.assertEqual(d['required_count'],6)
        r=fixture();r['context']['rules']='unknown';self.assertEqual(evaluate(r)['decision']['color'],'gray')

    def test_formula_register_not_capacity(self):
        b=io.BytesIO()
        with zipfile.ZipFile(b,'w') as z:
            z.writestr('xl/workbook.xml','<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="场站评分录入表" r:id="rId1"/></sheets></workbook>')
            z.writestr('xl/_rels/workbook.xml.rels','<Relationships><Relationship Id="rId1" Target="worksheets/sheet1.xml"/></Relationships>')
            z.writestr('xl/worksheets/sheet1.xml','<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData><row r="3"><c r="B3" t="inlineStr"><is><t>测试区</t></is></c><c r="C3" t="inlineStr"><is><t>合成地址</t></is></c><c r="G3"><f>E3*F3</f><v>12800</v></c></row></sheetData></worksheet>')
        r=import_register(b.getvalue())[0]
        self.assertEqual(r['decision']['color'],'gray');self.assertIsNone(r['proposal']['scale_kw']);self.assertIsNone(r['station']['coordinates'])
        self.assertEqual(r['source_register']['cells']['G']['formula'],'E3*F3')

    def test_public_projection_replay_and_scoped_attribution(self):
        root=Path(__file__).resolve().parents[1];index=json.loads((root/'web/candidates-index.json').read_text());data=json.loads((root/'web'/index['current']).read_text())
        self.assertEqual({r['decision']['color'] for r in data['records']},{'red','yellow','green','gray'})
        for r in data['records']:
            self.assertEqual(evaluate(r),r)
            self.assertTrue(r['public']);self.assertNotIn('source_register',r)
        r=next(r for r in data['records'] if r['case_id']=='winter-background' and r['station']['id']=='S1' and r['proposal']['id']=='capacitor')
        self.assertEqual(r['decision']['color'],'red')
        self.assertEqual(check(r,'voltage')['status'],'pass');self.assertEqual(check(r,'capacity')['status'],'fail')
        s3=next(r for r in data['records'] if r['case_id']=='winter-background' and r['station']['id']=='S3' and r['proposal']['id']=='unmanaged')
        self.assertNotIn('UZT1',[e.get('object') for e in check(s3,'capacity')['evidence']])


if __name__=='__main__':unittest.main()
