// Projection and regression checks against the frozen public records.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import zlib from 'node:zlib';
import {qualitySummary,nodeImpact,capacitySummary,extreme} from '../web/assessment.js';
const root=new URL('../output/quality/public/',import.meta.url);
const index=JSON.parse(fs.readFileSync(new URL('index.json',root)));
let cases=0;
for(const entry of Object.values(index.records)){
 const d=JSON.parse(zlib.gunzipSync(fs.readFileSync(new URL(entry.result,root))));
 for(const c of Object.values(d.cases)){
  const s=qualitySummary(c,d.cases.baseline);
  assert.equal(s.complete,true);assert.equal(s.users.length,4);
  assert.equal(s.backgroundVoltageNodes,c.power_quality.paired_deltas.filter(p=>p.background_voltage_exceedance_steps>0).length);
  assert.equal(s.addedVoltageNodes,c.power_quality.paired_deltas.filter(p=>p.new_voltage_exceedance_steps>0).length);
  for(const id of ['ZLV1','ZLV2','ZLV3','ZLV4']){
   const x=nodeImpact(c,d.cases.baseline,id,88);
   assert.equal(x.voltageDelta,c.power_quality.trace[id][88].voltage_min_pu-d.cases.baseline.power_quality.trace[id][88].voltage_min_pu);
   assert.equal(x.thdDelta,c.power_quality.trace[id][88].thdu_pct-d.cases.baseline.power_quality.trace[id][88].thdu_pct);
   assert.equal(x.minimum.voltage_min_pu,Math.min(...c.power_quality.trace[id].map(r=>r.voltage_min_pu)));
   assert.equal(x.maximum.thdu_pct,Math.max(...c.power_quality.trace[id].map(r=>r.thdu_pct)));
  }
  const failed=structuredClone(c);failed.power_quality.status='failed';failed.power_quality.failures=[{step:12}];
  assert.equal(qualitySummary(failed,d.cases.baseline).voltageStatus,'未完整评估');
  assert.equal(qualitySummary(failed,d.cases.baseline).addedVoltageNodes,null);
  const missing=structuredClone(c);delete missing.power_quality.nodes[0].criteria.thdu_pct;
  assert.equal(qualitySummary(missing,d.cases.baseline).harmonicStatus,'未完整评估');
  const incomplete=structuredClone(c);delete incomplete.power_quality.nodes[0].voltage_min_pu;
  assert.equal(qualitySummary(incomplete,d.cases.baseline).voltageStatus,'未完整评估');
  cases++;
 }
 const zero=nodeImpact(d.cases.baseline,d.cases.baseline,'ZLV2',88);assert.equal(zero.voltageDelta,0);assert.equal(zero.thdDelta,0);
}
assert.equal(extreme([{step:1,v:3},{step:2,v:3}],'v').step,1);
assert.equal(extreme([{step:0,v:null}],'v'),null);
const empty={metrics:{assets:[],shortfall_kwh:null}};assert.equal(capacitySummary(empty).capacity,'未完整评估');
const site=new URL('../output/pages-site/site/',import.meta.url),catalog=JSON.parse(fs.readFileSync(new URL('data/index.json',site)));
for(const plan of ['existing','ordered','expanded']){
 const r=JSON.parse(zlib.gunzipSync(fs.readFileSync(new URL(catalog.scenarios['2027-medium-'+plan+'-normal'].result,site))));
 const s=capacitySummary(r);assert.equal(s.service,plan==='expanded'?'运输电量满足':'存在车辆欠充');
 assert.equal(s.capacity,plan==='existing'?'存在容量越限':'登记有功限额内');
}
console.log(JSON.stringify({passed:true,qualityCases:cases,checks:['paired deltas','extreme timestamps','background versus added','solver failure','missing criteria','missing values','zero increment','legacy capacity and service']}));
