"""Exercise 1.1 import, local study generation and the display/export contract."""
import gzip
import io
import json
import sys
import time
import urllib.request
import zipfile
from pathlib import Path

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from test_quality import short_task

BASE=sys.argv[1] if len(sys.argv)>1 else 'http://127.0.0.1:8785'


def request(path,value=None):
    data=json.dumps(value).encode() if value is not None else None
    return urllib.request.urlopen(urllib.request.Request(BASE+path,data=data),timeout=60).read()


def wait(jid):
    for _ in range(600):
        job=json.loads(request('/api/jobs/'+jid))
        if job['status']=='completed':return job['result']
        if job['status']=='failed':raise AssertionError(job['error'])
        time.sleep(.5)
    raise AssertionError('quality job timeout')


checks={}
checks['page']=b'quality.js' in request('/quality.html')
checks['assets']=len(request('/quality.js'))>1000 and len(request('/quality.css'))>1000
cached=json.loads(gzip.decompress(request('/quality-data/summer-normal.json.gz')))
checks['cached_week']=len(cached['cases']['ordered']['timestamps'])==672
job=json.loads(request('/api/import',short_task()));result=wait(job['id'])
checks['input_1_1']=result['schema_version']=='1.1' and result['power_quality']['status']=='completed'
job=json.loads(request('/api/quality',{'season':'summer','stress':'normal'}));print('Computing local study',flush=True)
shown=wait(job['id'])
checks['local_matches_cache']=shown==cached
with zipfile.ZipFile(io.BytesIO(request('/api/export/'+job['id']))) as z:
    checks['shared_spatial']='spatial.json' in z.namelist()
    checks['full_evidence']=all(json.loads(z.read(f'cases/{p}/result.json'))['power_quality']['status']=='completed' for p in shown['cases'])
Path('output/电能质量接口验证.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2))
print(json.dumps(checks,ensure_ascii=False,indent=2));assert all(checks.values())
