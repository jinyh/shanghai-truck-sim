# GitHub Pages在线示范

- 访问地址：https://jinyh.github.io/shanghai-truck-sim/
- 仓库：https://github.com/jinyh/shanghai-truck-sim
- 构建入口：`tools/build_pages.py`
- 发布检出：`output/pages-site/`
- 部署与验证记录：`output/github-pages-deployment.json`

GitHub Pages托管静态文件。在线版加载同一工程模型计算的375个合成场景：2026—2030年、三种增长、五种配置和五种运行工况。支持逐站及上级设备图表、负荷回放、15组四年方案比较、114个合格基准可调记录、研究准入结果及逐场景复算包下载。

2027年中增长正常工况的现状常规、现状有序和提前扩建方案提供完整288时段交流潮流记录。其余组合的交流按钮明确提示使用本地版校核。所有展示结果保留输入哈希、源码哈希和证据等级；不年化72小时结果。

真实数据导入、新增工况求解、完整交流校核和客户数据留存使用本地工作台。在线版的数据页提供本地源码、固定版本依赖清单和数据模板；公开文件中只有合成输入及其结果。

更新合成场景或计算组件后，在原型目录运行：

```sh
.venv/bin/python tools/build_pages.py
.venv/bin/python tools/verify_pages.py
```

检查页面后，在 `output/pages-site/` 提交和推送更新。GitHub Actions会校验所有静态文件哈希、375个场景的来源与能量平衡、可调记录和下载包，然后发布 `site/`。

本次部署同时核验了网页下载的本地源码与场景复算包：输入、指标及完整逐会话轨迹均一致。工作流成功后还应检查线上入口、场景切换和下载链接。
