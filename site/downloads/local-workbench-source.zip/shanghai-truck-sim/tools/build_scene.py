"""Small, immutable replay projections from the existing calculation archives."""
import gzip
import hashlib
import json
from pathlib import Path
import zipfile

ROOT=Path(__file__).resolve().parents[1]


def write_gzip(folder, name, data):
    blob=gzip.compress(json.dumps(data,ensure_ascii=False,separators=(',',':'),allow_nan=False).encode(),mtime=0)
    sha=hashlib.sha256(blob).hexdigest();filename=f'{name}-{sha[:16]}.json.gz'
    (folder/filename).write_bytes(blob)
    return {'file':filename,'sha256':sha,'bytes':len(blob)}


def build_scene():
    source=ROOT/'output/quality/public';out=ROOT/'web/scene-data';out.mkdir(parents=True,exist_ok=True)
    index=json.loads((source/'index.json').read_text());candidates=json.loads((ROOT/'web/candidates-index.json').read_text())
    catalog={'schema_version':'scene-replay-1.0','candidate_version':candidates['version'],'records':{},'public':True,
             'cases':{'summer-normal':'夏季 · 正常代表周','winter-background':'冬季 · 背景偏高代表周'},
             'plans':{'unmanaged':'常规充电','ordered':'有序充电','capacitor':'有序＋补偿','filter':'有序＋滤波','baseline':'无新增重卡'}}
    for case in catalog['cases']:
        entry=index['records'][case];archive=source/entry['export']
        assert hashlib.sha256(archive.read_bytes()).hexdigest()==entry['export_sha256']
        with zipfile.ZipFile(archive) as z:
            geo=json.loads(z.read('spatial.json'))
            for plan in catalog['plans']:
                r=json.loads(z.read(f'cases/{plan}/result.json'));task=json.loads(z.read(f'cases/{plan}/task.json'));q=r['power_quality']
                sessions={x['id']:x for x in r['metrics']['sessions']}
                vehicles=[]
                if plan!='baseline':
                    for v in task['transport']['vehicles']:
                        trips=[]
                        for t in task['transport']['trips']:
                            if t['vehicle_id']!=v['id']:continue
                            s=sessions.get(t.get('session_id'));ledger=next(x for x in r['transport']['ledger'] if x['trip_id']==t['id'])
                            trips.append({**t,'session':s,'ledger':ledger,'power_kw':r['solution']['power_by_session'].get(t.get('session_id'),[0]*task['periods'])})
                        vehicles.append({**v,'station_id':trips[0]['session']['station_id'] if trips and trips[0]['session'] else None,'trips':trips})
                routes={}
                for route in task['transport']['routes']:
                    routes[route['station_id']]={**route,'outward_coordinates':[geo['nodes'][str(n)] for n in route['outward'].get('nodes',[])],
                                               'inward_coordinates':[geo['nodes'][str(n)] for n in route['inward'].get('nodes',[])]}
                equipment={a['id']:{'kind':a['kind'],'loading_pct':[next(x['loading_pct'] for x in row['assets'] if x['id']==a['id']) for row in q['equipment']]} for a in q['equipment'][0]['assets']}
                data={'schema_version':'scene-replay-1.0','case_id':case,'plan':plan,'public':True,'evidence':'public_synthetic',
                      'input_hash':r['input_hash'],'source_export':'quality-data/'+entry['export'],'source_sha256':entry['export_sha256'],
                      'timestamps':r['timestamps'],'step_minutes':task['step_minutes'],'charging_efficiency':task['charging_efficiency'],
                      'stations':task['stations'],'vehicles':vehicles,'routes':routes,'station_power_kw':r['metrics']['station_power_kw'],
                      'operating_states':q['operating_states'],'equipment':equipment,'nodes':q['nodes'],'trace':q['trace'],
                      'network':{k:task['electrical'][k] for k in ('buses','lines','transformers','station_buses')},
                      'status':q['status'],'failures':q['failures'],'transport_issues':r['transport'].get('issues',[]),
                      'scope':'计算值保持15分钟；途中位置和行程电量为任务时间插值；场内布局和移动示意。'}
                catalog['records'][case+'-'+plan]={**write_gzip(out,case+'-'+plan,data),'input_hash':r['input_hash']}
            if case=='summer-normal':
                geometry={k:geo[k] for k in ('bounds','source','landuse')}
                geometry['roads']={'features':[f for f in geo['roads']['features'] if f['properties']['highway'] in ('motorway','trunk','primary','secondary','tertiary')]}
                catalog['geometry']=write_gzip(out,'geography',geometry)
    raw=json.dumps(catalog,sort_keys=True,ensure_ascii=False).encode();version=hashlib.sha256(raw).hexdigest()[:16];catalog['version']=version
    (out/f'index-{version}.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n')
    (out/'index.json').write_text(json.dumps({'version':version,'file':f'index-{version}.json'},indent=2)+'\n')
    print(json.dumps({'scene_version':version,'cases':len(catalog['records']),'compressed_bytes':sum(x['bytes'] for x in catalog['records'].values())}))
    return catalog


if __name__=='__main__':build_scene()
