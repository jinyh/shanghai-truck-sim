"""Publish only frozen public engineering results and labelled synthetic prerequisites."""
import gzip
import hashlib
import json
from pathlib import Path
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from trucksim.candidates import RULE_VERSION, STAGE, evaluate, digest


def build_candidates():
    folder = ROOT/'output/quality/public'
    index = json.loads((folder/'index.json').read_text())
    records = []
    for case in ('summer-normal', 'winter-background'):
        entry = index['records'][case]
        archive = (folder/entry['export']).read_bytes()
        assert hashlib.sha256(archive).hexdigest() == entry['export_sha256']
        with zipfile.ZipFile(folder/entry['export']) as z:
            baseline = json.loads(z.read('cases/baseline/result.json'))
            for plan in ('unmanaged', 'ordered', 'capacitor', 'filter'):
                r = json.loads(z.read(f'cases/{plan}/result.json'))
                task = json.loads(z.read(f'cases/{plan}/task.json'))
                q = r['power_quality']; bq = baseline['power_quality']
                assert q['status'] == 'completed' and not q['failures']
                feeder_of = {s['id']: s['feeder_id'] for s in task['stations']}
                tx_of = {f['id']: f['transformer_id'] for f in task['feeders']}
                for s in task['stations']:
                    sid = s['id'];num = sid[1:];fid = s['feeder_id'];tid = tx_of[fid]
                    peers = [x['id'] for x in task['stations'] if x['feeder_id'] == fid]
                    context = {'scale': s['connection_limit_kw'], 'combination': {x['id']: {'scale_kw': x['connection_limit_kw'], 'dispatch': plan} for x in task['stations']},
                               'background': case, 'network': digest(task['electrical']), 'control': plan+'-synthetic-v1', 'rules': RULE_VERSION}
                    source = 'quality-data/'+entry['export']
                    def ev(locator, criterion, **extra):
                        return {'state': 'valid', 'source': source, 'locator': f'cases/{plan}/result.json#'+locator,
                                'station_id':sid,'proposal_id':plan,
                                'version': r['input_hash'], 'record_sha256': entry['export_sha256'],
                                'binding': context.copy(), 'criterion': criterion, 'evidence_kind': '合成工程计算', **extra}
                    checks = []
                    sessions = [x for x in r['metrics']['sessions'] if x['station_id'] == sid]
                    ledger = [x for x in r['transport']['ledger'] if x['vehicle_id'].startswith(sid+'V')]
                    shortfall = sum(x['shortfall_kwh'] for x in sessions)
                    energy_failed = [x for x in ledger if x['after_charge_kwh']+1e-5 < x['minimum_departure_kwh'] or x['after_trip_kwh'] < -1e-5]
                    checks.append({'id': 'demand', 'status': 'fail' if shortfall > 1e-5 or energy_failed else 'pass',
                                   'reason': f'{sid}：{len(ledger)}次运输任务，欠充 {shortfall:.4f} kWh',
                                   'evidence': [ev(f'metrics/sessions[station_id={sid}];transport/ledger', '欠充≤0.00001 kWh数值容差；行程及离站电量满足任务要求', actual=shortfall, unit='kWh')]})
                    # Attribute equipment to the actual feeder subtree and common upstream path.
                    asset_ids = {tid, 'L'+fid, 'LS'+num, 'UST'+num}
                    for peer in peers: asset_ids.update({'LZ'+peer[1:], 'UZT'+peer[1:]})
                    eq_evidence = []
                    for aid in sorted(asset_ids):
                        values = [(row['step'], next(a['loading_pct'] for a in row['assets'] if a['id'] == aid)) for row in q['equipment']]
                        step, actual = max(values, key=lambda x:x[1])
                        before = next(a['loading_pct'] for a in bq['equipment'][step]['assets'] if a['id'] == aid)
                        eq_evidence.append(ev(f'power_quality/equipment/{step}/assets[id={aid}]', '登记设备基波电流额定值：负载率≤100%；谐波附加温升未评估',
                                              actual=actual, baseline=before, delta=actual-before, limit=100, margin=100-actual, unit='%',
                                              object=aid, time=r['timestamps'][step], step=step, related_stations=peers if aid not in ('LS'+num,'UST'+num) else [sid],
                                              attribution='背景已越限' if before > 100+1e-6 else '新增越限' if actual > 100+1e-6 else '未越限'))
                    # Retain operating active-power limits separately from equipment ratings.
                    for a in r['metrics']['assets']:
                        if a['id'] not in (sid, fid, tid): continue
                        step=a['worst_step']; actual=a['max_loading_pct']
                        eq_evidence.append(ev(f'metrics/assets[id={a["id"]}]', '登记运行有功限额：负载率≤100%', actual=actual, limit=100, margin=100-actual, unit='%', object=a['id']+'（有功限额）', time=r['timestamps'][step], step=step))
                    worst=max(eq_evidence,key=lambda x:x['actual'])
                    checks.append({'id':'capacity','status':'fail' if any(e['actual']>100+1e-6 for e in eq_evidence) else 'pass',
                                   'reason': f'{worst["object"]}最高负载率 {worst["actual"]:.2f}%'+('，需调整方案' if worst['actual']>100+1e-6 else '，在登记限额内'), 'evidence':eq_evidence})
                    nodes=[n for n in q['nodes'] if n['id'] in ['PCC'+num,'SLV'+num]+['ZLV'+x[1:] for x in peers]]
                    for key in ('voltage','harmonics'):
                        es=[];fails=[]
                        for n in nodes:
                            trace=q['trace'][n['id']];crit=n['criteria']
                            if key=='voltage':
                                lo=crit['voltage_min_pu'];hi=crit['voltage_max_pu']
                                row=max(trace,key=lambda x:max(lo-x['voltage_min_pu'],x['voltage_max_pu']-hi))
                                field='voltage_min_pu' if lo-row['voltage_min_pu']>=row['voltage_max_pu']-hi else 'voltage_max_pu'
                                actual=row[field];limit=f'{lo}—{hi}';margin=min(actual-lo,hi-actual)
                                threshold=crit['voltage_standard']+'；'+crit['statistics'];bad=n['voltage_exceedance_steps']
                            else:
                                # Choose worst ratio across THD and every individual harmonic, not THD alone.
                                choices=[(x['thdu_pct']/crit['thdu_pct'],x,'thdu_pct',x['thdu_pct'],crit['thdu_pct']) for x in trace]
                                choices += [(v/crit['individual_harmonic_pct'][str(h)],x,h,v,crit['individual_harmonic_pct'][str(h)]) for x in trace for h,v in zip(range(2,26),x['harmonic_voltage_pct'])]
                                _,row,field,actual,limit=max(choices,key=lambda x:x[0]);margin=limit-actual
                                threshold=crit['harmonic_standard']+'；'+crit['statistics'];bad=n['harmonic_exceedance_steps']
                            step=row['step'];br=bq['trace'][n['id']][step]
                            before=br[field] if isinstance(field,str) else br['harmonic_voltage_pct'][field-2]
                            es.append(ev(f'power_quality/trace/{n["id"]}/{step}',threshold, actual=actual, baseline=before, delta=actual-before,
                                         limit=limit, margin=margin, unit='pu' if key=='voltage' else '%', object=n['id']+' · '+n['name'], step=step, time=r['timestamps'][step],
                                         metric=field if isinstance(field,str) else f'{field}次谐波', related_stations=peers,
                                         attribution='背景已越限' if br['voltage_status' if key=='voltage' else 'harmonic_status']=='exceeds_reference' else '新增越限' if bad else '未越限',
                                         link=f'quality.html?season={case.split("-")[0]}&stress={case.split("-")[1]}&plan={plan}&node={n["id"]}&step={step}&view=electrical'))
                            if bad:fails.append(n['id'])
                        checks.append({'id':key,'status':'fail' if fails else 'pass','reason': ('、'.join(fails)+'超出登记参考范围') if fails else ('所列接入点与同馈线用户'+('电压' if key=='voltage' else '2—25次谐波')+'在参考范围内'), 'evidence':es})
                    def assumption(check_id, text, status='pass', conditions=None):
                        e={'state':'valid','station_id':sid,'proposal_id':plan,'source':'candidate-assumptions.json','locator':f'/{sid}/{check_id}', 'version':'synthetic-prerequisites-1', 'criterion':'本阶段登记的合成前置条件；仅演示流程', 'binding':context.copy(), 'evidence_kind':'合成手续与运行保障假设'}
                        return {'id':check_id,'status':status,'reason':text,'evidence':[e],'conditions':conditions or []}
                    conditions=[{'id':'route-permit','text':'取得已核定电缆通道的使用授权','owner':'建设及通道权属方（角色待确认）','verified':True,
                                 'verification':'合成踏勘记录已确认路径、空间及施工条件，授权待签','closure_evidence':'通道权属方使用授权记录','closed':False}]
                    checks.append(assumption('external','通道路径已核定，使用授权待落实（合成）','conditional',conditions) if sid=='S2' else
                                  {'id':'external','status':'unknown','reason':'外线通道尚未核实；需建设与权属方补充路径和权属依据','evidence':[]} if sid=='S4' else
                                  assumption('external','外线路径、权属及本阶段手续已核实（合成）'))
                    checks.append(assumption('controls','常规充电不依赖集中调度；设备限值和运行职责已登记（合成）' if plan=='unmanaged' else '有序调度运行方式已登记；控制失效保障须单独核验（合成）'))
                    if plan!='unmanaged':checks.append({'id':'control_failure','status':'unknown','reason':'本四站案例尚无控制失效必需工况记录，需补充失效后的联合复核','evidence':[]})
                    item={'stage':STAGE,'evaluated_at':'2026-10-15T10:00:00+08:00','public':True,'evidence_level':'public_synthetic',
                          'case_id':case,'station':{'id':sid,'name':s['name'],'coordinates':[s['longitude'],s['latitude']], 'coordinate_system':'EPSG:4326'},
                          'proposal':{'id':plan,'name':{'unmanaged':'常规充电','ordered':'有序充电','capacitor':'有序＋无功补偿','filter':'有序＋谐波滤波'}[plan],
                                      'scale_kw':s['connection_limit_kw'],'requires_control':plan!='unmanaged'},'context':context,'checks':checks,
                          'scope':f'四站联合接入；{case}七天代表周；{sid}所属{fid}、上级{tid}。用户观测范围为本馈线已登记用户。',
                          'period': [r['timestamps'][0],r['timestamps'][-1]],'source_export':source,'source_input_hash':r['input_hash'],
                          'not_evaluated':['其他馈线用户的增量归因','短路','保护','转供','可靠性','谐波电流分配','谐波附加温升','闪变与暂降','真实手续与现场验收'],
                          'next_steps':['按具体设备瓶颈论证容量、供电点或建设时序调整；未计算的措施标为待论证','补齐真实供电映射、同期负荷与监测，复核登记判据','接入组合或运行条件变化后重新评估；绿色不代表容量已预留']}
                    records.append(evaluate(item))
    assumptions={sid:{'external':'合成流程记录：S1/S3路径及手续齐备；S2通道踏勘已完成但授权待落实；S4缺少核实记录。不是上海实际工程资料。',
                      'controls':'合成设备限值与运行职责；有序方案的控制失效工况未覆盖，作为必需缺项保留。'} for sid in ('S1','S2','S3','S4')}
    (ROOT/'web/candidate-assumptions.json').write_text(json.dumps(assumptions,ensure_ascii=False,indent=2)+'\n')
    geo=json.loads(gzip.decompress((folder/index['records']['summer-normal']['result']).read_bytes()))['spatial']
    payload={'bounds':geo['bounds'],'schema_version':'candidates-1.0','public':True,'rule_version':RULE_VERSION,'stage':STAGE,
             'default_case':'summer-normal','default_proposal':'unmanaged','cases':{'summer-normal':'夏季 · 正常代表周','winter-background':'冬季 · 背景偏高代表周'},'records':records}
    version=digest(payload)[:16];payload['version']=version
    name=f'candidates-{version}.json'
    (ROOT/'web'/name).write_text(json.dumps(payload,ensure_ascii=False,indent=2)+'\n')
    (ROOT/'web/candidates-index.json').write_text(json.dumps({'current':name,'version':version},ensure_ascii=False,indent=2)+'\n')
    # Label-free map backdrop; the interactive view draws accessible markers.
    svg=(ROOT/'web/overview-map.svg').read_text()
    svg=svg[:svg.index('<circle')]+svg[svg.rindex('<text x="20"'):]
    (ROOT/'web/candidates-map.svg').write_text(svg)
    return payload


if __name__=='__main__':
    r=build_candidates();print(json.dumps({'records':len(r['records']),'colors':sorted({x['decision']['color'] for x in r['records']}),'version':r['version']}))
