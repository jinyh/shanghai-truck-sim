"""Run with Blender 4.5.3 --background --python tools/make_scene_models.py.

Original stylised assets: dimensions/layout are illustrative, not surveyed.
Blender Z-up exports to glTF Y-up. Truck forward is Blender +Y (glTF -Z).
"""
import bpy
import math
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'web/assets/scene';OUT.mkdir(parents=True,exist_ok=True)
SOURCE=ROOT/'assets/scene';SOURCE.mkdir(parents=True,exist_ok=True)
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)


def mat(name,color,metal=0,rough=.55):
    m=bpy.data.materials.new(name);m.diffuse_color=(*color,1);m.use_nodes=True
    bs=m.node_tree.nodes.get('Principled BSDF');bs.inputs['Base Color'].default_value=(*color,1);bs.inputs['Metallic'].default_value=metal;bs.inputs['Roughness'].default_value=rough
    return m


ivory=mat('Warm porcelain',(.88,.91,.87));green=mat('Utility jade',(.12,.37,.29));mint=mat('Roof sage',(.37,.61,.51));glass=mat('Blue glass',(.16,.29,.32),.3,.2)
asphalt=mat('Warm asphalt',(.35,.39,.39));white=mat('Lane white',(.97,.97,.89));dark=mat('Rubber',(.055,.07,.075));steel=mat('Brushed alloy',(.55,.61,.61),.65,.3)
amber=mat('Safety amber',(.98,.67,.18));leaf=mat('Tree crowns',(.3,.53,.39));earth=mat('Planter',(.73,.76,.68));blue=mat('Battery blue',(.16,.45,.59));red=mat('Tail lamp',(.7,.1,.08))


def box(name,loc,size,material,bevel=.06):
    bpy.ops.mesh.primitive_cube_add(size=1,location=loc);o=bpy.context.object;o.name=name;o.dimensions=size
    bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);o.data.materials.append(material)
    if bevel:
        mod=o.modifiers.new('Manufactured edges','BEVEL');mod.width=bevel;mod.segments=2
        o.modifiers.new('Weighted surface normals','WEIGHTED_NORMAL')
    return o


def cylinder(name,loc,radius,depth,material,rotation=(0,0,0),vertices=16):
    bpy.ops.mesh.primitive_cylinder_add(vertices=vertices,radius=radius,depth=depth,location=loc,rotation=rotation);o=bpy.context.object;o.name=name;o.data.materials.append(material)
    for p in o.data.polygons:p.use_smooth=True
    return o


def text(name,body,loc,size,material,rotation=(0,0,0)):
    bpy.ops.object.text_add(location=loc,rotation=rotation);o=bpy.context.object;o.name=name;o.data.body=body;o.data.size=size;o.data.align_x='CENTER';o.data.extrude=.008;o.data.materials.append(material)
    bpy.ops.object.convert(target='MESH');return bpy.context.object


def export(name):
    bpy.ops.wm.save_as_mainfile(filepath=str(SOURCE/(name+'.blend')))
    bpy.ops.export_scene.gltf(filepath=str(OUT/(name+'.glb')),export_format='GLB',export_apply=True,export_extras=True)


# Detailed charging yard: four oversized demonstration bays, sheltered chargers,
# switchgear, landscape, one low administration building, logistics context.
box('S1|yard',(0,0,-.4),(95,73,.8),ivory,.7)
box('S1|driveway',(0,-21,.04),(91,13,.15),asphalt,.1)
box('S1|bay-apron',(0,1,.05),(54,30,.14),asphalt,.1)
for x in (-24,-12,0,12,24):box('S1|bay-line',(x,1,.15),(.15,28,.025),white,0)
for x in range(-40,45,8):box('S1|road-dash',(x,-21,.15),(4,.16,.025),white,0)
for i,x in enumerate((-18,-6,6,18)):
    text(f'PORT{i}|number',f'{i+1:02}',(x,-11,.17),1.4,white)
    box(f'PORT{i}|island',(x,14,.35),(5,3,.6),ivory,.3)
    box(f'PORT{i}|charger',(x,14,1.9),(1.35,1.1,2.6),green,.15)
    box(f'PORT{i}|screen',(x,13.43,2.3),(.85,.05,.65),glass,.03)
    box(f'PORT{i}|indicator',(x,13.4,2.85),(.7,.06,.12),mint,.02)
    text(f'PORT{i}|power','320',(x,13.37,1.7),.25,ivory,(math.pi/2,0,0))
    for side in (-1,1):
        cylinder(f'PORT{i}|bollard',(x+side*1.8,13,.8),.13,1.3,amber)
        # Cable loop, open charging connector represented by a dark hose.
        bpy.ops.mesh.primitive_torus_add(major_segments=20,minor_segments=6,location=(x+side*.9,14,1.25),major_radius=.55,minor_radius=.045,rotation=(math.pi/2,0,0));bpy.context.object.data.materials.append(dark);bpy.context.object.name=f'PORT{i}|cable'
for x in (-25,0,25):box('S1|canopy-column',(x,16,3),( .25,.25,6),steel)
box('S1|canopy',(0,15,6.2),(55,10,.45),mint,.2)
for x in range(-24,25,4):box('S1|roof-panel',(x,15,6.47),(3.7,9,.05),green,.02)
box('S1|office',(-36,10,2.8),(15,18,5.6),ivory,.3)
box('S1|office-roof',(-36,10,5.8),(16,19,.5),mint,.2)
for y in (4,9,14):box('S1|office-window',(-28.43,y,3),(.07,3.5,2),glass,.06)
box('S1|office-door',(-36,.95,1.6),(2,.08,3),glass)
text('S1|office-sign','ENERGY HUB',(-36,.86,4.1),.65,green,(math.pi/2,0,0))
box('UST1|pad',(35,12,.35),(13,18,.7),earth,.25)
box('UST1|transformer',(35,14,2.25),(5,6,3.8),mint,.25)
for x in (32.3,37.7):
    for y in range(12,17):box('UST1|cooling-fin',(x,y,2.2),(.2,.4,3.2),green,.03)
for x in (33.5,35,36.5):cylinder('UST1|bushing',(x,14,4.6),.17,.8,ivory)
box('UST1|switchgear',(35,5,1.8),(8,3,3),ivory,.15)
for x in (32.3,35,37.7):box('UST1|switch-door',(x,3.44,1.8),(2.4,.08,2.6),green,.04)
text('UST1|sign','1600 kVA',(35,10.92,2.4),.55,green,(math.pi/2,0,0))
for x,y in [(-43,-7),(-43,27),(-25,29),(-10,29),(8,29),(26,29),(44,26),(44,-6)]:
    box('landscape|planter',(x,y,.4),(3,3,.8),earth,.2);cylinder('landscape|trunk',(x,y,2),.18,3,green)
    for dx,dy,z,rad in [(0,0,4,1.8),(.7,0,4.8,1.4),(-.6,.3,4.6,1.4)]:
        bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=2,radius=rad,location=(x+dx,y+dy,z));o=bpy.context.object;o.name='landscape|crown';o.data.materials.append(leaf)
for x in (-45,45):
    cylinder('S1|streetlight',(x,-18,4),.12,8,steel);box('S1|lamp',(x,-17.6,8),(1.5,2,.2),ivory)
text('S1|ground-label','S1  /  PORT ENERGY',(0,-32,.08),2.1,green)
export('s1-yard')

bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
# Tractor and trailer, no external textures. Whole vehicle length ~16 m.
box('truck|chassis',(0,0,1),(2.45,15,.35),dark,.08)
box('truck|trailer',(0,-2.2,2.8),(2.75,10.2,3.3),ivory,.12)
box('truck|trailer-roof',(0,-2.2,4.5),(2.85,10.3,.16),mint,.07)
for x in (-1.4,1.4):
    box('truck|stripe',(x,-2.2,2.4),(.035,9.8,.38),green,.02)
    for y in range(-7,3):box('truck|panel-seam',(x,y,3.3),(.04,.035,2),steel,0)
box('truck|cab',(0,5.1,2.45),(2.8,3.6,3.6),green,.28)
box('truck|roof',(0,4.8,4.35),(2.8,3.1,.35),mint,.18)
box('truck|windshield',(0,6.94,3.3),(2.45,.06,1.25),glass,.09)
box('truck|bumper',(0,7.05,1.05),(2.9,.4,.45),ivory,.08)
box('truck|grille',(0,6.98,1.9),(1.6,.06,.4),dark,.04)
for x in (-1,1):box('truck|headlamp',(x,7.1,1.5),(.55,.08,.3),white,.06)
for side in (-1,1):
    box('truck|side-window',(side*1.42,5.3,3.25),(.04,2.2,1.15),glass,.06)
    box('truck|mirror',(side*1.67,6.25,3.2),(.22,.45,.75),dark,.05)
    box('truck|battery',(side*1.12,1.8,1.1),(.6,2.1,.6),blue,.08)
    for y in (5.5,2.2,1.0,-5.7,-6.8):
        cylinder('wheel|tire',(side*1.35,y,.8),.72,.42,dark,(0,math.pi/2,0),20)
        cylinder('wheel|hub',(side*1.59,y,.8),.39,.05,steel,(0,math.pi/2,0),16)
    box('truck|rear-light',(side*.95,-7.38,1.3),(.42,.08,.25),red,.02)
export('electric-truck')
print('Saved editable Blender sources and GLB models:',OUT)
