"""Stage the new public study without recomputing or changing legacy records."""
import hashlib
import io
import json
import shutil
import tomllib
import zipfile

from build_pages import ROOT,SITE,TARGET,LOCAL_README,PUBLIC_README,build_frontend


def stage_quality_pages(refresh_frontend=True):
    if refresh_frontend:build_frontend()
    source=ROOT/'output/quality/public';index=json.loads((source/'index.json').read_text())
    assert len(index['records'])==10 and all(r['days']==7 for r in index['records'].values())
    for name in ('quality.html','quality.css','quality.js'):
        shutil.copyfile(ROOT/'web'/name,SITE/name)
    destination=SITE/'quality-data';destination.mkdir(exist_ok=True)
    shutil.copyfile(source/'index.json',destination/'index.json')
    for record in index['records'].values():
        for name in ('result','export'):shutil.copyfile(source/record[name],destination/record[name])
    downloads=SITE/'downloads';downloads.mkdir(exist_ok=True)
    with zipfile.ZipFile(downloads/'data-templates.zip','w',zipfile.ZIP_DEFLATED) as z:
        for p in sorted((ROOT/'templates').iterdir()):
            if p.is_file():z.writestr(p.name,p.read_bytes())
        z.writestr('电能质量评估与数据接口.md',(ROOT/'docs/电能质量评估与数据接口.md').read_bytes())
    out=io.BytesIO();prefix='shanghai-truck-sim/'
    with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
        paths=[]
        for dirname in ('trucksim','web','templates','docs','tests'):
            paths.extend(p for p in (ROOT/dirname).rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc' and p.name!='材料清单.json')
        names=['pyproject.toml','uv.lock','start.command','README.md','data/public/source-manifest.json','data/public/shanghai-study-area.json']
        names += ['tools/'+n for n in ('prepare_geography.py','make_quality_input.py','build_quality.py','build_pages.py','stage_quality_pages.py','verify_pages.py')]
        paths.extend(ROOT/n for n in names)
        for p in sorted(paths):z.writestr(prefix+p.relative_to(ROOT).as_posix(),p.read_bytes())
        z.writestr(prefix+'安装与复算.md',LOCAL_README+'\n道路与电能质量入口：/quality.html。本地首次打开可点击“在本机重新计算”；公开预计算缓存不重复包含在源码包。\n冻结的公开地理数据库已随包提供，无须联网取数。1.1接口详见 docs/电能质量评估与数据接口.md。\n')
        packages=tomllib.loads((ROOT/'uv.lock').read_text())['package']
        z.writestr(prefix+'requirements-locked.txt','\n'.join(f"{p['name']}=={p['version']}" for p in packages if p.get('source',{}).get('registry'))+'\n')
    (downloads/'local-workbench-source.zip').write_bytes(out.getvalue())
    (TARGET/'README.md').write_text(PUBLIC_README+'\n新增 quality.html：冻结的公开OSM道路/用地 + 合成电气、运输与负荷参数。夏冬各5种工况、每种5类方案，共50个连续代表周案例；提供节点电压、2—25次谐波、共享供电影响、扫频和完整复算包。\n\n数据按ODbL署名 © OpenStreetMap contributors。数据源与原始PBF摘要在本地源码包 data/public/source-manifest.json。地理图层真实公开，站位和供电关系仅为等值演示。\n')
    (TARGET/'scripts/verify_site.py').write_bytes((ROOT/'tools/verify_pages.py').read_bytes())
    manifest={p.relative_to(SITE).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(SITE.rglob('*')) if p.is_file() and p.name!='manifest.json'}
    (SITE/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
    print(json.dumps({'quality_comparisons':10,'weekly_cases':50,'static_files':len(manifest)},ensure_ascii=False))


if __name__=='__main__':stage_quality_pages()
