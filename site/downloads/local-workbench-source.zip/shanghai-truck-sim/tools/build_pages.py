"""Build an allowlisted static, synthetic-only GitHub Pages demonstration."""
from __future__ import annotations
import gzip
import hashlib
import io
import json
import sys
import tomllib
import zipfile
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from trucksim.analysis import run,planning,flexibility
from trucksim.demo import make_demo,PLANS
from trucksim.io import export_bundle,export_analysis,templates
from trucksim.research import admission

TARGET=ROOT/'output'/'pages-site'
SITE=TARGET/'site'


def packed(path,value):
    if isinstance(value,dict) and 'task' in value:
        assert value['task']['metadata']['evidence']=='synthetic'
        assert 'original_import' not in value['task']['metadata']
    data=json.dumps(value,ensure_ascii=False,separators=(',',':'),allow_nan=False).encode()
    destination=SITE/path;destination.parent.mkdir(parents=True,exist_ok=True)
    destination.write_bytes(gzip.compress(data,mtime=0))
    return './'+path


def build_frontend():
    SITE.mkdir(parents=True,exist_ok=True)
    html=(ROOT/'web/planning.html').read_text()
    html=html.replace('href="/"','href="./"').replace('href="/style.css"','href="./style.css"')
    html=html.replace('<script type="module" src="/app.js"></script>','<script src="./static-api.js"></script><script type="module" src="./app.js?v=pages-v1.1"></script>')
    html=html.replace('本地离线计算','在线示范 · 已计算记录').replace('研究原型','合成示范')
    html=html.replace('调整建设与运行条件，查看服务保障和电网边界如何变化。','选择已登记的建设与运行场景，查看共享容量和履约结果。')
    html=html.replace('重新计算','查看评估').replace('测算 60 分钟窗口','查看 60 分钟记录').replace('运行全时窗校核','查看交流校核记录')
    html=html.replace('计算四年五类方案 ↗','查看四年五类方案 ↗').replace('运行准入筛查 ↗','查看准入筛查 ↗')
    html=html.replace('数据留在本机<br><span class="muted">没有现场指令或模型服务调用</span>','登记工况离线求解<br><span class="muted">页面读取结果，可下载本地版复算</span>')
    html=html.replace('从真实数据开始','获取本地计算版')
    html=html.replace('导入完整案例 JSON，或包含清单与 CSV 表的 ZIP。数据检查通过后进行本地计算；缺测、重复时戳和不明计量边界会直接报出。','在线版展示375个合成场景的已计算记录。下载本地版，可导入JSON/CSV、重新求解和执行交流校核。')
    html=html.replace('<label class="upload">选择数据文件<input type="file" id="import-file" accept=".json,.zip"></label>','<p><a class="button primary" href="./downloads/local-workbench-source.zip">下载本地版源码与数据模板 ↓</a></p>')
    html=html.replace('/api/templates.zip','./downloads/data-templates.zip').replace('/api/demo-input.json','./downloads/demo-input.json')
    html=html.replace('客户结果存放在本机 output/private。附表不会自动转化为调控认证或工程审批。','客户数据请在约定环境内使用本地版处理；在线版只包含合成输入，不提供数据上传接口。')
    html=html.replace('沿用左侧增长与压力工况。','读取左侧增长与压力工况对应的已计算记录。')
    html=html.replace('计算后显示工程对象','记录中包含工程对象').replace('选择情景后运行','选择情景后查看')
    html=html.replace('本地原型 v0.1','在线示范 v0.1')
    html=html.replace('<div id="status"','<div class="projection-scope">在线版读取375个登记工况；真实数据导入和新增求解使用本地版。</div><div id="status"')
    (SITE/'planning.html').write_text(html)
    script=(ROOT/'web/app.js').read_text()
    first=script.index('async function post(');last=script.index('async function action(',first)
    script=script[:first]+"const post=(path,body)=>window.truckStatic.post(path,body);\nconst wait=job=>window.truckStatic.wait(job);\n"+script[last:]
    script=script.replace("'/api/export/'+jid","window.truckStatic.exportURL(jid)")
    script=script.replace('/api/export/${j.id}','${window.truckStatic.exportURL(j.id)}')
    script=script.replace('renderAC();render();renderPlanningReport();','renderAC();window.truckStatic.configure(r);render();renderPlanningReport();').replace('status(`计算完成','status(`已载入计算记录')
    script=script.replace('请点击“重新计算”','请点击“查看评估”')
    script=script.replace('建设方案比较完成','建设方案记录已载入').replace('工程准入筛查完成','工程准入记录已载入')
    script=script.replace('调节窗口计算完成','调节窗口记录已载入')
    start=script.index("$('#import-file').addEventListener(");end=script.index('const dataRows=',start)
    script=script[:start]+script[end:]
    (SITE/'app.js').write_text(script)
    for name in ('style.css','static-api.js','index.html','site.css','site.js','assessment.js','home.js','showcase-summary.json','overview-map.svg'):(SITE/name).write_bytes((ROOT/'web'/name).read_bytes())
    (SITE/'delivery.html').write_text((ROOT/'web/delivery.html').read_text().replace('/api/templates.zip','./downloads/data-templates.zip'))
    (SITE/'.nojekyll').write_text('')


def main():
    build_frontend();templates();(SITE/'downloads').mkdir(exist_ok=True)
    catalog={'version':'pages-v1','evidence':'synthetic','execution':'registered_offline_results','scenarios':{},'planning':{}}
    source_hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((ROOT/'trucksim').glob('*.py'))}
    catalog['engine_sources_sha256']=source_hashes
    stresses=('normal','bunched','early','derated','control_loss')
    count=0;ac_count=0;flex_count=0
    for year in range(2026,2031):
        for growth in ('low','medium','high'):
            for plan in PLANS:
                for stress in stresses:
                    key=f'{year}-{growth}-{plan}-{stress}'
                    result=run(make_demo(year,growth,plan,stress),PLANS[plan]['method'])
                    entry={'result':packed(f'data/scenarios/{key}.json.gz',result),
                        'input_hash':result['input_hash'],'export':f'./downloads/scenarios/{key}.zip','flex':{}}
                    folder=SITE/'downloads'/'scenarios';folder.mkdir(exist_ok=True)
                    (folder/(key+'.zip')).write_bytes(export_bundle(result))
                    if result['metrics']['feasible']:
                        for f in result['task']['feeders']:
                            value=flexibility(result,f['id'])
                            entry['flex'][f['id']]=packed(f'data/flex/{key}-{f["id"]}.json.gz',value);flex_count+=1
                    if year==2027 and growth=='medium' and stress=='normal' and plan in ('existing','ordered','expanded'):
                        checked=run(result['task'],result['method'],True);ac_count+=1
                        entry['ac']=packed(f'data/ac/{key}.json.gz',checked)
                        entry['ac_export']=f'./downloads/scenarios/{key}-ac.zip'
                        (folder/(key+'-ac.zip')).write_bytes(export_bundle(checked))
                    catalog['scenarios'][key]=entry;count+=1
        print(f'{year}: {count} scenarios, {flex_count} flexibility records, {ac_count} full AC records',flush=True)
    for growth in ('low','medium','high'):
        for stress in stresses:
            key=f'{growth}-{stress}';value=planning(growth,stress)
            entry={'result':packed(f'data/planning/{key}.json.gz',value),'export':f'./downloads/planning-{key}.zip'}
            catalog['planning'][key]=entry;(SITE/'downloads'/f'planning-{key}.zip').write_bytes(export_analysis('planning',value))
    research=admission();catalog['research']={'result':packed('data/research.json.gz',research),'export':'./downloads/research.zip'}
    (SITE/'downloads/research.zip').write_bytes(export_analysis('research',research))
    out=io.BytesIO()
    with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
        for p in (ROOT/'templates').iterdir():
            if p.is_file():z.writestr(p.name,p.read_bytes())
    (SITE/'downloads/data-templates.zip').write_bytes(out.getvalue())
    (SITE/'downloads/demo-input.json').write_text(json.dumps(make_demo(),ensure_ascii=False,indent=2))
    out=io.BytesIO()
    with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
        for dirname in ('trucksim','web','templates','docs','tests'):
            for p in sorted((ROOT/dirname).rglob('*')):
                if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc' and p.name!='材料清单.json':
                    z.writestr('shanghai-truck-sim/'+p.relative_to(ROOT).as_posix(),p.read_bytes())
        for name in ('pyproject.toml','uv.lock','start.command','README.md'):z.writestr('shanghai-truck-sim/'+name,(ROOT/name).read_bytes())
        z.writestr('shanghai-truck-sim/安装与复算.md',LOCAL_README)
        packages=tomllib.loads((ROOT/'uv.lock').read_text())['package']
        locked='\n'.join(f"{p['name']}=={p['version']}" for p in packages if p.get('source',{}).get('registry'))+'\n'
        z.writestr('shanghai-truck-sim/requirements-locked.txt',locked)
    (SITE/'downloads/local-workbench-source.zip').write_bytes(out.getvalue())
    catalog['counts']={'scenarios':count,'flexibility_records':flex_count,'full_ac_records':ac_count,'annual_comparisons':len(catalog['planning'])}
    (SITE/'data/index.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2))
    (TARGET/'README.md').write_text(PUBLIC_README)
    workflow=TARGET/'.github'/'workflows';workflow.mkdir(parents=True,exist_ok=True)
    (workflow/'pages.yml').write_text(WORKFLOW)
    scripts=TARGET/'scripts';scripts.mkdir(exist_ok=True)
    (scripts/'verify_site.py').write_bytes((ROOT/'tools/verify_pages.py').read_bytes())
    manifest={p.relative_to(SITE).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(SITE.rglob('*')) if p.is_file() and p.name!='manifest.json'}
    (SITE/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
    if (ROOT/'output/quality/public/index.json').exists():
        from stage_quality_pages import stage_quality_pages
        stage_quality_pages(refresh_frontend=False)
    print(json.dumps(catalog['counts'],ensure_ascii=False),flush=True)


LOCAL_README='''# 上海重卡接入规划本地工作台

Python 3.12，使用 uv 或 pip 安装固定版本依赖：

```sh
uv venv --python 3.12
uv pip install --python .venv/bin/python -r requirements-locked.txt
.venv/bin/python -m trucksim.cli serve --port 8785
```

打开 http://127.0.0.1:8785/ 。支持JSON/CSV导入、排程求解、容量与交流校核、报告及复算导出。
真实数据留在本机约定环境中。合成场景不形成上海实际接入结论。
数据字段说明见 templates/数据交付说明.md；模型范围见 docs/模型与验收说明.md。
README保留原型完整说明，其中离线wheelhouse不在网页下载包内。按此说明联网安装固定版本依赖。
从导出包复算时，在同版本源代码目录内执行 python -m trucksim.cli reproduce /已解压导出包；源码不匹配会报出。
'''
PUBLIC_README='''# 上海重卡接入与配套电网规划 · 在线示范

地址：https://jinyh.github.io/shanghai-truck-sim/

在线版为GitHub Pages静态应用，加载同一Python工程模型生成的375个登记合成场景。支持场景切换、逐站评估、馈线/主变共享容量与负荷回放、15组年度比较、合格工况可调记录、工程准入报告和复算包下载。

三个2027年中增长正常工况（现状常规、现状有序、提前扩建）提供完整288时段交流校核记录；其他组合可在本地版校核。客户数据导入、新增工况求解和真实网络适配使用本地版。

仅发布合成输入与结果，无客户数据、材料原件或上传接口。代码和评分器哈希见 site/data/index.json；静态文件哈希见 site/manifest.json。

部署沿用GitHub Actions Pages。发布前运行 python scripts/verify_site.py 。
'''
WORKFLOW='''name: Verify and deploy truck simulation
on:
  push:
    branches: [main]
  workflow_dispatch:
permissions:
  contents: read
concurrency:
  group: truck-simulation-pages
  cancel-in-progress: false
jobs:
  build:
    runs-on: ubuntu-latest
    permissions:
      contents: read
      pages: read
    steps:
      - uses: actions/checkout@v6
      - name: Verify synthetic records and file integrity
        run: python scripts/verify_site.py
      - uses: actions/configure-pages@v5
      - uses: actions/upload-pages-artifact@v4
        with:
          path: site
  deploy:
    needs: build
    runs-on: ubuntu-latest
    permissions:
      pages: write
      id-token: write
    environment:
      name: github-pages
      url: ${{ steps.deployment.outputs.page_url }}
    steps:
      - id: deployment
        uses: actions/deploy-pages@v4
'''


if __name__=='__main__':main()
