"""Extract a reproducible study-area road graph from the frozen public OSM PBF."""
from __future__ import annotations

import hashlib
import json
import re
import sys
from collections import Counter
from pathlib import Path

import osmium

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from trucksim.geography import distance_km

BOUNDS = [121.51, 31.26, 121.64, 31.385]
SPEEDS = {'motorway': 65, 'motorway_link': 30, 'trunk': 50, 'trunk_link': 30,
          'primary': 35, 'primary_link': 25, 'secondary': 30, 'secondary_link': 20,
          'tertiary': 25, 'tertiary_link': 20, 'unclassified': 20, 'residential': 15, 'service': 12}


def inside(xy):
    return BOUNDS[0] <= xy[0] <= BOUNDS[2] and BOUNDS[1] <= xy[1] <= BOUNDS[3]


def numeric(value):
    return float(value) if re.fullmatch(r'\d+(\.\d+)?', value or '') else None


class Extract(osmium.SimpleHandler):
    def __init__(self):
        super().__init__(); self.nodes = {}; self.edges = []; self.roads = []; self.zones = []; self.restrictions = []; self.audit = Counter()

    def way(self, way):
        tags = dict(way.tags); highway = tags.get('highway')
        if highway not in SPEEDS and 'landuse' not in tags:
            return
        try:
            coords = [[n.lon, n.lat] for n in way.nodes]
        except osmium.InvalidLocationError:
            self.audit['invalid_geometry'] += 1; return
        if len(coords) < 2 or not any(inside(x) for x in coords):
            return
        if highway in SPEEDS:
            unknown = ['未核实地方重卡通行政策']
            if 'hgv' not in tags:
                unknown.append('缺少hgv标签')
            if any('conditional' in k for k in tags):
                unknown.append('条件限制需人工核实')
            if tags.get('maxweight') and numeric(tags['maxweight']) is None:
                unknown.append('未解析限重')
            if tags.get('maxheight') and numeric(tags['maxheight']) is None:
                unknown.append('未解析限高')
            speed = min(SPEEDS[highway], numeric(tags.get('maxspeed:hgv')) or numeric(tags.get('maxspeed')) or 999)
            oneway = tags.get('oneway', 'yes' if highway == 'motorway' or tags.get('junction') == 'roundabout' else 'no')
            for a, b, xy1, xy2 in zip(way.nodes, list(way.nodes)[1:], coords, coords[1:]):
                if not inside(xy1) or not inside(xy2):
                    continue
                u, v = str(a.ref), str(b.ref); km = distance_km(xy1, xy2)
                if km < 1e-7:
                    continue
                self.nodes[u] = xy1; self.nodes[v] = xy2
                edge = {'way': str(way.id), 'km': km, 'minutes': km/speed*60, 'speed_kmh': speed,
                        'hgv': tags.get('hgv', 'unknown'), 'access': tags.get('motor_vehicle', tags.get('access', 'unknown')),
                        'maxweight_t': numeric(tags.get('maxweight')), 'maxheight_m': numeric(tags.get('maxheight')), 'unknown': unknown}
                if oneway != '-1':
                    self.edges.append({**edge, 'u': u, 'v': v})
                if oneway not in ('yes', '1', 'true'):
                    self.edges.append({**edge, 'u': v, 'v': u})
            self.roads.append({'type': 'Feature', 'geometry': {'type': 'LineString', 'coordinates': coords},
                               'properties': {'osm_id': str(way.id), 'name': tags.get('name', ''), 'highway': highway}})
            self.audit['road_'+highway] += 1
            self.audit['roads_with_hgv'] += 'hgv' in tags
        if tags.get('landuse') and len(coords) > 3 and coords[0] == coords[-1]:
            raw = tags['landuse']
            category = {'commercial': 'commercial', 'retail': 'commercial', 'residential': 'residential',
                        'industrial': 'industrial', 'port': 'port_logistics'}.get(raw, 'unknown')
            if tags.get('industrial') in ('port', 'logistics', 'warehouse') or tags.get('harbour') == 'yes':
                category = 'port_logistics'
            self.zones.append({'type': 'Feature', 'geometry': {'type': 'Polygon', 'coordinates': [coords]},
                               'properties': {'osm_id': str(way.id), 'name': tags.get('name', ''),
                                              'category': category, 'raw_landuse': raw, 'source': 'OSM closed way'}})
            self.audit['landuse_'+category] += 1

    def relation(self, rel):
        tags = dict(rel.tags)
        if tags.get('type') == 'multipolygon' and tags.get('landuse'):
            self.audit['landuse_relations_in_shanghai'] += 1
        if tags.get('type') != 'restriction' or 'hgv' in tags.get('except', '').split(';'):
            return
        members = {m.role: m for m in rel.members}
        if set(('from', 'to', 'via')).issubset(members) and members['via'].type == 'n':
            self.restrictions.append({'via': str(members['via'].ref), 'from_way': str(members['from'].ref),
                                      'to_way': str(members['to'].ref), 'kind': tags.get('restriction:hgv', tags.get('restriction', 'unknown'))})
        else:
            self.audit['unsupported_restriction_relations_in_shanghai'] += 1

    def area(self, area):
        if area.from_way() or not area.tags.get('landuse'):
            return
        geometry = json.loads(osmium.geom.GeoJSONFactory().create_multipolygon(area))
        if not any(inside(xy) for polygon in geometry['coordinates'] for ring in polygon for xy in ring):
            return
        raw = area.tags['landuse']
        category = {'commercial':'commercial','retail':'commercial','residential':'residential',
                    'industrial':'industrial','port':'port_logistics'}.get(raw,'unknown')
        self.zones.append({'type':'Feature','geometry':geometry,'properties':{'osm_id':'relation/'+str(area.orig_id()),
                           'name':area.tags.get('name',''),'category':category,'raw_landuse':raw,'source':'OSM multipolygon relation'}})
        self.audit['landuse_'+category] += 1
        self.audit['assembled_landuse_relations_in_study_area'] += 1


def main():
    source = ROOT/'data/public/source/shanghai-261013.osm.pbf'
    handler = Extract(); handler.apply_file(str(source), locations=True, idx='flex_mem')
    restrictions = [r for r in handler.restrictions if r['via'] in handler.nodes]
    # Remove only degree-two shape vertices, preserving junctions, way boundaries,
    # direction/access attributes and measured segment distance/travel time.
    neighbors = {}; ways = {}; directed = {}
    for e in handler.edges:
        for a,b in [(e['u'],e['v']),(e['v'],e['u'])]:
            neighbors.setdefault(a,set()).add(b); ways.setdefault(a,set()).add(e['way'])
        directed.setdefault(e['u'],[]).append(e)
    keep = {n for n in handler.nodes if len(neighbors.get(n,[])) != 2 or len(ways.get(n,[])) != 1}
    keep.update(r['via'] for r in restrictions)
    simplified = []
    for origin in sorted(keep):
        for first in directed.get(origin,[]):
            edge = dict(first); seen = {origin}; previous = origin; current = first['v']
            while current not in keep and current not in seen:
                seen.add(current)
                options = [e for e in directed.get(current,[]) if e['v'] != previous and e['way'] == first['way']]
                if len(options) != 1:
                    break
                nxt = options[0]; edge['km'] += nxt['km']; edge['minutes'] += nxt['minutes']
                previous,current = current,nxt['v']
            edge['v'] = current
            if edge['u'] != edge['v']:
                simplified.append(edge)
    retained = {e[k] for e in simplified for k in ('u','v')}
    handler.audit['original_shape_nodes'] = len(handler.nodes)
    handler.nodes = {n:handler.nodes[n] for n in sorted(retained)}; handler.edges = simplified
    # Undirected connectivity is an inventory check, not proof of HGV reachability.
    adjacency = {n: [] for n in handler.nodes}
    for e in handler.edges:
        adjacency[e['u']].append(e['v']); adjacency[e['v']].append(e['u'])
    remaining = set(adjacency); sizes = []
    while remaining:
        stack = [remaining.pop()]; count = 0
        while stack:
            n = stack.pop(); count += 1
            for nxt in adjacency[n]:
                if nxt in remaining:
                    remaining.remove(nxt); stack.append(nxt)
        sizes.append(count)
    source_info = {'url': 'https://download.geofabrik.de/asia/china/shanghai-261013.osm.pbf',
                   'snapshot': '2026-10-13', 'sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
                   'license': 'ODbL 1.0', 'attribution': '© OpenStreetMap contributors',
                   'license_url': 'https://www.openstreetmap.org/copyright', 'public': True}
    value = {'coordinate_system': 'EPSG:4326', 'bounds': BOUNDS, 'source': source_info,
             'nodes': handler.nodes, 'edges': handler.edges, 'turn_restrictions': restrictions,
             'roads': {'type': 'FeatureCollection', 'features': handler.roads},
             'landuse': {'type': 'FeatureCollection', 'features': handler.zones},
             'coverage': {**handler.audit, 'nodes': len(handler.nodes), 'directed_edges': len(handler.edges),
                          'turn_restrictions': len(restrictions), 'components': len(sizes), 'largest_component_nodes': max(sizes)},
             'assumptions': ['道路速度是按道路等级登记的情景值，不是实时交通速度',
                             '土地利用包含闭合way和已组装multipolygon；没有标签的区域保持未知',
                             '仅支持节点式转向限制；条件及复杂转向限制未核实，路线不作通行许可依据',
                             '功能区标签不代表实际供电范围、实际负荷或实际充电站位置']}
    target = ROOT/'data/public/shanghai-study-area.json'
    target.write_text(json.dumps(value, ensure_ascii=False, separators=(',', ':')))
    (ROOT/'data/public/source-manifest.json').write_text(json.dumps({'source': source_info, 'coverage': value['coverage'], 'assumptions': value['assumptions']}, ensure_ascii=False, indent=2))
    print(json.dumps(value['coverage'], ensure_ascii=False))


if __name__ == '__main__':
    main()
