"""Build allowlisted public research records; never search customer directories."""
from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from trucksim.study import compare_study,presentation,STRESSES
from trucksim.quality_io import export_study


def main():
    p=argparse.ArgumentParser();p.add_argument('--season',choices=['summer','winter']);p.add_argument('--stress',choices=list(STRESSES))
    p.add_argument('--days',type=int,default=7);args=p.parse_args()
    folder=ROOT/'output/quality/public';folder.mkdir(parents=True,exist_ok=True)
    index_path=folder/'index.json'
    index=json.loads(index_path.read_text()) if index_path.exists() else {'version':'quality-v1','records':{},'evidence':'公开地理数据 + 合成工程情景'}
    for season in ([args.season] if args.season else ['summer','winter']):
        for stress in ([args.stress] if args.stress else list(STRESSES)):
            key=f'{season}-{stress}';print(f'Computing {key}',flush=True)
            result=compare_study(season,stress,args.days)
            for r in result['cases'].values():
                assert r['task']['metadata'].get('public') is True and r['task']['metadata']['evidence']=='synthetic'
                assert r['task']['spatial']['source'].get('public') is True and r['task']['electrical'].get('public') is True
                assert 'original_import' not in r['task']['metadata']
                assert r['power_quality']['status']=='completed',r['power_quality']['failures'][:1]
            data=gzip.compress(json.dumps(presentation(result),ensure_ascii=False,separators=(',',':'),allow_nan=False).encode(),mtime=0)
            (folder/f'{key}.json.gz').write_bytes(data)
            archive=export_study(result);(folder/f'{key}.zip').write_bytes(archive)
            index['records'][key]={'result':f'{key}.json.gz','export':f'{key}.zip','days':args.days,
                'sha256':hashlib.sha256(data).hexdigest(),'export_sha256':hashlib.sha256(archive).hexdigest(),
                'input_hashes':{plan:r['input_hash'] for plan,r in result['cases'].items()},
                'source_sha256':result['source_sha256']}
            index_path.write_text(json.dumps(index,ensure_ascii=False,indent=2))
            print(f'Built {key}: {len(data)} display bytes, {len(archive)} evidence bytes',flush=True)


if __name__=='__main__':main()
