"""Project the frozen public study into small homepage assets; no new simulation."""
import gzip
import hashlib
import html
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]


def build_showcase():
    source=ROOT/'output/quality/public'
    index=json.loads((source/'index.json').read_text())
    entry=index['records']['summer-normal'];raw=(source/entry['result']).read_bytes()
    assert hashlib.sha256(raw).hexdigest()==entry['sha256']
    d=json.loads(gzip.decompress(raw));assert d['evidence']=='public_geography_synthetic_engineering'
    cases={}
    for plan,c in d['cases'].items():
        q=c['power_quality'];assert q['status']=='completed' and not q['failures']
        worst=max((a for a in c['metrics']['assets'] if a['type']!='station'),key=lambda a:a['max_loading_pct'])
        cases[plan]={'input_hash':c['input_hash'],'voltage_min_pu':min(n['voltage_min_pu'] for n in q['nodes']),
                     'thdu_pct':max(n['max_thdu_pct'] for n in q['nodes']),
                     'charging_peak_kw':c['metrics']['charging_peak_kw'],'energy_cost_cny':c['metrics']['operator_energy_cost_cny'],
                     'user_nodes':sum(n['kind'] in ('industrial','residential','commercial','mixed') for n in q['nodes']),
                     'worst_asset':{'id':worst['id'],'name':worst['name'],'loading_pct':worst['max_loading_pct']}}
    summary={'version':1,'evidence':d['evidence'],'quality':{'case_id':'summer-normal','record_sha256':entry['sha256'],
             'start':d['cases']['ordered']['timestamps'][0],'end':d['cases']['ordered']['timestamps'][-1],
             'export':'quality-data/'+entry['export'],'cases':cases}}
    (ROOT/'web/showcase-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
    geo=d['spatial'];bounds=geo['bounds'];colors={'industrial':'#e4cfb4','residential':'#d3dfb8','commercial':'#dbcfdf','port_logistics':'#b6d4d3','mixed':'#d6d5bb','unknown':'#e1e6da'}
    def project(p):return (20+(p[0]-bounds[0])/(bounds[2]-bounds[0])*960,580-(p[1]-bounds[1])/(bounds[3]-bounds[1])*560)
    def path(points):return ' '.join(('M' if i==0 else 'L')+'%.1f %.1f'%project(p) for i,p in enumerate(points))
    parts=['<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 600" role="img"><title>上海研究区域公开道路与四个合成示范站位</title><rect width="1000" height="600" fill="#edf1e8"/>']
    for f in geo['landuse']['features']:
        polygons=[f['geometry']['coordinates']] if f['geometry']['type']=='Polygon' else f['geometry']['coordinates']
        shape=' '.join(' '.join(path(r)+'Z' for r in poly) for poly in polygons)
        parts.append(f'<path d="{shape}" fill="{colors.get(f["properties"]["category"],"#e1e6da")}" fill-rule="evenodd" stroke="white" stroke-width=".6"/>')
    for f in geo['roads']['features']:
        if f['properties']['highway'] not in ('motorway','trunk','primary','secondary','tertiary','residential'):continue
        major=f['properties']['highway'] in ('motorway','trunk','primary')
        parts.append(f'<path d="{path(f["geometry"]["coordinates"])}" fill="none" stroke="{"#b2bdae" if major else "#fff"}" stroke-width="{2.2 if major else 1.2}"/>')
    for s in d['cases']['ordered']['stations']:
        x,y=project([s['longitude'],s['latitude']]);label=html.escape(s['id']+' · '+s['name'].replace('示范站位',''))
        left=x-200 if x>720 else x+22
        parts.append(f'<circle cx="{x:.1f}" cy="{y:.1f}" r="13" fill="#176b53" stroke="white" stroke-width="4"/><rect x="{left:.1f}" y="{y-21:.1f}" width="185" height="42" rx="6" fill="white"/><text x="{left+12:.1f}" y="{y+6:.1f}" fill="#173d35" font-size="18" font-family="sans-serif">{label}</text>')
    parts.append('<text x="20" y="590" font-size="12" fill="#637c72">© OpenStreetMap contributors · ODbL · 2026-10-13 · 站位为合成示范</text></svg>')
    (ROOT/'web/overview-map.svg').write_text(''.join(parts))
    return summary


if __name__=='__main__':
    s=build_showcase();print(json.dumps({'case':s['quality']['case_id'],'plans':len(s['quality']['cases'])}))
