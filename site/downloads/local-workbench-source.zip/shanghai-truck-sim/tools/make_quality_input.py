"""Write a full editable 1.1 public-geography / synthetic-engineering example."""
import argparse
import json
import sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from trucksim.study import make_study,STUDY_PLANS,STRESSES

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--season',choices=['summer','winter'],default='summer')
    p.add_argument('--plan',choices=list(STUDY_PLANS),default='ordered')
    p.add_argument('--stress',choices=list(STRESSES),default='normal')
    p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    a.output.parent.mkdir(parents=True,exist_ok=True)
    a.output.write_text(json.dumps(make_study(a.season,a.plan,a.stress),ensure_ascii=False,indent=2,allow_nan=False))
    print(a.output)
