"""Explicit compute/display/package boundaries and verified allowlisted resources."""
from __future__ import annotations
import hashlib
import importlib
import io
import json
import shutil
from pathlib import Path
from .paths import ROOT, frozen
from .archive import EvidenceZip

def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(path):return json.loads(Path(path).read_text())
def write(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def safe(base,name):
    raw=Path(base)/name
    if raw.is_symlink():raise ValueError('资源不接受符号链接')
    p=raw.resolve()
    if not p.is_relative_to(Path(base).resolve()) or p.is_symlink():raise ValueError('资源路径越界')
    return p

def verify_frozen(family):
    folder=frozen(family);m=read(folder/'frozen-manifest.json')
    for name,sha in m['files'].items():
        p=safe(folder,name)
        if not p.is_file() or digest(p)!=sha:raise ValueError(f'冻结资源缺失或校验失败：{family}/{name}')
    return folder,m

def display(out):
    out=Path(out).resolve();out.mkdir(parents=True,exist_ok=True)
    if any(out.iterdir()):raise ValueError('展示输出目录必须为空；使用新目录保留历史版本')
    web=out/'web';web.mkdir()
    for name in read(ROOT/'maintenance/public-resources.json')['web']:
        source=safe(ROOT/'web',name);target=safe(web,name);target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,target)
    for family in ('quality','planning'):
        folder,m=verify_frozen(family)
        for name in m['files']:
            target=safe(web,name);target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(folder/name,target)
    for name in ('build_showcase','build_candidates','build_scene','build_presentation'):
        module=importlib.import_module('tools.'+name);getattr(module,name)(out)
    # Future records are optional until the complete annual model is accepted.
    pointer=ROOT/'data/published/four/index.json'
    if pointer.exists():
        entry=read(pointer);base=safe(ROOT,entry['path']);m=read(base/'frozen-manifest.json')
        for name,sha in m['files'].items():
            if digest(base/name)!=sha:raise ValueError('四站规划资源摘要不符：'+name)
            target=safe(web,name);target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(base/name,target)
    write(out/'display-manifest.json',{p.relative_to(web).as_posix():digest(p) for p in sorted(web.rglob('*')) if p.is_file()})
    return out

def source_paths():
    spec=read(ROOT/'maintenance/public-source.json');paths={ROOT/n for n in spec['files']}
    for dirname in spec['directories']:
        for p in (ROOT/dirname).rglob('*'):
            if p.is_file() and not p.is_symlink() and '__pycache__' not in p.parts and p.suffix not in ('.pyc','.dbl','.blend1','.log') and p.name!='.DS_Store':paths.add(p)
    paths.update(ROOT/'web'/n for n in read(ROOT/'maintenance/public-resources.json')['web'])
    return sorted(paths)

def package(display_dir,out):
    display_dir=Path(display_dir).resolve();web=display_dir/'web';m=read(display_dir/'display-manifest.json')
    for name,sha in m.items():
        if digest(safe(web,name))!=sha:raise ValueError('展示资源校验失败：'+name)
    out=Path(out).resolve()
    if out.exists() and any(out.iterdir()):raise ValueError('打包输出目录必须为空')
    out.mkdir(parents=True,exist_ok=True)
    for name in m:
        target=safe(out,name);target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(web/name,target)
    write(out/'runtime-config.json',{'mode':'static','schema':'runtime-1'})
    (out/'.nojekyll').write_text('')
    downloads=out/'downloads';downloads.mkdir(exist_ok=True)
    with EvidenceZip(downloads/'data-templates.zip','w') as z:
        for p in sorted((ROOT/'templates').iterdir()):
            if p.is_file():z.writestr(p.name,p.read_bytes())
        z.writestr('电能质量评估与数据接口.md',(ROOT/'docs/电能质量评估与数据接口.md').read_bytes())
    with EvidenceZip(downloads/'local-workbench-source.zip','w') as z:
        for p in source_paths():z.writestr('shanghai-truck-sim/'+p.relative_to(ROOT).as_posix(),p.read_bytes())
        # Offline evidence is delivered independently from editable source.
        z.writestr('shanghai-truck-sim/安装与复算.md','使用Python 3.12与uv.lock安装依赖；python -m trucksim.cli serve。公开冻结结果使用另附的evidence-quality.zip及evidence-planning-*.zip（分片各自独立解压），解压至项目根目录。真实资料只在约定本地环境处理。\n')
    # A complete standalone public evidence baseline; split by family to bound file sizes.
    for family in ('quality','planning'):
        folder,fm=verify_frozen(family)
        parts=[[]];size=0
        for p in sorted(folder.rglob('*')):
            if not p.is_file():continue
            if size+p.stat().st_size>60_000_000 and parts[-1]:parts.append([]);size=0
            parts[-1].append(p);size+=p.stat().st_size
        for i,part in enumerate(parts):
            name=f'evidence-{family}'+(f'-{i+1}' if len(parts)>1 else '')+'.zip'
            with EvidenceZip(downloads/name,'w') as z:
                z.writestr('data/published/index.json',(ROOT/'data/published/index.json').read_bytes())
                for p in part:z.writestr(p.relative_to(ROOT).as_posix(),p.read_bytes())
    # Keep existing advertised demo-input download.
    shutil.copyfile(ROOT/'templates/demo-input.json',downloads/'demo-input.json')
    write(out/'manifest.json',{p.relative_to(out).as_posix():digest(p) for p in sorted(out.rglob('*')) if p.is_file() and p.name!='manifest.json'})
    return out

def compute(case,out,**kwargs):
    out=Path(out).resolve();out.mkdir(parents=True,exist_ok=True)
    if case=='four':
        from .annual_build import build
        return build(out,**kwargs)
    if case=='planning':
        from tools import compute_legacy
        compute_legacy.TARGET=out;compute_legacy.SITE=out/'site';compute_legacy.SITE.mkdir(exist_ok=True)
        return compute_legacy.main()
    if case=='quality':
        from tools import build_quality
        return build_quality.build(out)
    raise ValueError('未知计算案例族')
