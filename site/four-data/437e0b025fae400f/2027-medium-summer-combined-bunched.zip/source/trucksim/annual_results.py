"""Build immutable annual display/evidence from computed archives, without solvers."""
import gzip
import hashlib
import json
import shutil
from pathlib import Path
from .annual_build import matrix,key,load_archive,code_hash,dump
from .study_planning import ASSUMPTIONS,ASSUMPTION_HASH,summaries,ENGINEERING
from .study import presentation,STUDY_PLANS
from .annual_evidence import assessments

def first_constraints(rows):
    result=[]
    for growth in ('low','medium','high'):
        for engineering in ENGINEERING:
            for plan in STUDY_PLANS:
                if plan=='baseline':continue
                chosen=[r for r in rows if r['growth']==growth and r['engineering']==engineering and r['plan']==plan and r['stress']=='normal']
                for metric in ('capacity','transport','voltage','harmonics'):
                    bad=sorted([r for r in chosen if r['states'][metric] is False],key=lambda r:(r['year'],r['season']))
                    gaps=[r for r in chosen if r['states'][metric] is None]
                    first=bad[0] if bad else None
                    # An earlier missing year cannot prove the first failure year.
                    complete=len(chosen)==8 and not any(r['year']<=(first['year'] if first else 2030) for r in gaps)
                    result.append(dict(growth=growth,engineering=engineering,plan=plan,metric=metric,status='首次受限' if first and complete else '未完整评估' if not complete else '评价期内未触发',year=first['year'] if first and complete else None,record=first['record'] if first else None,object=first['worst_asset'] if first and metric=='capacity' else None))
    return result

def schedules(rows):
    result=[]
    from .study_planning import project_list
    for growth in ('low','medium','high'):
        for plan in ('unmanaged','ordered','capacitor','filter'):
            for engineering in ('station','shared','combined'):
                projects=project_list(engineering);lead=max(p['lead_months'] for p in projects)
                for year in range(2027,2031):
                    chosen=[r for r in rows if r['growth']==growth and r['plan']==plan and r['stress']=='normal' and r['engineering']==(engineering if r['year']>=year else 'existing')]
                    required=[r for r in rows if r['growth']==growth and r['plan']==plan and r['stress'] in ('bunched','control_loss') and r['engineering']==(engineering if r['year']>=year else 'existing')]
                    normal_ok=len(chosen)==8 and all(all(v is True for v in r['states'].values()) for r in chosen)
                    stress_ok=len(required)==16 and all(all(v is True for v in r['states'].values()) for r in required)
                    # Unmanaged still needs concentrated-arrival coverage, but no central-control failure gate.
                    if plan=='unmanaged':stress_ok=len([r for r in required if r['stress']=='bunched'])==8 and all(all(v is True for v in r['states'].values()) for r in required if r['stress']=='bunched')
                    startmonth=year*12-lead;start=f'{startmonth//12:04d}-{startmonth%12+1:02d}-01'
                    cost={o:sum(p['quantity']*p['unit_cost_cny'] for p in projects if p['owner']==o) for o in ('utility','station','other_user')}
                    result.append(dict(growth=growth,plan=plan,engineering=engineering,commission_year=year,normal_satisfied=normal_ok,required_stress_satisfied=stress_ok,status='登记计算条件满足；工程与现场条件待落实' if normal_ok and stress_ok else '必要压力工况未完整评估' if normal_ok and growth!='medium' else '现有候选时序不满足登记条件',latest_start=start,start_condition='时序条件待落实' if start<ASSUMPTIONS['as_of'] else '建设条件待落实',investment=[dict(year=y,new=cost if y==year else dict.fromkeys(cost,0),cumulative=cost if y>=year else dict.fromkeys(cost,0)) for y in range(2027,2031)]))
    return result

def generate(compute,out):
    compute=Path(compute);out=Path(out);out.mkdir(parents=True,exist_ok=True)
    if any(out.iterdir()):raise ValueError('年度展示目录必须为空')
    cache=compute/'cache';jobs=matrix();signature=code_hash()+ASSUMPTION_HASH
    for args in jobs:
        name=key(args);meta=json.loads((cache/(name+'.meta.json')).read_text());path=cache/(name+'.zip')
        if meta['signature']!=signature or meta['sha256']!=hashlib.sha256(path.read_bytes()).hexdigest():raise ValueError('计算记录失效：'+name)
    version=hashlib.sha256((signature+''.join(json.loads((cache/(key(a)+'.meta.json')).read_text())['sha256'] for a in jobs)).encode()).hexdigest()[:16]
    folder=out/'four-data'/version;folder.mkdir(parents=True)
    records={};rows=[]
    for args in jobs:
        name=key(args);value=load_archive(cache/(name+'.zip'));record_rows=summaries(value)
        for r in record_rows:r['record']=name
        rows.extend(record_rows)
        entry={'conditions':args,'id':value['id'],'result':f'{name}.json.gz','export':f'{name}.zip','input_hashes':{p:r['input_hash'] for p,r in value['cases'].items()}}
        source=f'four-data/{version}/{name}.zip'
        ca={**args,'stress':'control_loss'};controlpath=cache/(key(ca)+'.zip')
        control=load_archive(controlpath) if controlpath.exists() else None
        if control:control['_source']=f'four-data/{version}/{key(ca)}.zip'
        projected=presentation(value);projected.pop('spatial',None)
        projected.update(evaluation_version=version,rows=record_rows,records=assessments(value,control,source))
        for plan,r in value['cases'].items():
            projected['cases'][plan]['equipment']=r['power_quality']['equipment']
            projected['cases'][plan]['ports']=r['solution'].get('ports',{})
        payload=gzip.compress(json.dumps(projected,ensure_ascii=False,separators=(',',':'),allow_nan=False).encode(),mtime=0)
        (folder/entry['result']).write_bytes(payload);shutil.copyfile(cache/(name+'.zip'),folder/entry['export'])
        entry['sha256']=hashlib.sha256(payload).hexdigest();entry['export_sha256']=hashlib.sha256((folder/entry['export']).read_bytes()).hexdigest();records[name]=entry
        print('Projected',name,flush=True)
    catalog=dict(schema='four-planning-1',version=version,base_year=2026,years=[2027,2028,2029,2030],records=records,rows=rows,first_constraints=first_constraints(rows),schedules=schedules(rows),assumptions=ASSUMPTIONS,assumption_hash=ASSUMPTION_HASH,compute_sha256=code_hash(),plan_labels=STUDY_PLANS,engineering_labels=ENGINEERING,annualized=False)
    dump(folder/'index.json',catalog);dump(out/'four-data/index.json',{'version':version,'file':f'{version}/index.json','sha256':hashlib.sha256((folder/'index.json').read_bytes()).hexdigest()})
    dump(out/'frozen-manifest.json',{'family':'four','version':version,'files':{p.relative_to(out).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(out.rglob('*')) if p.is_file()}})
    return catalog

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--compute',required=True);p.add_argument('--out',required=True);a=p.parse_args();generate(a.compute,a.out)
