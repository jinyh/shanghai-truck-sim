"""Explicit, resumable computation of the registered four-station matrix."""
from __future__ import annotations
import concurrent.futures
import gzip
import hashlib
import json
import os
import time
import zipfile
from pathlib import Path
from .paths import ROOT
from .study_planning import ASSUMPTIONS, ASSUMPTION_HASH, compare_annual, summaries, schedule
from .study import presentation
from .quality_io import export_study, restore_inputs

COMPUTE_FILES=['analysis.py','dispatch.py','model.py','audit.py','transport.py','network.py','quality.py','study.py','study_planning.py','geography.py']
def code_hash():
    return hashlib.sha256(b''.join((ROOT/'trucksim'/n).read_bytes() for n in COMPUTE_FILES)).hexdigest()
def dump(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def load_archive(path):
    with zipfile.ZipFile(path) as z:
        value=json.loads(z.read('study.json'));geo=json.loads(z.read('spatial.json'))
        for plan in value['cases']:
            task=json.loads(z.read(f'cases/{plan}/task.json'));task['spatial']=geo
            value['cases'][plan]={**json.loads(z.read(f'cases/{plan}/result.json')),'task':task}
    return value

def matrix():
    rows=[]
    for growth in ('medium','low','high'):
        for year in range(2027,2031):
            for season in ('summer','winter'):
                for engineering in ('existing','station','shared','combined'):
                    for stress in (('normal','control_loss','bunched') if growth=='medium' else ('normal',)):
                        rows.append(dict(year=year,growth=growth,season=season,engineering=engineering,stress=stress))
    for season in ('summer','winter'):
        rows.append(dict(year=2026,growth='medium',season=season,engineering='existing',stress='control_loss'))
        for stress in ('weak','light'):rows.append(dict(year=2030,growth='medium',season=season,engineering='existing',stress=stress))
    for engineering in ('existing','combined'):
        for repair in (False,True):rows.append(dict(year=2030,growth='medium',season='winter',engineering=engineering,stress='background',background_repair=repair))
    return rows

def key(args):return '-'.join(str(args[k]) for k in ('year','growth','season','engineering','stress'))+('-repair' if args.get('background_repair') else '')
def worker(job):
    folder,args,signature=job;folder=Path(folder);name=key(args);archive=folder/(name+'.zip');meta=folder/(name+'.meta.json')
    if archive.exists() and meta.exists():
        m=json.loads(meta.read_text())
        if m['signature']==signature and m['sha256']==hashlib.sha256(archive.read_bytes()).hexdigest():return name,'cached'
    started=time.monotonic();value=compare_annual(**args)
    archive.write_bytes(export_study(value,zipfile.ZIP_LZMA))
    dump(meta,{'signature':signature,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'args':args,'seconds':time.monotonic()-started})
    return name,round(time.monotonic()-started,1)

def build(out,workers=2,scenarios=None):
    out=Path(out).resolve();out.mkdir(parents=True,exist_ok=True);cache=out/'cache';cache.mkdir(exist_ok=True)
    signature=code_hash()+ASSUMPTION_HASH;cases=scenarios or matrix()
    dump(out/'registered-assumptions.json',{'assumptions':ASSUMPTIONS,'sha256':ASSUMPTION_HASH,'compute_sha256':code_hash(),'matrix':cases})
    with concurrent.futures.ProcessPoolExecutor(max_workers=workers) as pool:
        for name,duration in pool.map(worker,[(str(cache),args,signature) for args in cases]):print(name,duration,flush=True)
    return out

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--out',required=True);p.add_argument('--workers',type=int,default=2);a=p.parse_args();build(a.out,a.workers)
