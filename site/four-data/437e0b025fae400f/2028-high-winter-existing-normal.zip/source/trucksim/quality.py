"""One explicit 50 Hz network for fundamental, harmonic and impedance studies.

All limits are reference criteria, not an engineering connection approval.
No measured waveform, flicker, dip or current-allocation result is inferred.
"""
from __future__ import annotations

import cmath
import copy
import math
import re

import numpy as np

from .model import InputError

HARMONICS = list(range(2, 26))


def identifier(value):
    if not isinstance(value, str) or not re.fullmatch(r'[A-Za-z][A-Za-z0-9_]*', value):
        raise InputError('电气标识只能包含英文字母、数字和下划线，且以字母开头')
    return value


def validate_electrical(task):
    net = task.get('electrical')
    if not net:
        return
    if net.get('frequency_hz') != 50:
        raise InputError('首版电气模型只支持50 Hz')
    buses = {identifier(b['id']): b for b in net['buses']}
    if len(buses) != len(net['buses']):
        raise InputError('电气节点标识重复')
    for b in buses.values():
        if not math.isfinite(b['kv']) or b['kv'] <= 0:
            raise InputError('节点额定电压必须为正数')
    if net['source']['bus'] not in buses or any(not math.isfinite(net['source'][k]) or net['source'][k]<=0 for k in ('pu','mvasc3','mvasc1','xr')):
        raise InputError('电源节点或等值参数无效')
    for section in ('lines', 'transformers'):
        seen = set()
        for e in net[section]:
            identifier(e['id'])
            if e['id'] in seen or e['from_bus'] not in buses or e['to_bus'] not in buses:
                raise InputError('电气设备重复或引用未知节点')
            seen.add(e['id'])
            fields = ('length_km', 'ampacity_a', 'r1', 'x1', 'r0', 'x0') if section == 'lines' else ('kva', 'xhl_pct', 'r_pct')
            for key in fields:
                if not math.isfinite(e[key]) or e[key] <= 0:
                    raise InputError(f'{e["id"]}.{key} 必须提供独立的正值设备参数')
    n = task['periods']; zone_ids = set()
    for z in net['loads']:
        identifier(z['id'])
        if z['id'] in zone_ids or z['bus'] not in buses:
            raise InputError('分区负荷重复或引用未知节点')
        zone_ids.add(z['id'])
        if z['feeder_id'] not in {f['id'] for f in task['feeders']}:
            raise InputError('分区负荷引用未知馈线')
        for field in ('p_kw', 'q_kvar'):
            if len(z[field]) != n or any(not math.isfinite(x) for x in z[field]):
                raise InputError('分区负荷缺测、非数值或长度不符')
        if any(p < 0 for p in z['p_kw']):
            raise InputError('首版分区有功必须非负；无功允许正负')
        if len(z['phase_fractions']) != 3 or abs(sum(z['phase_fractions'])-1) > 1e-8 or min(z['phase_fractions']) < 0:
            raise InputError('分相负荷比例必须非负且合计为1')
    mappings = net['station_buses']
    if set(mappings) != {s['id'] for s in task['stations']} or any(b not in buses for b in mappings.values()):
        raise InputError('场站电气映射不完整')
    for s in task['stations']:
        if net['station_ports'].get(s['id']) != s['ports'] or net['charger_rated_kw'] != s['charger_kw']:
            raise InputError('排程端口及额定功率必须与电气设备模型一致')
    mitigation=net['mitigation']
    if not 0<=mitigation['filter_fraction']<=1 or mitigation['filter_rated_a']<0 or mitigation['capacitor_kvar_per_station']<0 or any(h not in HARMONICS for h in mitigation['filter_orders']):
        raise InputError('治理措施容量、补偿比例或阶次无效')
    for f in task['feeders']:
        zones = [z for z in net['loads'] if z['feeder_id'] == f['id']]
        for t in range(n):
            if abs(sum(z['p_kw'][t] for z in zones)-f['net_background_kw'][t]) > 1e-5:
                raise InputError('分区负荷与馈线背景不一致或重复计量')
    if any(max(t['net_background_kw']) > 1e-8 or max(t['committed_kw']) > 1e-8 for t in task['transformers']) or any(max(f['committed_kw']) > 1e-8 for f in task['feeders']):
        raise InputError('1.1电气模型的全部背景/承诺负荷须显式映射到节点，不能另加上级聚合负荷')
    table = net['charger_characteristics']['operating_points']
    ratios = [row['fraction'] for row in table]
    if sorted(set(ratios)) != ratios or ratios[0] <= 0 or ratios[-1] != 1:
        raise InputError('充电设备运行点须按功率比例严格递增并覆盖额定功率')
    for row in table:
        if not 0 < row['displacement_pf'] <= 1:
            raise InputError('基波功率因数无效')
        for h, pair in row['harmonics'].items():
            if int(h) not in HARMONICS or len(pair) != 2 or not all(math.isfinite(x) for x in pair) or pair[0] < 0:
                raise InputError('谐波谱须为2—25次、非负幅值百分比及相角')


def operating_point(table, fraction):
    """Interpolate complex currents, not wrapped phase angles."""
    points = table['operating_points']
    lo = hi = points[0]
    for row in points:
        hi = row
        if row['fraction'] >= fraction:
            break
        lo = row
    if fraction >= points[-1]['fraction']:
        lo = hi = points[-1]
    weight = 0 if hi['fraction'] == lo['fraction'] else (fraction-lo['fraction'])/(hi['fraction']-lo['fraction'])
    spectrum = {}
    for h in HARMONICS:
        def phasor(row):
            magnitude, angle = row['harmonics'].get(str(h), [0, 0])
            return cmath.rect(magnitude, math.radians(angle))
        v = phasor(lo)*(1-weight)+phasor(hi)*weight
        spectrum[str(h)] = [abs(v), math.degrees(cmath.phase(v))]
    return {'pf': lo['displacement_pf']*(1-weight)+hi['displacement_pf']*weight, 'harmonics': spectrum}


class Circuit:
    def __init__(self, net, plan='ordered', damping=50):
        from dss import DSS
        self.dss = DSS.NewContext(); self.net = net; self.plan = plan
        self.buses = {b['id']: b for b in net['buses']}; self.loads = []
        from .paths import runtime
        import os
        work=runtime()/f'dss-{os.getpid()}';work.mkdir(exist_ok=True)
        self.command('clear'); self.command(f'set datapath="{work}"'); self.command('set defaultbasefrequency=50')
        src = net['source']
        self.command(f'new circuit.study bus1={src["bus"]} basekv={self.buses[src["bus"]]["kv"]} pu={src["pu"]} phases=3 mvasc3={src["mvasc3"]} mvasc1={src["mvasc1"]} x1r1={src["xr"]} x0r0={src["xr"]}')
        self.spectrum('background_source', src.get('harmonics', {}))
        self.command('edit vsource.source spectrum=background_source')
        self.spectrum('zero', {})
        for t in net['transformers']:
            self.command(f'new transformer.{t["id"]} phases=3 windings=2 buses=[{t["from_bus"]} {t["to_bus"]}] conns=[{t["connections"][0]} {t["connections"][1]}] kvs=[{self.buses[t["from_bus"]]["kv"]} {self.buses[t["to_bus"]]["kv"]}] kvas=[{t["kva"]} {t["kva"]}] xhl={t["xhl_pct"]} %rs=[{t["r_pct"]/2} {t["r_pct"]/2}] %noloadloss=0 %imag=0 xrconst=yes')
        for ln in net['lines']:
            self.command(f'new line.{ln["id"]} bus1={ln["from_bus"]} bus2={ln["to_bus"]} phases=3 length={ln["length_km"]} units=km r1={ln["r1"]} x1={ln["x1"]} r0={ln["r0"]} x0={ln["x0"]} c1={ln.get("c1_nf",0)} c0={ln.get("c0_nf",0)} normamps={ln["ampacity_a"]}')
        for z in net['loads']:
            self.spectrum('sp_'+z['id'], z.get('harmonics', {}))
            for phase in range(1, 4):
                name = z['id']+'_'+str(phase)
                self.command(f'new load.{name} bus1={z["bus"]}.{phase} phases=1 conn=wye kv={self.buses[z["bus"]]["kv"]/math.sqrt(3)} kw=0 kvar=0 model=1 vminpu=.1 vmaxpu=2 spectrum=sp_{z["id"]} %seriesrl={damping}')
                self.loads.append(name)
        for sid, bus in net['station_buses'].items():
            for port in range(net['station_ports'][sid]):
                name = f'charger_{sid}_{port}'; self.spectrum('sp_'+name, {})
                self.command(f'new load.{name} bus1={bus} phases=3 conn=wye kv={self.buses[bus]["kv"]} kw=0 kvar=0 model=1 vminpu=.1 vmaxpu=2 spectrum=sp_{name} %seriesrl={damping}')
                self.loads.append(name)
        if plan == 'capacitor' and net['mitigation']['capacitor_kvar_per_station']>0:
            for sid, bus in net['station_buses'].items():
                self.command(f'new capacitor.cap_{sid} bus1={bus} phases=3 kv={self.buses[bus]["kv"]} kvar={net["mitigation"]["capacitor_kvar_per_station"]}')
        self.command('set voltagebases=['+' '.join(str(v) for v in sorted({b['kv'] for b in self.buses.values()}))+']')
        self.command('calcvoltagebases'); self.command('set maxiterations=60 tolerance=0.000001 controlmode=off')

    def command(self, value):
        self.dss.Text.Command = value

    def spectrum(self, name, values):
        pairs = [values.get(str(h), [0, 0]) for h in HARMONICS]
        action = 'edit' if name in getattr(self, '_spectra', set()) else 'new'
        self.command(f'{action} spectrum.{name} numharm=25 harmonic=(1 '+ ' '.join(map(str, HARMONICS))+') %mag=(100 '+ ' '.join(str(p[0]) for p in pairs)+') angle=(0 '+ ' '.join(str(p[1]) for p in pairs)+')')
        if not hasattr(self, '_spectra'):
            self._spectra = set()
        self._spectra.add(name)

    def load(self, name, p, q):
        loads = self.dss.ActiveCircuit.Loads; loads.Name = name; loads.kW = p; loads.kvar = q
        # OpenDSS harmonic Norton initialization is undefined for a zero-kVA load.
        self.dss.ActiveCircuit.ActiveCktElement.Enabled = abs(p)+abs(q) > 1e-10

    def set_state(self, step, port_power):
        self.command('set mode=snapshot frequency=50')
        for z in self.net['loads']:
            for phase, share in enumerate(z['phase_fractions'], 1):
                self.load(z['id']+'_'+str(phase), z['p_kw'][step]*share, z['q_kvar'][step]*share)
        state = []; total_q = {}
        for sid, bus in self.net['station_buses'].items():
            rows = []
            for port in range(self.net['station_ports'][sid]):
                p = port_power.get((sid, port), 0)
                char = operating_point(self.net['charger_characteristics'], p/self.net['charger_rated_kw'])
                q = p*math.tan(math.acos(char['pf'])) if p > 0 else 0
                amps = math.hypot(p, q)/(math.sqrt(3)*self.buses[bus]['kv'])
                rows.append((port, p, q, amps, char))
            # Ideal, bounded feed-forward cancellation, not a device dynamic model.
            mitigation = self.net['mitigation']; selected = mitigation['filter_orders']
            requested = sum(amps*math.sqrt(sum((char['harmonics'][str(h)][0]/100)**2 for h in selected))
                            for _, _, _, amps, char in rows)*mitigation['filter_fraction']
            fraction = mitigation['filter_fraction']*min(1, mitigation['filter_rated_a']/max(requested, 1e-12)) if self.plan == 'filter' else 0
            total_q[sid] = sum(r[2] for r in rows)
            for port, p, q, amps, char in rows:
                name = f'charger_{sid}_{port}'
                spectrum = copy.deepcopy(char['harmonics'])
                for h in selected:
                    spectrum[str(h)][0] *= 1-fraction
                self.spectrum('sp_'+name, spectrum if p > 1e-8 else {})
                self.load(name, p, q)
                if p > 1e-8:
                    state.append({'station_id': sid, 'port': port, 'p_kw': p, 'q_kvar': q,
                                  'displacement_pf': char['pf'], 'filter_fraction': fraction})
        self.dss.ActiveCircuit.Solution.Solve()
        if not self.dss.ActiveCircuit.Solution.Converged:
            raise ValueError('基波潮流未收敛')
        return state, total_q

    def voltages(self, bus):
        self.dss.ActiveCircuit.SetActiveBus(bus)
        v = np.asarray(self.dss.ActiveCircuit.ActiveBus.Voltages).reshape(-1, 2)
        return v[:, 0]+1j*v[:, 1]

    def currents(self, element):
        self.dss.ActiveCircuit.SetActiveElement(element)
        values = np.asarray(self.dss.ActiveCircuit.ActiveCktElement.Currents).reshape(-1, 2)
        return values[:3, 0]+1j*values[:3, 1]

    def harmonic(self, h):
        # Harmonic mode iterates its harmonic list; setting frequency alone does
        # not select one order and would repeatedly return the last solved order.
        self.command(f'solve mode=harmonics harmonics=[{h}]')
        if not self.dss.ActiveCircuit.Solution.Converged:
            raise ValueError(f'{h}次谐波未收敛')


def reference_status(values, low, high):
    if low is None or high is None:
        return 'not_evaluated'
    return 'within_reference' if min(values) >= low-1e-8 and max(values) <= high+1e-8 else 'exceeds_reference'


def evaluate_quality(task, solution):
    net = task.get('electrical')
    if not net:
        return {'status': 'not_evaluated', 'reason': '未提供独立电气模型'}
    plan = task.get('study', {}).get('plan', 'ordered'); circuit = Circuit(net, plan)
    watched = [b for b in net['buses'] if b.get('observe')]
    traces = {b['id']: [] for b in watched}; currents = {sid: [] for sid in net['pcc_elements']}
    n=task['periods']
    equipment = []; failures = []; operating_states = [None]*n; station_q = {s['id']: [None]*n for s in task['stations']}
    reservations = solution['reservations']; cache = {}
    for step in range(n):
        powers = {(r['station_id'], r['port']): solution['power_by_session'][r['id']][step]
                  for r in reservations if r['connected_step'] <= step < r['departure_step']}
        # Exact input equality only: repeated daily operating points need not be
        # re-solved. Do not round inputs or cache failed/non-finite solutions.
        key = (tuple((z['p_kw'][step],z['q_kvar'][step]) for z in net['loads']),
               tuple(sorted((sid,port,p) for (sid,port),p in powers.items() if p > 0)))
        if key in cache:
            saved=cache[key];operating_states[step]=saved['states']
            for sid in station_q:station_q[sid][step]=saved['q'][sid]
            equipment.append({**saved['equipment'],'step':step})
            for bid,values in saved['trace'].items():traces[bid].append({**values,'step':step})
            for sid,values in saved['current'].items():currents[sid].append({**values,'step':step})
            continue
        try:
            states, q = circuit.set_state(step, powers)
            operating_states[step]=states
            for sid in station_q:
                station_q[sid][step]=q[sid]
            fundamental = {b['id']: circuit.voltages(b['id']) for b in watched}
            initial_i = {sid: circuit.currents(e) for sid, e in net['pcc_elements'].items()}
            loading = []
            for ln in net['lines']:
                loading.append({'id': ln['id'], 'kind': 'line', 'loading_pct': float(max(abs(circuit.currents('line.'+ln['id'])))/ln['ampacity_a']*100)})
            for t in net['transformers']:
                rating = t['kva']/(math.sqrt(3)*circuit.buses[t['from_bus']]['kv'])
                loading.append({'id': t['id'], 'kind': 'transformer', 'loading_pct': float(max(abs(circuit.currents('transformer.'+t['id'])))/rating*100)})
            equipment.append({'step': step, 'assets': loading})
            harmonic_v = {b['id']: [] for b in watched}; harmonic_i = {sid: [] for sid in initial_i}
            for h in HARMONICS:
                circuit.harmonic(h)
                for b in watched:
                    harmonic_v[b['id']].append(abs(circuit.voltages(b['id'])))
                for sid, e in net['pcc_elements'].items():
                    harmonic_i[sid].append(abs(circuit.currents(e)))
            for b in watched:
                f = abs(fundamental[b['id']]); vbase = b['kv']*1000/math.sqrt(3)
                harm = np.asarray(harmonic_v[b['id']]); pct = harm/np.maximum(f, 1e-9)*100
                thd = np.sqrt((pct**2).sum(axis=0)); pu = f/vbase
                if not np.isfinite(pu).all() or not np.isfinite(thd).all() or min(pu) < .1:
                    raise ValueError('节点失压、非有限数值或无有效基波')
                criteria = b.get('criteria', {})
                vstatus = reference_status(pu, criteria.get('voltage_min_pu'), criteria.get('voltage_max_pu'))
                thd_limit = criteria.get('thdu_pct'); individual = criteria.get('individual_harmonic_pct', {})
                complete = thd_limit is not None and all(str(h) in individual for h in HARMONICS)
                hstatus = ('exceeds_reference' if max(thd) > thd_limit or any(max(pct[i]) > individual[str(h)] for i, h in enumerate(HARMONICS)) else 'within_reference') if complete else 'not_evaluated'
                traces[b['id']].append({'step': step, 'voltage_min_pu': float(min(pu)), 'voltage_max_pu': float(max(pu)),
                                        'voltage_phase_pu': pu.tolist(), 'thdu_pct': float(max(thd)),
                                        'harmonic_voltage_pct': pct.max(axis=1).tolist(),
                                        'voltage_status': vstatus, 'harmonic_status': hstatus})
            for sid in initial_i:
                i1 = abs(initial_i[sid]); ih = np.asarray(harmonic_i[sid])
                if not np.isfinite(i1).all() or not np.isfinite(ih).all() or any(not math.isfinite(e['loading_pct']) for e in loading):
                    raise ValueError('电流或设备负载率出现非有限数值')
                currents[sid].append({'step': step, 'fundamental_a': float(max(i1)),
                                      'harmonic_a': ih.max(axis=1).tolist(),
                                      'thdi_pct': float(max(np.sqrt((ih**2).sum(axis=0))/np.maximum(i1, 1e-9))*100) if max(i1) > 1e-4 else None,
                                      'current_limit_status': 'not_evaluated'})
            cache[key]={'states':states,'q':q,'equipment':equipment[-1],
                        'trace':{bid:rows[-1] for bid,rows in traces.items()},
                        'current':{sid:rows[-1] for sid,rows in currents.items()}}
        except Exception as exc:
            failures.append({'step': step, 'reason': str(exc)})
            operating_states[step]=None
            for sid in station_q:station_q[sid][step]=None
            for rows in list(traces.values())+list(currents.values())+[equipment]:
                if rows and rows[-1]['step']==step:rows.pop()
    summaries = []
    for b in watched:
        rows = traces[b['id']]
        summaries.append({'id': b['id'], 'name': b['name'], 'kind': b['kind'], 'kv': b['kv'],
                          'voltage_min_pu': min((r['voltage_min_pu'] for r in rows), default=None),
                          'voltage_max_pu': max((r['voltage_max_pu'] for r in rows), default=None),
                          'max_thdu_pct': max((r['thdu_pct'] for r in rows), default=None),
                          'voltage_exceedance_steps': sum(r['voltage_status']=='exceeds_reference' for r in rows),
                          'harmonic_exceedance_steps': sum(r['harmonic_status']=='exceeds_reference' for r in rows),
                          'criteria': b.get('criteria', {}), 'steps_evaluated': len(rows)})
    return {'status': 'failed' if failures else 'completed', 'failures': failures, 'steps_requested': n,
            'nodes': summaries, 'trace': traces, 'pcc_current': currents, 'equipment': equipment,
            'station_q_kvar': station_q, 'operating_states': operating_states,
            'harmonic_orders': HARMONICS, 'frequency_hz': 50,
            'engine': circuit.dss.Version, 'engineering_approved': False,
            'current_allocation_status': 'not_evaluated',
            'maximum_equipment_loading_pct': max((e['loading_pct'] for row in equipment for e in row['assets']), default=None),
            'equipment_overload_steps': sum(any(e['loading_pct']>100+1e-6 for e in row['assets']) for row in equipment),
            'not_evaluated': ['闪变', '电压暂降', '间谐波', '25次以上高频发射', '谐波电流用户分配限值', '正式接入审批'],
            'scope': '15分钟恒定设备运行点；2—25次频域谐波；最大相指标；仅与登记参考阈值比较',
            'equipment_scope': '基波电流负载率；未计算谐波附加温升与寿命损失'}


def event_screen(task, solution, step):
    """Apply a recorded charger transition at one frozen background operating point."""
    c=Circuit(task['electrical'],task['study']['plan']); values=[]; powers=[]
    for t in (step-1,step):
        ports={(r['station_id'],r['port']):solution['power_by_session'][r['id']][t]
               for r in solution['reservations'] if r['connected_step']<=t<r['departure_step']}
        c.set_state(step,ports);powers.append(sum(ports.values()))
        values.append({b['id']:(abs(c.voltages(b['id']))/(b['kv']*1000/math.sqrt(3))).tolist()
                       for b in task['electrical']['buses'] if b.get('observe')})
    return {'plan':task['study']['plan'],'step':step,'delta_kw':powers[1]-powers[0],
            'nodes':{k:min(v) for k,v in values[1].items()},'previous_nodes':{k:min(v) for k,v in values[0].items()},
            'phase_delta_pu':{k:[b-a for a,b in zip(values[0][k],values[1][k])] for k in values[0]},
            'background_step':step,'scope':'固定同一时刻背景，施加相邻充电设备状态；前后稳态差，不评价闪变或暂降'}


def impedance_scan(net, plan, step, damping=50, bus=None):
    """1 A injection; source emissions removed but passive load damping retained."""
    spec = copy.deepcopy(net); spec['source']['harmonics'] = {}
    for load in spec['loads']:
        load['harmonics'] = {}
    c = Circuit(spec, plan, damping); c.set_state(step, {})
    bus = bus or list(spec['station_buses'].values())[0]
    orders = [x/4 for x in range(8, 101)]
    c.command('new spectrum.scan numharm='+str(len(orders)+1)+' harmonic=(1 '+' '.join(map(str, orders))+') %mag=(100 '+' '.join('100' for _ in orders)+') angle=(0 '+' '.join('0' for _ in orders)+')')
    c.command(f'new isource.probe bus1={bus} phases=3 amps=1 angle=0 frequency=50 spectrum=scan scantype=positive')
    c.command('solve mode=snapshot frequency=50')
    rows = []
    for h in orders:
        c.harmonic(h); rows.append({'order': h, 'hz': 50*h, 'ohm': float(max(abs(c.voltages(bus))))})
    return {'bus': bus, 'damping_series_pct': damping, 'rows': rows,
            'peak': max(rows, key=lambda r: r['ohm']),
            'scope': '停充网络的1 A正序扫频；保留背景负荷等值阻尼，非设备动态响应'}


def paired_deltas(reference, candidate):
    """Aligned node/time differences, rather than subtracting unrelated maxima."""
    output = []
    for node in candidate['nodes']:
        base = {r['step']: r for r in reference['trace'][node['id']]}
        rows = [r for r in candidate['trace'][node['id']] if r['step'] in base]
        dv = [r['voltage_min_pu']-base[r['step']]['voltage_min_pu'] for r in rows]
        dh = [r['thdu_pct']-base[r['step']]['thdu_pct'] for r in rows]
        output.append({'node_id': node['id'], 'paired_steps': len(rows),
                       'min_voltage_delta_pu': min(dv, default=None), 'max_voltage_delta_pu': max(dv, default=None),
                       'max_thdu_delta_percentage_points': max(dh, default=None),
                       'background_voltage_exceedance_steps': sum(r['voltage_status']=='exceeds_reference' for r in base.values()),
                       'new_voltage_exceedance_steps': sum(r['voltage_status']=='exceeds_reference' and base[r['step']]['voltage_status']!='exceeds_reference' for r in rows),
                       'new_harmonic_exceedance_steps': sum(r['harmonic_status']=='exceeds_reference' and base[r['step']]['harmonic_status']!='exceeds_reference' for r in rows)})
    return output


def crosscheck_fundamental(net, step=0, powers=None, plan='ordered'):
    """Independent balanced AC check from the very same equipment parameters."""
    import pandapower as pp
    if any(max(z['phase_fractions'])-min(z['phase_fractions']) > 1e-9 for z in net['loads']):
        return {'status': 'not_evaluated', 'reason': '此独立校验仅适用于平衡基波工况'}
    c = Circuit(net, plan); states, _ = c.set_state(step, powers or {})
    p = pp.create_empty_network(f_hz=50)
    buses = {b['id']: pp.create_bus(p, b['kv'], name=b['id']) for b in net['buses']}
    src = net['source']; kv = c.buses[src['bus']]['kv']
    ideal = pp.create_bus(p, kv); pp.create_ext_grid(p, ideal, vm_pu=src['pu'])
    z = kv**2/src['mvasc3']; r = z/math.sqrt(1+src['xr']**2); x = r*src['xr']
    pp.create_impedance(p, ideal, buses[src['bus']], rft_pu=r/kv**2, xft_pu=x/kv**2, sn_mva=1)
    for t in net['transformers']:
        pp.create_transformer_from_parameters(p,buses[t['from_bus']],buses[t['to_bus']],sn_mva=t['kva']/1000,
            vn_hv_kv=c.buses[t['from_bus']]['kv'],vn_lv_kv=c.buses[t['to_bus']]['kv'],
            vkr_percent=t['r_pct'],vk_percent=math.hypot(t['r_pct'],t['xhl_pct']),pfe_kw=0,i0_percent=0,shift_degree=30)
    for e in net['lines']:
        pp.create_line_from_parameters(p,buses[e['from_bus']],buses[e['to_bus']],e['length_km'],e['r1'],e['x1'],
            e.get('c1_nf',0),e['ampacity_a']/1000)
    for z in net['loads']:
        pp.create_load(p,buses[z['bus']],p_mw=z['p_kw'][step]/1000,q_mvar=z['q_kvar'][step]/1000)
    for row in states:
        pp.create_load(p,buses[net['station_buses'][row['station_id']]],p_mw=row['p_kw']/1000,q_mvar=row['q_kvar']/1000)
    if plan == 'capacitor':
        for bus in net['station_buses'].values():
            pp.create_shunt(p,buses[bus],q_mvar=-net['mitigation']['capacitor_kvar_per_station']/1000)
    pp.runpp(p,numba=False,tolerance_mva=1e-8,calculate_voltage_angles=True)
    rows=[]
    for b in net['buses']:
        dss=float(np.mean(abs(c.voltages(b['id']))))/(b['kv']*1000/math.sqrt(3))
        pandapower=float(p.res_bus.vm_pu.at[buses[b['id']]])
        rows.append({'bus':b['id'],'dss_pu':dss,'pandapower_pu':pandapower,'error_pu':abs(dss-pandapower)})
    error=max(r['error_pu'] for r in rows)
    return {'status':'completed','passed':error<5e-4,'tolerance_pu':5e-4,'maximum_error_pu':error,
            'nodes':rows,'scope':'同源参数、平衡基波独立工具复核；不证明实际网络校准'}
