"""Loopback-only workbench; no cloud, model calls or field control."""
from __future__ import annotations
from .paths import runtime, quality_cache
import io
import json
import mimetypes
import threading
import uuid
import zipfile
from concurrent.futures import ThreadPoolExecutor
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse

from .io import ROOT, export_bundle, export_analysis, load_bundle, templates, save_result, preserve_import
from .demo import make_demo, PLANS
from .analysis import run, planning, flexibility
from .research import admission

JOBS={};LOCK=threading.Lock();POOL=ThreadPoolExecutor(max_workers=1)


def enqueue(kind,fn):
    jid=uuid.uuid4().hex[:16]
    with LOCK:JOBS[jid]={'id':jid,'kind':kind,'status':'queued'}
    def work():
        JOBS[jid]['status']='running'
        try:
            value=fn()
            if kind in ('run','import','ac'):
                save_result(value,runtime()/('private' if value['evidence_level']!='synthetic' else 'runs'))
            elif kind=='quality':
                from .quality_io import export_study
                folder=runtime()/'quality/local';folder.mkdir(parents=True,exist_ok=True)
                (folder/f'{jid}.zip').write_bytes(export_study(value))
            elif kind in ('planning','research'):
                folder=runtime()/'comparisons';folder.mkdir(parents=True,exist_ok=True)
                (folder/f'{jid}.zip').write_bytes(export_analysis(kind,value))
            JOBS[jid].update(status='completed',result=value)
        except Exception as exc:JOBS[jid].update(status='failed',error=f'{type(exc).__name__}: {exc}')
    POOL.submit(work)
    return {'id':jid,'status':'queued'}


class Handler(BaseHTTPRequestHandler):
    def log_message(self,*args):pass

    def send(self,data,status=200,content_type='application/json; charset=utf-8',filename=None):
        if not isinstance(data,bytes):data=json.dumps(data,ensure_ascii=False,allow_nan=False).encode()
        self.send_response(status);self.send_header('Content-Type',content_type)
        self.send_header('Content-Length',str(len(data)));self.send_header('Cache-Control','no-store')
        self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('Content-Security-Policy',"default-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; script-src 'self'; connect-src 'self'; frame-ancestors 'none'")
        if filename:self.send_header('Content-Disposition',f'attachment; filename="{filename}"')
        self.end_headers();self.wfile.write(data)

    def allowed(self):
        host=self.headers.get('Host','').split(':')[0]
        origin=self.headers.get('Origin')
        return host in ('127.0.0.1','localhost') and (not origin or origin==f'http://{self.headers.get("Host")}')

    def do_GET(self):
        if not self.allowed():return self.send({'error':'仅允许本机同源访问'},403)
        path=urlparse(self.path).path
        if path=='/runtime-config.json':return self.send({'schema':'runtime-1','mode':'local'})
        if path=='/api/health':return self.send({'status':'ok','version':'0.2.0','candidates':True})
        if path=='/api/candidates':
            from .candidates import local_catalog
            return self.send(local_catalog(runtime()/'private/candidates'))
        if path.startswith('/api/jobs/'):
            jid=path.rsplit('/',1)[1]
            job=JOBS.get(jid,{'status':'not_found'})
            if job.get('kind')=='quality' and job.get('status')=='completed':
                from .study import presentation
                job={**job,'result':presentation(job['result'])}
            return self.send(job,200 if jid in JOBS else 404)
        if path.startswith('/api/export/'):
            job=JOBS.get(path.rsplit('/',1)[1],{})
            if job.get('status')!='completed':return self.send({'error':'结果未完成'},404)
            if job.get('kind')=='quality':
                from .quality_io import export_study
                return self.send(export_study(job['result']),content_type='application/zip',filename='power-quality-evidence.zip')
            if job.get('kind') in ('planning','research'):
                return self.send(export_analysis(job['kind'],job['result']),content_type='application/zip',filename='truck-comparison.zip')
            if 'metrics' not in job.get('result',{}):return self.send({'error':'该结果不支持此导出'},404)
            return self.send(export_bundle(job['result']),content_type='application/zip',filename='truck-evaluation.zip')
        if path=='/api/demo-input.json':
            return self.send(json.dumps(make_demo(),ensure_ascii=False,indent=2).encode(),filename='task.json')
        if path=='/api/templates.zip':
            folder=templates();out=io.BytesIO()
            with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
                for p in folder.iterdir():
                    if p.is_file():z.writestr(p.name,p.read_bytes())
            return self.send(out.getvalue(),content_type='application/zip',filename='data-templates.zip')
        if path.startswith('/four-data/'):
            pointer=ROOT/'data/published/four/index.json'
            if not pointer.exists():return self.send({'error':'四站年度结果尚未登记'},404)
            entry=json.loads(pointer.read_text());folder=(ROOT/entry['path']).resolve();f=(folder/path.lstrip('/')).resolve()
            if not folder.is_relative_to(ROOT/'data/published') or not f.is_relative_to(folder) or not f.is_file():return self.send({'error':'指定年度版本缺失'},404)
            return self.send(f.read_bytes(),content_type=mimetypes.guess_type(str(f))[0] or 'application/octet-stream')
        if path=='/downloads/data-templates.zip':
            folder=templates();out=io.BytesIO()
            with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
                for p in folder.iterdir():
                    if p.is_file():z.writestr(p.name,p.read_bytes())
            return self.send(out.getvalue(),content_type='application/zip',filename='data-templates.zip')
        if path.startswith('/quality-data/'):
            relative=path.removeprefix('/quality-data/');folder=(quality_cache()).resolve();f=(folder/relative).resolve()
            if not f.is_relative_to(folder) or not f.is_file():return self.send({'error':'未生成该登记工况，请在本机计算'},404)
            return self.send(f.read_bytes(),content_type=mimetypes.guess_type(str(f))[0] or 'application/octet-stream')
        if path.startswith(('/vendor/three/','/vendor/leaflet/','/assets/scene/','/scene-data/','/city-data/','/presentation/')):
            folder=(ROOT/'web').resolve();f=(folder/path.lstrip('/')).resolve()
            if not f.is_relative_to(folder) or not f.is_file():return self.send({'error':'not found'},404)
            return self.send(f.read_bytes(),content_type=mimetypes.guess_type(str(f))[0] or 'application/octet-stream')
        if path.startswith('/candidates-') and path.endswith('.json'):
            import re
            if re.fullmatch(r'/candidates-[a-f0-9]{16}\.json',path):
                f=ROOT/'web'/path.lstrip('/')
                if f.is_file():return self.send(f.read_bytes())
        resources=json.loads((ROOT/'maintenance/public-resources.json').read_text())['web']
        files={'/'+name:name for name in resources};files['/']='index.html'
        if path in files:
            f=ROOT/'web'/files[path]
            return self.send(f.read_bytes(),content_type=(mimetypes.guess_type(str(f))[0] or 'application/octet-stream')+'; charset=utf-8')
        return self.send({'error':'not found'},404)

    def do_POST(self):
        if not self.allowed():return self.send({'error':'仅允许本机同源访问'},403)
        try:
            size=int(self.headers.get('Content-Length','0'))
            if not 0<size<=20_000_000:raise ValueError('请求体应为1字节至20MB')
            body=self.rfile.read(size);path=urlparse(self.path).path
            if path=='/api/candidates/import':
                from .candidates import import_register, save_records
                import hashlib
                raw=import_register(body) if body[:2]==b'PK' else json.loads(body.decode('utf-8-sig'))
                if not isinstance(raw,(dict,list)):raise ValueError('导入内容须为评估对象或记录列表')
                records=raw if isinstance(raw,list) else raw.get('records',[raw])
                if not isinstance(records,list) or not 1<=len(records)<=1000:raise ValueError('每次导入1—1000条评估记录')
                saved=save_records(records,runtime()/'private/candidates')
                source=runtime()/'private/candidate-imports';source.mkdir(parents=True,exist_ok=True)
                (source/(hashlib.sha256(body).hexdigest()+('.xlsx' if body[:2]==b'PK' else '.json'))).write_bytes(body)
                return self.send({'count':len(saved),'assessment_ids':[r['assessment_id'] for r in saved]})
            if path=='/api/import':
                raw=load_bundle(body) if body[:2]==b'PK' else json.loads(body.decode('utf-8-sig'))
                # Importing a demo does not turn it into measurement evidence.
                from .model import normalize
                normalize(raw)
                raw=preserve_import(raw,body)
                return self.send(enqueue('import',lambda:run(raw)),202)
            args=json.loads(body)
            if path=='/api/study-planning':
                from .study_planning import compare_annual
                valid={k:args[k] for k in ('year','growth','season','engineering','stress','background_repair') if k in args}
                return self.send(enqueue('quality',lambda:compare_annual(**valid)),202)
            if path=='/api/quality':
                from .study import compare_study
                return self.send(enqueue('quality',lambda:compare_study(args.get('season','summer'),args.get('stress','normal'))),202)
            if path=='/api/run':
                raw=make_demo(year=int(args.get('year',2027)),growth=args.get('growth','medium'),
                    plan=args.get('plan','ordered'),stress=args.get('stress','normal'))
                method=PLANS[args.get('plan','ordered')]['method']
                return self.send(enqueue('run',lambda:run(raw,method)),202)
            if path=='/api/planning':return self.send(enqueue('planning',lambda:planning(args.get('growth','medium'),args.get('stress','normal'))),202)
            if path=='/api/research':return self.send(enqueue('research',admission),202)
            if path in ('/api/flex','/api/ac'):
                job=JOBS.get(args.get('job_id'),{})
                if job.get('status')!='completed' or 'metrics' not in job.get('result',{}):raise ValueError('需要已完成的运行结果')
                r=job['result']
                if path=='/api/ac':return self.send(enqueue('ac',lambda:run(r['task'],r['method'],True)),202)
                return self.send(enqueue('flex',lambda:flexibility(r,args.get('feeder_id'))),202)
            return self.send({'error':'not found'},404)
        except (ValueError,KeyError,TypeError,zipfile.BadZipFile) as exc:return self.send({'error':str(exc)},400)


def serve(port=8785):
    templates()
    http=ThreadingHTTPServer(('127.0.0.1',port),Handler)
    print(f'Local: http://127.0.0.1:{port}/',flush=True)
    try:http.serve_forever()
    except KeyboardInterrupt:pass
    finally:http.server_close()
