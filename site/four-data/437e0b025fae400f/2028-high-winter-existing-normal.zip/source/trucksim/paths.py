"""Separate immutable source/evidence from process-local runtime files."""
import hashlib
import json
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def runtime():
    path=Path(os.environ.get('TRUCKSIM_RUN_DIR',str(ROOT/'output'))).resolve()
    path.mkdir(parents=True,exist_ok=True)
    return path

def frozen(family):
    registry=json.loads((ROOT/'data/published/index.json').read_text())
    entry=registry['families'][family]
    folder=(ROOT/entry['path']).resolve()
    if not folder.is_relative_to(ROOT/'data/published'): raise ValueError('冻结路径越界')
    if hashlib.sha256((folder/'frozen-manifest.json').read_bytes()).hexdigest()!=entry['manifest_sha256']:raise ValueError('冻结清单校验失败')
    return folder

def quality_cache():
    return frozen('quality')/'quality-data'
