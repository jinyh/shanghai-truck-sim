"""Local CSV/JSON interchange, source-preserving export and reproducible evidence."""
from __future__ import annotations
from .paths import runtime, quality_cache
import csv
import hashlib
import io
import json
import zipfile
from .archive import EvidenceZip
from datetime import datetime
from pathlib import Path
from .model import InputError, normalize

ROOT=Path(__file__).resolve().parent.parent


def preserve_import(raw, content):
    """Keep the exact incoming bytes locally before deriving computation records."""
    digest=hashlib.sha256(content).hexdigest()
    suffix='zip' if content[:2]==b'PK' else 'json'
    folder=runtime()/'private'/'inputs';folder.mkdir(parents=True,exist_ok=True)
    (folder/f'{digest}.{suffix}').write_bytes(content)
    raw['metadata']['original_import']={'sha256':digest,'format':suffix}
    return raw

FIELDS={
 'stations.csv':['id','name','region','status','longitude','latitude','coordinate_system','meter_id','user_transformer_id','feeder_id','ports','charger_kw','shared_power_kw','requested_capacity_kva','approved_capacity_kva','connection_limit_kw','commission_date','controllable'],
 'grid_assets.csv':['id','type','parent_id','name','limit_kw','background_boundary'],
 'timeseries.csv':['timestamp','entity_type','entity_id','background_kw','committed_kw','limit_kw','price_cny_kwh','quality'],
 'meter_components.csv':['asset_id','child_id','timestamp','p_kw'],
 'sessions.csv':['id','station_id','arrival_time','departure_time','required_kwh','max_power_kw','deadline_source'],
 'projects.csv':['id','asset_id','name','commission_year','lead_months','latest_start','utility_cny','user_cny','cost_basis','trigger'],
 'controls.csv':['station_id','equipment_id','permission_basis','command_time','command_kw','actual_time','actual_kw','latency_seconds','override','failure'],
 'demand_scenarios.csv':['year','scenario','station_id','vehicle_count','energy_kwh','source','published_at'],
 'network_parameters.csv':['asset_id','asset_type','from_bus','to_bus','voltage_kv','length_km','r_ohm_per_km','x_ohm_per_km','sn_mva','current_limit_a','source'],
 'calibration.csv':['timestamp','station_id','actual_kw','predicted_kw','split','quality'],
}


def csv_text(fields,rows):
    out=io.StringIO(newline='');writer=csv.DictWriter(out,fields,extrasaction='ignore');writer.writeheader()
    for row in rows:
        safe={k: ("'"+v if isinstance(v,str) and v.startswith(('=','+','-','@')) else v) for k,v in row.items()}
        writer.writerow(safe)
    return out.getvalue()


def templates():
    folder=runtime()/'templates';folder.mkdir(exist_ok=True)
    for source in (ROOT/'templates').iterdir():
        if source.is_file(): (folder/source.name).write_bytes(source.read_bytes())
    for name,fields in FIELDS.items():(folder/name).write_text(csv_text(fields,[]),encoding='utf-8-sig')
    manifest={'schema_version':'1.0','id':'customer-case','title':'客户数据待核验','start':'2026-09-01T00:00:00+08:00',
        'periods':2688,'step_minutes':15,'charging_efficiency':.95,'information_mode':'offline_known_scenario',
        'metadata':{'evidence':'customer_provided','source':'请填写导出系统与责任部门','version':'请填写导出日期/版本'},
        'note':'默认4周。效率为待确认字段；正式导入前填写，不可把示例参数视为测量值。'}
    (folder/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf8')
    return folder


def load_bundle(content):
    """Only whitelisted members are read; no ZIP member is extracted to disk."""
    with zipfile.ZipFile(io.BytesIO(content)) as z:
        if sum(i.file_size for i in z.infolist())>100_000_000 or len(z.infolist())>40:
            raise InputError('导入包超过100MB或40个成员')
        names=z.namelist()
        if len(names)!=len(set(names)):raise InputError('导入包存在重复文件名')
        if 'task.json' in names:
            raw=json.loads(z.read('task.json'));normalize(raw);return raw
        def read(name):
            if name not in names:raise InputError(f'缺少 {name}')
            return z.read(name).decode('utf-8-sig')
        raw=json.loads(read('manifest.json'))
        if not isinstance(raw,dict) or isinstance(raw.get('periods'),bool) or not isinstance(raw.get('periods'),int) or not 1<=raw['periods']<=35136:
            raise InputError('manifest.periods 必须为1–35136整数')
        if not isinstance(raw.get('metadata'),dict):raise InputError('manifest.metadata 必须为对象')
        def table(name):return list(csv.DictReader(io.StringIO(read(name))))
        def num(row,key):
            try:return float(row[key])
            except (ValueError,KeyError):raise InputError(f'{key}: 缺失或非数值') from None
        def integer(row,key):
            v=num(row,key)
            if not v.is_integer():raise InputError(f'{key}: 必须为整数')
            return int(v)
        raw['stations']=[]
        for row in table('stations.csv'):
            if row['controllable'].lower() not in ('true','false'):raise InputError('controllable 必须为 true/false')
            raw['stations'].append({**row,'ports':integer(row,'ports'),'charger_kw':num(row,'charger_kw'),
                'shared_power_kw':num(row,'shared_power_kw'),'connection_limit_kw':num(row,'connection_limit_kw'),
                'controllable':row['controllable'].lower()=='true'})
        raw['feeders']=[];raw['transformers']=[];n=raw['periods']
        assets={}
        for row in table('grid_assets.csv'):
            if row['type'] not in ('feeder','transformer'):raise InputError('grid_assets.type 需为 feeder/transformer')
            if row['id'] in assets:raise InputError('电网设备标识重复')
            item={**row,'limit_kw':[num(row,'limit_kw')]*n,'background_kw':[None]*n,'committed_kw':[None]*n}
            if row['type']=='feeder':item['transformer_id']=row['parent_id']
            raw['feeders' if row['type']=='feeder' else 'transformers'].append(item);assets[row['id']]=item
        start=datetime.fromisoformat(raw['start'])
        def step(ts,allow_end=False):
            parsed=datetime.fromisoformat(ts)
            if parsed.utcoffset()!=start.utcoffset():raise InputError('时间记录必须声明相同UTC+08时区')
            minutes=(parsed-start).total_seconds()/60
            if minutes%15 or not 0<=minutes/15<=(n if allow_end else n-1):raise InputError(f'时戳越界或未对齐: {ts}')
            return int(minutes/15)
        raw['price_cny_kwh']=[None]*n;seen=set();price_seen=set()
        for row in table('timeseries.csv'):
            t=step(row['timestamp']);key=(row['entity_type'],row['entity_id'],t)
            if key in seen:raise InputError('同一实体时段重复')
            seen.add(key)
            if row['quality']!='valid':raise InputError('存在缺测或异常记录；请先核实，不自动插值')
            if row['entity_type']=='price':
                if t in price_seen:raise InputError('同一时段电价重复，首版只支持统一购电单价')
                price_seen.add(t);raw['price_cny_kwh'][t]=num(row,'price_cny_kwh')
            else:
                if row['entity_id'] not in assets:raise InputError('时间序列引用未知设备')
                asset=assets[row['entity_id']]
                if row['entity_type']!=asset['type']:raise InputError('设备类型不匹配')
                asset['background_kw'][t]=num(row,'background_kw');asset['committed_kw'][t]=num(row,'committed_kw')
                if row.get('limit_kw'):asset['limit_kw'][t]=num(row,'limit_kw')
        if 'meter_components.csv' in names:
            seen=set()
            for row in table('meter_components.csv'):
                rid=row['asset_id'];child=row['child_id'];t=step(row['timestamp']);key=(rid,child,t)
                if rid not in assets or key in seen:raise InputError('分项设备未知或记录重复')
                seen.add(key)
                assets[rid].setdefault('included_children_kw',{}).setdefault(child,[None]*n)[t]=num(row,'p_kw')
        raw['sessions']=[]
        for row in table('sessions.csv'):
            raw['sessions'].append({**row,'arrival_step':step(row['arrival_time']),
                'departure_step':step(row['departure_time'],True),'required_kwh':num(row,'required_kwh'),
                'max_power_kw':num(row,'max_power_kw')})
        raw['projects']=table('projects.csv') if 'projects.csv' in names else []
        raw['investment']={'utility_cny':None,'user_cny':None,'basis':'未核定，未参与投资评价'}
        raw['metadata']['imported_optional_tables']=[name for name in ('controls.csv','network_parameters.csv','demand_scenarios.csv','calibration.csv') if name in names]
        raw['supplementary_tables']={name:table(name) for name in raw['metadata']['imported_optional_tables']}
        raw['metadata']['optional_table_scope']='附表保留为交付资料，不自动推断调控有效性、工程投资或网络认证'
        raw['metadata']['evidence']='customer_provided'
        normalize(raw);return raw


def report_text(result):
    t=result['task'];m=result['metrics']
    amount=lambda x:'未提供' if x is None else f'{x:.2f} 元'
    rows=['# 重卡场站接入与配套电网仿真评估','',t['title'],'',
        f"案例：{result['job_id']}；输入校验：{result['input_hash']}",'',
        f"证据：{'合成示范，尚未校准上海真实站点' if result['evidence_level']=='synthetic' else '客户提供数据，尚待业务与工程复核'}。",
        f"评价期：{t['start']} 起 {m['period_hours']:.1f} 小时；离线已知工况；不年化。",'',
        '## 主要结果','',f"容量与车辆服务：{'合格' if m['feasible'] else '不合格'}。欠充 {m['shortfall_kwh']:.3f} kWh；场站联合峰值 {m['charging_peak_kw']:.2f} kW。",
        f"用户侧评价期电能费用 {m['operator_energy_cost_cny']:.2f} 元；电网建成投资 {amount(m['utility_investment_cny'])}；用户建设投资 {amount(m['user_investment_cny'])}。",
        '费用不含未提供的需量、运维、补偿等项目；投资延期效益未核算。','',
        '## 一站一表','', '| 场站 | 馈线/主变 | 峰值 kW | 欠充 kWh | 判断 |','|---|---|---:|---:|---|']
    for s in m['stations']:rows.append(f"| {s['name']} | {s['feeder_id']}/{s['transformer_id']} | {s['peak_kw']:.2f} | {s['shortfall_kwh']:.3f} | {s['assessment']} |")
    rows+=['','## 电网限制记录','']
    limited=[a for a in m['assets'] if a['max_excess_kw']>1e-4]
    rows += [f"- {a['name']}：最高负载率 {a['max_loading_pct']:.2f}%，本评价期越限 {a['violation_hours']:.2f} 小时。" for a in limited] or ['本评价期所列有功容量边界未越限。']
    rows+=['','## 配套工程假设','']
    rows += [f"- {p['name']}：{p['commission_year']}年投产，建设期{p['lead_months']}个月，最迟启动假设{p['latest_start']}；{p['cost_basis']}。" for p in t.get('projects',[])] or ['本案例未计入新增工程。']
    rows+=['','## 校核范围','',m['grid_check_scope'],f"交流校核状态：{result['ac']['status']}。正式接入审批：未形成。",
        '单站附加功率空间以其他站本方案负荷不变为条件，不可跨站相加。控制失效、季节工况及适用事故方式需另行覆盖。','',
        '## 待补材料','', '正式站点与供电设备映射、同期负荷、已承诺项目、网络及判据、出车最低需求、控制执行、工程造价与建设周期。','',
        '## 输入假设','']+[f'- {s}' for s in t['metadata'].get('assumptions',[])]
    if result['ac']['status']=='completed':
        ac=result['ac'];rows+=['','## 交流潮流结论','',f"完整检查{ac['steps_checked']}个时段，{ac['failed_steps']}个时段未通过；{'通过' if ac['passed'] else '未通过'}合成网络示范判据。"]
        affected=sorted({v['asset_id'] for v in ac.get('violations',[])})
        if affected:rows.append('越限对象：'+ '、'.join(affected)+'。详细时刻与量值见result.json的ac.violations。')
        rows.append('交流结果与有功容量检查分别报告；容量通过不保证交流网络通过。')
    if result.get('power_quality'):
        q=result['power_quality'];transport=result.get('transport',{})
        rows+=['','## 电压、谐波与运输任务','',f"电气计算：{q['status']}；运输账本：{transport.get('status')}。",
               '各项独立报告；下表是登记参考阈值的情景比较，不是工程接入合格结论。',
               '| 节点 | 最低电压 pu | 最高2—25次 THDu % | 电压越参考值时段 | 谐波越参考值时段 |',
               '|---|---:|---:|---:|---:|']
        for b in q.get('nodes',[]):
            rows.append(f"| {b['name']} | {b['voltage_min_pu']} | {b['max_thdu_pct']} | {b['voltage_exceedance_steps']} | {b['harmonic_exceedance_steps']} |")
        rows+=['',q.get('scope',q.get('reason','')),'未评估：'+ '、'.join(q.get('not_evaluated',[]))]
    return '\n'.join(rows)+'\n'


def export_bundle(result):
    out=io.BytesIO()
    with EvidenceZip(out,'w',zipfile.ZIP_DEFLATED) as z:
        def write(name,value):z.writestr(name,json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False))
        write('task.json',result['task']);write('result.json',result)
        original=result['task']['metadata'].get('original_import',{})
        digest=original.get('sha256','');suffix=original.get('format')
        if len(digest)==64 and all(c in '0123456789abcdef' for c in digest) and suffix in ('json','zip'):
            source=runtime()/'private'/'inputs'/f'{digest}.{suffix}'
            if source.is_file() and hashlib.sha256(source.read_bytes()).hexdigest()==digest:
                z.writestr('original-input.'+suffix,source.read_bytes())
        z.writestr('评估报告.md',report_text(result))
        z.writestr('逐站评估.csv','\ufeff'+csv_text(['id','name','feeder_id','transformer_id','rated_kw','shared_power_kw','connection_limit_kw','peak_kw','grid_energy_kwh','shortfall_kwh','mean_wait_minutes','assessment','evidence'],result['metrics']['stations']))
        curves=[]
        for a in result['metrics']['assets']:
            for t,stamp in enumerate(result['timestamps']):curves.append({'timestamp':stamp,'type':a['type'],'id':a['id'],'p_kw':a['curve_kw'][t],'limit_kw':a['limit_kw'][t]})
        z.writestr('容量时序.csv','\ufeff'+csv_text(['timestamp','type','id','p_kw','limit_kw'],curves))
        add_sources(z)
        z.writestr('复算说明.txt','在本项目独立环境内执行：python -m trucksim.cli reproduce 解压目录。\n源代码快照位于 source；独立安装时使用主交付包 wheelhouse。不需要模型账户或网络服务。\n')
    return out.getvalue()


def add_sources(z):
    hashes={}
    paths=list(sorted((ROOT/'trucksim').rglob('*.py')))+[ROOT/name for name in ('pyproject.toml','uv.lock','README.md') if (ROOT/name).exists()]
    for path in paths:
        data=path.read_bytes();name='source/'+path.relative_to(ROOT).as_posix();z.writestr(name,data)
        hashes[name]=hashlib.sha256(data).hexdigest()
    z.writestr('source_manifest.json',json.dumps(hashes,indent=2))


def export_analysis(kind,value):
    out=io.BytesIO()
    with EvidenceZip(out,'w',zipfile.ZIP_DEFLATED) as z:
        z.writestr('analysis.json',json.dumps({'kind':kind,'result':value},ensure_ascii=False,indent=2,allow_nan=False))
        rows=value.get('rows',value.get('records',[]))
        if rows:z.writestr('方案比较.csv','\ufeff'+csv_text(list(rows[0]),rows))
        if kind=='planning':
            z.writestr('工程时序.csv','\ufeff'+csv_text(FIELDS['projects.csv']+['plan'],value['projects']))
            curves=[]
            for case in value['time_series']:
                for field in ('station_power_kw','feeder_power_kw','transformer_power_kw'):
                    for aid,series in case[field].items():
                        for t,p in enumerate(series):curves.append({'year':case['year'],'plan':case['plan'],'timestamp':case['timestamps'][t],'asset_id':aid,'power_kw':p})
            z.writestr('逐年逐设备负荷.csv','\ufeff'+csv_text(['year','plan','timestamp','asset_id','power_kw'],curves))
        add_sources(z)
        z.writestr('复算说明.txt','在同版本独立环境内执行 python -m trucksim.cli reproduce 解压目录。\n年度比较仅使用登记合成工况；不作全年费用与电量外推。源码和依赖要求见source/README.md。\n')
    return out.getvalue()


def save_result(result,folder=None):
    folder=Path(folder or runtime());folder.mkdir(parents=True,exist_ok=True)
    stem=folder/result['job_id']
    stem.with_suffix('.json').write_text(json.dumps(result,ensure_ascii=False,allow_nan=False),encoding='utf8')
    stem.with_suffix('.md').write_text(report_text(result),encoding='utf8')
    stem.with_suffix('.zip').write_bytes(export_bundle(result))
    return stem
