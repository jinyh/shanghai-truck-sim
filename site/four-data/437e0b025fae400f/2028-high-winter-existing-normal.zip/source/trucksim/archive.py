"""Deterministic ZIP metadata for reproducible new exports."""
import zipfile

class EvidenceZip(zipfile.ZipFile):
    def writestr(self, name, data, compress_type=None, compresslevel=None):
        if isinstance(name,str):
            info=zipfile.ZipInfo(name,date_time=(2026,1,1,0,0,0));info.compress_type=self.compression or zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16
        else:info=name
        return super().writestr(info,data,compress_type,compresslevel)
