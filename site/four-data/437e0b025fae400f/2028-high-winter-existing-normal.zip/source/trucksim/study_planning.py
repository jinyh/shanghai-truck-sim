"""Four-station longitudinal scenarios; engineering and operation are independent."""
from __future__ import annotations
import copy
import datetime as dt
import hashlib
import json
import math
from pathlib import Path
from .study import make_study, compare_study

GROWTH={'low':.06,'medium':.13,'high':.20}
ENGINEERING={'existing':'现状设备','station':'S1/S2站内扩容','shared':'F1/T1共享设备强化','combined':'站内与共享设备组合'}
# Frozen demonstration bill of quantities, not market prices or a real design.
PROJECTS=[
 {'id':'S1-UP','object':'S1','group':'station','owner':'station','quantity':1,'unit':'站内扩容包','unit_cost_cny':650000,'lead_months':6,'ports':8,'shared_power_kw':2560,'connection_limit_kw':2500,'transformer':'UST1','kva':3200,'r_pct':1,'xhl_pct':6},
 {'id':'S2-UP','object':'S2','group':'station','owner':'station','quantity':1,'unit':'站内扩容包','unit_cost_cny':650000,'lead_months':6,'ports':8,'shared_power_kw':2560,'connection_limit_kw':2500,'transformer':'UST2','kva':3200,'r_pct':1,'xhl_pct':6},
 {'id':'F1-UP','object':'LF1','group':'shared','owner':'utility','quantity':4,'unit':'km','unit_cost_cny':450000,'lead_months':18,'ampacity_a':600,'r1':.10,'x1':.06,'r0':.30,'x0':.18,'c1_nf':300,'c0_nf':150,'limit_kw':10000},
 {'id':'T1-UP','object':'T1','group':'shared','owner':'utility','quantity':1,'unit':'主变增容包','unit_cost_cny':3200000,'lead_months':24,'kva':50000,'r_pct':.5,'xhl_pct':8,'limit_kw':36000},
 {'id':'UZT1-UP','object':'UZT1','group':'background','owner':'other_user','quantity':1,'unit':'用户变整改包','unit_cost_cny':450000,'lead_months':6,'kva':5000,'r_pct':1,'xhl_pct':6},
]
ASSUMPTIONS={'version':'four-planning-1','base_year':2026,'years':[2027,2028,2029,2030],'growth':GROWTH,'background_growth':.035,'seed':42,'projects':PROJECTS,'cost_basis':'显式合成工程量与单价；非市场询价、预算或实际工程设计','engineering_basis':'增容设备参数独立登记；F1为双回同规格线路的等值参数，主变为合成等值增容；短路、保护及实际施工未覆盖','control_loss':'全周失去集中调度，保持现场硬限值；独立补偿与滤波保持运行，不代表动态失控过程','annualized':False,'as_of':'2026-10-16'}
ASSUMPTION_HASH=hashlib.sha256(json.dumps(ASSUMPTIONS,sort_keys=True).encode()).hexdigest()

def project_list(engineering,background_repair=False):
    groups={'existing':set(),'station':{'station'},'shared':{'shared'},'combined':{'station','shared'}}[engineering]
    if background_repair:groups=groups|{'background'}
    return [copy.deepcopy(p) for p in PROJECTS if p['group'] in groups]

def make_annual(year=2027,growth='medium',season='summer',plan='ordered',engineering='existing',stress='normal',days=7,background_repair=False):
    if year not in range(2026,2031) or growth not in GROWTH or engineering not in ENGINEERING:raise ValueError('未登记的规划条件')
    raw=make_study(season,plan,'normal' if stress=='control_loss' else stress,days=days)
    if year==2026 and engineering=='existing' and stress!='control_loss' and not background_repair:return raw
    count=math.floor(4*(1+GROWTH[growth])**(year-2026)+.5)
    old=copy.deepcopy(raw['transport']);sessions={s['id']:s for s in raw['sessions']}
    raw['transport']['vehicles']=[];raw['transport']['trips']=[];raw['sessions']=[]
    for sid in ('S1','S2','S3','S4'):
        for i in range(count):
            source=f'{sid}V{i%4}';vid=f'{sid}V{i}'
            v=copy.deepcopy(next(v for v in old['vehicles'] if v['id']==source));v['id']=vid;raw['transport']['vehicles'].append(v)
            for trip in (t for t in old['trips'] if t['vehicle_id']==source):
                t=copy.deepcopy(trip);t['id']=vid+trip['id'][len(source):];t['vehicle_id']=vid
                if 'session_id' in trip:
                    s=copy.deepcopy(sessions[trip['session_id']]);s['id']='C'+t['id'];t['session_id']=s['id'];raw['sessions'].append(s)
                raw['transport']['trips'].append(t)
    net=raw['electrical'];factor=1.035**(year-2026)
    for z in net['loads']:
        for k in ('p_kw','q_kvar'):z[k]=[v*factor for v in z[k]]
    for f in raw['feeders']:f['background_kw']=[sum(z['p_kw'][t] for z in net['loads'] if z['feeder_id']==f['id']) for t in range(raw['periods'])]
    projects=project_list(engineering,background_repair)
    for p in projects:
        if p['group']=='station':
            s=next(s for s in raw['stations'] if s['id']==p['object'])
            for k in ('ports','shared_power_kw','connection_limit_kw'):s[k]=p[k]
            net['station_ports'][s['id']]=p['ports'];target=p['transformer']
        else:target=p['object']
        if target.startswith('LF'):
            ln=next(x for x in net['lines'] if x['id']==target)
            for k in ('ampacity_a','r1','x1','r0','x0','c1_nf','c0_nf'):ln[k]=p[k]
            next(f for f in raw['feeders'] if f['id']=='F1')['limit_kw']=p['limit_kw']
        else:
            t=next(x for x in net['transformers'] if x['id']==target)
            for k in ('kva','r_pct','xhl_pct'):t[k]=p[k]
            if target=='T1':next(x for x in raw['transformers'] if x['id']=='T1')['limit_kw']=p['limit_kw']
    if stress=='control_loss':
        for s in raw['stations']:s['controllable']=False
    month=7 if season=='summer' else 1;date=dt.date(year,month,1);date+=dt.timedelta(days=(-date.weekday())%7)
    raw['start']=f'{date.isoformat()}T00:00:00+08:00'
    raw['id']=f'four-{year}-{growth}-{season}-{stress}-{engineering}-{plan}'+('-repair' if background_repair else '')
    raw['study'].update(control_loss=stress=='control_loss',stress=stress)
    raw['planning']={'year':year,'growth':growth,'season':season,'engineering':engineering,'stress':stress,'vehicles_per_station':count,'assumption_hash':ASSUMPTION_HASH,'background_repair':background_repair}
    raw['metadata'].update(version='four-planning-1',year=year,planning_assumptions=ASSUMPTIONS)
    raw['projects']=projects
    costs={owner:sum(p['quantity']*p['unit_cost_cny'] for p in projects if p['owner']==owner) for owner in ('utility','station','other_user')}
    raw['investment']={'utility_cny':costs['utility'],'user_cny':costs['station'],'other_user_cny':costs['other_user'],'basis':ASSUMPTIONS['cost_basis']}
    return raw

def compare_annual(year=2027,growth='medium',season='summer',engineering='existing',stress='normal',days=7,background_repair=False):
    from .study import STUDY_PLANS
    inputs={p:make_annual(year,growth,season,p,engineering,stress,days,background_repair) for p in STUDY_PLANS}
    value=compare_study(season,stress,days,True,inputs)
    value.update(kind='four_station_planning_comparison',planning=inputs['ordered'].get('planning',{'year':2026,'growth':growth,'season':season,'engineering':engineering,'stress':stress}),assumptions=ASSUMPTIONS)
    return value

def summaries(value):
    rows=[]
    for plan,r in value['cases'].items():
        q=r['power_quality'];complete=q['status']=='completed' and not q['failures']
        states={'capacity':None,'transport':None,'voltage':None,'harmonics':None}
        if complete:
            states.update(capacity=q['maximum_equipment_loading_pct']<=100+1e-6 and all(a['max_loading_pct']<=100+1e-6 for a in r['metrics']['assets']),voltage=all(n['voltage_exceedance_steps']==0 and n['steps_evaluated']==r['task']['periods'] for n in q['nodes']),harmonics=all(n['harmonic_exceedance_steps']==0 and n['steps_evaluated']==r['task']['periods'] for n in q['nodes']))
        if plan!='baseline':states['transport']=r['transport'].get('passed')
        worst=max(((a['loading_pct'],a['id'],t['step']) for t in q['equipment'] for a in t['assets']),default=(None,None,None))
        rows.append({**value['planning'],'plan':plan,'input_hash':r['input_hash'],'states':states,'maximum_equipment_loading_pct':q['maximum_equipment_loading_pct'],'worst_asset':worst[1],'worst_step':worst[2],'shortfall_kwh':r['metrics']['shortfall_kwh'],'failed_trips':r['transport'].get('failed_trip_count'),'minimum_voltage_pu':min((n['voltage_min_pu'] for n in q['nodes'] if n['voltage_min_pu'] is not None),default=None),'maximum_thdu_pct':max((n['max_thdu_pct'] for n in q['nodes'] if n['max_thdu_pct'] is not None),default=None),'energy_cost_cny':None if plan=='baseline' else r['metrics']['operator_energy_cost_cny'],'charging_peak_kw':r['metrics']['charging_peak_kw'],'investment':r['task']['investment'],'projects':r['task']['projects'],'period_hours':r['metrics']['period_hours'],'annualized':False})
    return rows

def schedule(rows,growth='medium',plan='ordered',engineering='combined'):
    """Enumerate commissioning against paired annual configurations; never annualize."""
    results=[]
    for commission in range(2027,2031):
        selected=[r for r in rows if r['growth']==growth and r['plan']==plan and r['stress']=='normal' and r['engineering']==(engineering if r['year']>=commission else 'existing')]
        ready=len(selected)==8 and all(all(v is True for v in r['states'].values()) for r in selected)
        projects=project_list(engineering);lead=max([p['lead_months'] for p in projects],default=0)
        months=commission*12-lead;start=dt.date(months//12,months%12+1,1).isoformat()
        results.append({'commission_year':commission,'calculated_conditions_satisfied':ready,'latest_start':start,'implementation_status':'时序条件待落实' if start<ASSUMPTIONS['as_of'] else '建设条件待落实','projects':projects,'annual_investment':[{'year':y,'new':sum(p['quantity']*p['unit_cost_cny'] for p in projects) if y==commission else 0,'cumulative':sum(p['quantity']*p['unit_cost_cny'] for p in projects) if y>=commission else 0} for y in range(2027,2031)]})
    return results
