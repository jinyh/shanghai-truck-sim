"""Export/import of complete study evidence, sharing only the immutable geography."""
from __future__ import annotations

import copy
import io
import json
import zipfile
from .archive import EvidenceZip

from .io import add_sources, csv_text


def export_study(value, compression=zipfile.ZIP_DEFLATED):
    out=io.BytesIO()
    with EvidenceZip(out,'w',compression) as z:
        def write(name,obj):z.writestr(name,json.dumps(obj,ensure_ascii=False,separators=(',',':'),allow_nan=False))
        shared=value['cases']['baseline']['task']['spatial'];write('spatial.json',shared)
        manifest={k:v for k,v in value.items() if k!='cases'}
        manifest['cases']={}
        rows=[]
        for plan,r in value['cases'].items():
            task=copy.deepcopy(r['task'])
            if task.pop('spatial')!=shared:raise ValueError('对照案例必须使用同一空间数据')
            write(f'cases/{plan}/task.json',task)
            write(f'cases/{plan}/result.json',{k:v for k,v in r.items() if k!='task'})
            manifest['cases'][plan]={'input_hash':r['input_hash'],'spatial_reference':'spatial.json'}
            for node in r['power_quality']['nodes']:
                rows.append({'plan':plan,**{k:node[k] for k in ('id','name','kv','voltage_min_pu','voltage_max_pu','max_thdu_pct','voltage_exceedance_steps','harmonic_exceedance_steps','steps_evaluated')}})
        write('study.json',manifest)
        if rows:z.writestr('逐节点电能质量.csv','\ufeff'+csv_text(list(rows[0]),rows))
        add_sources(z)
        z.writestr('复算说明.txt','在同版本项目执行 python -m trucksim.cli reproduce 解压目录。\nspatial.json由五个输入共享；复算会还原原始输入并校验哈希。\n所有工程参数均为登记合成假设；频率50 Hz，谐波范围2—25次。\n各次谐波、电气运行点、运输账本、失败信息、判据与求解器版本均保存在cases/*/result.json。\n')
    return out.getvalue()


def restore_inputs(folder,manifest):
    shared=json.loads((folder/'spatial.json').read_text());inputs={}
    for plan in manifest['cases']:
        if plan not in ('baseline','unmanaged','ordered','capacitor','filter'):raise ValueError('未知方案')
        raw=json.loads((folder/'cases'/plan/'task.json').read_text());raw['spatial']=shared
        inputs[plan]=raw
    return inputs


def numerically_equal(a,b,tolerance=1e-7):
    if isinstance(a,bool) or isinstance(b,bool):return a==b
    if isinstance(a,(int,float)) and isinstance(b,(int,float)):
        return abs(a-b)<=tolerance*max(1,abs(a),abs(b))
    if isinstance(a,dict) and isinstance(b,dict):
        keys=set(a)-{'seconds','elapsed_seconds'}
        return keys==set(b)-{'seconds','elapsed_seconds'} and all(numerically_equal(a[k],b[k],tolerance) for k in keys)
    if isinstance(a,list) and isinstance(b,list):
        return len(a)==len(b) and all(numerically_equal(x,y,tolerance) for x,y in zip(a,b))
    return a==b
