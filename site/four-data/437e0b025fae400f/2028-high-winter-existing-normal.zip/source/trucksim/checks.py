"""Unified checks with a private process-local server and temporary runtime."""
import json
import os
import socket
import subprocess
import sys
import tempfile
import time
import urllib.request
from pathlib import Path
from .paths import ROOT

def check(suite='all',site=None):
    reports=[]
    with tempfile.TemporaryDirectory(prefix='trucksim-check-') as td:
        tmp=Path(td);env={**os.environ,'TRUCKSIM_RUN_DIR':str(tmp/'run'),'OPENBLAS_NUM_THREADS':'1'};(tmp/'output').mkdir()
        def run(args,cwd=ROOT):
            subprocess.run(args,cwd=cwd,env=env,check=True);reports.append(args)
        if suite in ('unit','all'):run([sys.executable,'-m','unittest','discover','-s','tests'])
        if suite in ('integration','all'):
            run([sys.executable,str(ROOT/'tools/check_build.py')])
            for file in sorted((ROOT/'tests').glob('check_*.mjs')):run(['node',str(file)])
            with socket.socket() as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
            server=subprocess.Popen([sys.executable,'-m','trucksim.cli','serve','--port',str(port)],cwd=ROOT,env=env,stdout=subprocess.DEVNULL)
            try:
                for _ in range(100):
                    try:urllib.request.urlopen(f'http://127.0.0.1:{port}/api/health',timeout=1);break
                    except OSError:time.sleep(.1)
                for name in ('check_http.py','check_quality_http.py'):run([sys.executable,str(ROOT/'tests'/name),f'http://127.0.0.1:{port}'],tmp)
            finally:server.terminate();server.wait(timeout=15)
        if suite in ('release','all'):
            run([sys.executable,str(ROOT/'tools/verify_pages.py')]+(['--site',str(Path(site).resolve())] if site else []))
        print(json.dumps({'passed':True,'suite':suite,'checks':len(reports)}))
