"""Read-only projection of annual results into the unchanged pre-screening rules."""
from .candidates import evaluate, digest, RULE_VERSION, STAGE
from .study import STUDY_PLANS

def scope(task,sid):
    net=task['electrical'];edges=net['lines']+net['transformers'];parents={x['to_bus']:x for x in edges}
    def ancestry(bus):
        result=[];seen=set()
        while bus in parents and bus not in seen:
            seen.add(bus);e=parents[bus];result.append(e);bus=e['from_bus']
        return result
    paths={s:ancestry(b) for s,b in net['station_buses'].items()}
    station=next(s for s in task['stations'] if s['id']==sid)
    feeder=station['feeder_id'];own=paths[sid]
    users=[z['bus'] for z in net['loads'] if any(e['from_bus']==feeder or e['to_bus']==feeder for e in ancestry(z['bus']))]
    observed={b['id'] for b in net['buses'] if b.get('observe')}
    nodes=sorted(({e['to_bus'] for e in own}|set(users))&observed)
    assets={e['id'] for e in own}
    for user in users:assets.update(e['id'] for e in ancestry(user))
    related={e['id']:[s for s,path in paths.items() if e['id'] in {x['id'] for x in path}] for e in edges}
    for e in edges:
        if not related[e['id']]:related[e['id']]=[s['id'] for s in task['stations'] if s['feeder_id']==feeder] if e['id'] in assets else []
    tx=next(f['transformer_id'] for f in task['feeders'] if f['id']==feeder)
    return nodes,assets,related,{sid,feeder,tx}

def station_checks(result,sid):
    task=result['task'];q=result['power_quality'];nodes,assets,related,active=scope(task,sid)
    complete=q['status']=='completed' and not q['failures']
    ledger=[x for x in result['transport'].get('ledger',[]) if x['vehicle_id'].startswith(sid+'V')]
    sessions=[x for x in result['metrics']['sessions'] if x['station_id']==sid]
    shortfall=sum(x['shortfall_kwh'] for x in sessions)
    demand=bool(ledger) and shortfall<=1e-5 and all(x['after_trip_kwh']>=-1e-5 and x['after_charge_kwh']+1e-5>=x['minimum_departure_kwh'] for x in ledger)
    cap=[];capacity_complete=complete
    for aid in sorted(assets):
        points=[(r['step'],a['loading_pct']) for r in q.get('equipment',[]) for a in r['assets'] if a['id']==aid]
        capacity_complete &= len(points)==task['periods']
        if points:
            t,v=max(points,key=lambda x:x[1]);cap.append(dict(object=aid,actual=v,limit=100,unit='%',step=t,locator=f'power_quality/equipment/{t}/assets[id={aid}]',related_stations=related[aid]))
    for a in result['metrics']['assets']:
        if a['id'] in active:cap.append(dict(object=a['id'],actual=a['max_loading_pct'],limit=100,unit='%',step=a['worst_step'],locator=f'metrics/assets[id={a["id"]}]',related_stations=[sid],metric='运行有功限额利用率'))
    states={'demand':demand,'capacity':False if any(e['actual']>100+1e-6 for e in cap) else True if capacity_complete and cap else None}
    details={'demand':[dict(object=sid,actual=shortfall,unit='kWh',limit=0,locator=f'transport/ledger[vehicle_id={sid}V*];metrics/sessions',metric='欠充')],'capacity':cap}
    for key in ('voltage','harmonics'):
        found=[n for n in q['nodes'] if n['id'] in nodes];out=[];bad=False;valid=len(found)==len(nodes) and complete
        for n in found:
            criterion=n['criteria'];trace=q['trace'].get(n['id'],[])
            valid &= bool(criterion.get('voltage_min_pu') is not None and criterion.get('voltage_max_pu') is not None) if key=='voltage' else bool(criterion.get('thdu_pct') and len(criterion.get('individual_harmonic_pct',{}))==24)
            valid &= len(trace)==task['periods'] and n['steps_evaluated']==task['periods']
            points=[]
            for row in trace:
                if key=='voltage' and row.get('voltage_min_pu') is not None:
                    for field,limit,sign in [('voltage_min_pu',criterion.get('voltage_min_pu'),-1),('voltage_max_pu',criterion.get('voltage_max_pu'),1)]:
                        if limit is not None:points.append((sign*(row[field]-limit),row,field,row[field],limit))
                if key=='harmonics' and row.get('thdu_pct') is not None:
                    if criterion.get('thdu_pct'):points.append((row['thdu_pct']/criterion['thdu_pct']-1,row,'thdu_pct',row['thdu_pct'],criterion['thdu_pct']))
                    for h,v in zip(range(2,26),row.get('harmonic_voltage_pct',[])):
                        limit=criterion.get('individual_harmonic_pct',{}).get(str(h))
                        if limit:points.append((v/limit-1,row,h,v,limit))
            if not points:valid=False;continue
            excess,row,field,actual,limit=max(points,key=lambda x:x[0]);bad|=excess>1e-6
            out.append(dict(object=n['id'],actual=actual,limit=limit,unit='pu' if key=='voltage' else '%',step=row['step'],metric=field,locator=f'power_quality/trace/{n["id"]}/{row["step"]}',criterion=criterion['voltage_standard' if key=='voltage' else 'harmonic_standard']+'；'+criterion['statistics']))
        states[key]=False if bad else True if valid else None;details[key]=out
    return states,details

def assessments(value,control=None,source=''):
    records=[]
    for plan,result in value['cases'].items():
        if plan=='baseline':continue
        for station in result['task']['stations']:
            sid=station['id'];states,details=station_checks(result,sid);baseline=value['cases']['baseline']
            context={'scale':station['connection_limit_kw'],'combination':{s['id']:{'scale_kw':s['connection_limit_kw'],'dispatch':plan} for s in result['task']['stations']},'background':value['id'],'network':digest(result['task']['electrical']),'control':value['planning']['stress']+'-'+plan,'rules':RULE_VERSION}
            def ev(item,origin=result,archive=source):
                e={**item,'state':'valid','source':archive,'locator':f'cases/{plan}/'+item['locator'] if item['locator'].startswith('task.json#') else f'cases/{plan}/result.json#'+item['locator'],'version':origin['input_hash'],'station_id':sid,'proposal_id':plan,'binding':context.copy(),'criterion':item.get('criterion','登记设备限额≤100%；运输行程与离站电量满足；数值容差1e-5'),'evidence_kind':'合成年度计算'}
                if 'step' in item:
                    t=item['step'];e['time']=origin['timestamps'][t]
                    paired=baseline if origin is result else control['cases']['baseline']
                    if item['object'] in paired['power_quality']['trace']:
                        b=paired['power_quality']['trace'][item['object']][t];field=item.get('metric');bv=b.get(field) if isinstance(field,str) else b.get('harmonic_voltage_pct',[])[field-2] if isinstance(field,int) else None
                    else:
                        bv=next((a['loading_pct'] for row in paired['power_quality']['equipment'] if row['step']==t for a in row['assets'] if a['id']==item['object']),None)
                    if bv is not None:e.update(baseline=bv,delta=item['actual']-bv)
                return e
            checks=[]
            for check,state in states.items():
                checks.append({'id':check,'status':{True:'pass',False:'fail',None:'unknown'}[state],'reason':f'{sid} '+{'demand':'运输与补能','capacity':'关联设备容量','voltage':'登记用户与接入点电压','harmonics':'登记用户与接入点谐波'}[check]+('满足登记条件' if state is True else '存在不满足项' if state is False else '未完整评估'),'evidence':[ev(e) for e in details[check]]})
            def assumption(check,text,conditional=False,unknown=False):
                condition={'id':check+'-closure','text':text,'owner':'试点参与方（待确认）','verified':True,'verification':'登记合成流程与设备运行边界；计算证据见本方案复算包','closure_evidence':'工程投产/运行职责/通道授权验收记录','closed':False}
                return {'id':check,'status':'unknown' if unknown else 'conditional' if conditional else 'pass','reason':text,'evidence':[] if unknown else [ev({'locator':'task.json#planning;projects;electrical','criterion':'合成前置条件登记；不等同于实际手续','object':sid})],'conditions':[condition] if conditional else []}
            checks.append(assumption('external','S4外线路径与权属待核实' if sid=='S4' else 'S2通道使用授权待落实（合成流程）' if sid=='S2' else '既有线路路径与本阶段手续按合成基准登记',sid=='S2',sid=='S4'))
            checks.append(assumption('controls','现场限值与运行职责按合成基准登记' if plan=='unmanaged' else '调度执行、独立补偿/滤波及现场控制保障待联合验证',plan!='unmanaged'))
            if plan!='unmanaged':
                if control:
                    cr=control['cases'][plan];cs,cd=station_checks(cr,sid);good=all(v is True for v in cs.values());bad=any(v is False for v in cs.values())
                    checks.append({'id':'control_failure','status':'fail' if bad else 'pass' if good else 'unknown','reason':'全周失去集中控制：'+('存在必要条件不满足' if bad else '已完成合成联合复核' if good else '未完整评估'),'evidence':[ev(e,cr,control['_source']) for es in cd.values() for e in es]})
                else:checks.append({'id':'control_failure','status':'unknown','reason':'该增长与配置尚无控制失效联合记录','evidence':[]})
            projects=result['task']['projects'];extra=[]
            if projects:
                extra=[{'id':'construction','name':'工程投产条件','trigger':'所选配置包含尚未实施的合成候选工程'}]
                checks.append(assumption('construction','候选工程参数已冻结；投产时间、建设手续与工程验收待落实',True))
            records.append(evaluate({'stage':STAGE,'evaluated_at':'2026-10-16T12:00:00+08:00','station':{'id':sid,'name':station['name'],'coordinates':[station['longitude'],station['latitude']]},'proposal':{'id':plan,'name':STUDY_PLANS[plan],'scale_kw':station['connection_limit_kw'],'requires_control':plan!='unmanaged'},'context':context,'checks':checks,'additional_required':extra,'public':True,'case_id':value['id'],'planning':value['planning'],'source_export':source,'source_input_hash':result['input_hash'],'scope':'四站联合接入；当前年份及季节代表周；电气范围由登记网模生成，同馈线用户与本支路上级设备。绿色不预留容量。','not_evaluated':['短路','保护','转供','可靠性','实际工程设计','现场控制与手续验收']}))
    return records
